import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { IndustriesSection } from './components/IndustriesSection';
import { VisionSection } from './components/VisionSection';
import { StrengthSection } from './components/StrengthSection';
import { ServicesSection } from './components/ServicesSection';
import { InstrumentationSection } from './components/InstrumentationSection';
import { ElectricalSection } from './components/ElectricalSection';
import { FeaturedProjectsSection } from './components/FeaturedProjectsSection';
import { ExpertiseSection } from './components/ExpertiseSection';
import { ManpowerSection } from './components/ManpowerSection';
import { ClientsSection } from './components/ClientsSection';
import { VendorCodeSection } from './components/VendorCodeSection';
import { CertificationSection } from './components/CertificationSection';
import { SafetySection } from './components/SafetySection';
import { QualitySection } from './components/QualitySection';
import { CallToActionBanner } from './components/CallToActionBanner';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BackToTop } from './components/BackToTop';
import { AdminPanel } from './components/AdminPanel';

export default function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  useEffect(() => {
    // Check if URL contains #admin
    const handleHash = () => {
      if (window.location.hash === '#admin') {
        setIsAdminOpen(true);
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);

    // Keyboard shortcut: Ctrl + Alt + A (or Cmd + Alt + A)
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.altKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setIsAdminOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('hashchange', handleHash);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleCloseAdmin = () => {
    setIsAdminOpen(false);
    if (window.location.hash === '#admin') {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-orange-500 selection:text-white">
      {/* 1. HEADER (Sticky Navigation) */}
      <Navbar onOpenAdmin={() => setIsAdminOpen(true)} />

      <main className="flex-grow">
        {/* 2. HERO */}
        <Hero />

        {/* 3. ABOUT NARAYAN ENGINEERING */}
        <AboutSection />

        {/* 4. INDUSTRIES WE SERVE */}
        <IndustriesSection />

        {/* 5. OUR VISION */}
        <VisionSection />

        {/* 6. OUR STRENGTH */}
        <StrengthSection />

        {/* 7. SERVICES OFFERED */}
        <ServicesSection />

        {/* 8. INSTRUMENTATION SERVICES */}
        <InstrumentationSection />

        {/* 9. ELECTRICAL SERVICES */}
        <ElectricalSection />

        {/* FEATURED PROJECTS (Masonry Grid Industrial Showcase) */}
        <FeaturedProjectsSection />

        {/* 10. OUR EXPERTISE */}
        <ExpertiseSection />

        {/* 11. MANPOWER SCHEDULE */}
        <ManpowerSection />

        {/* 12. OUR MAJOR CLIENTS */}
        <ClientsSection />

        {/* 13. REGISTERED VENDOR CODE */}
        <VendorCodeSection />

        {/* 14. RECOGNITION & CERTIFICATION */}
        <CertificationSection />

        {/* 15. HEALTH & SAFETY POLICY */}
        <SafetySection />

        {/* 16. QUALITY POLICY */}
        <QualitySection />

        {/* Vertex Signature Orange Action Banner */}
        <CallToActionBanner />

        {/* 17. CONTACT US */}
        <ContactSection />
      </main>

      {/* 18. FOOTER */}
      <Footer onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Interactive Back to Top & Quick Call */}
      <BackToTop />

      {/* Admin Tender & Enquiries Portal */}
      <AdminPanel isOpen={isAdminOpen} onClose={handleCloseAdmin} />
    </div>
  );
}

