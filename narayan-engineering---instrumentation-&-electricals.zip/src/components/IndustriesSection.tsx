import React from 'react';
import { Flame, Factory, Droplets, Sprout, FlaskConical, Building2, Hammer, Zap, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { IMAGES } from '../assets/images';

interface IndustryItem {
  id: string;
  name: string;
  subtitle: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

const industries: IndustryItem[] = [
  { id: 'oil-gas', name: 'OIL & GAS', subtitle: 'Upstream, midstream & pipeline networks', icon: Flame },
  { id: 'petrochemical', name: 'PETROCHEMICAL', subtitle: 'Cracking, polymers & derivative units', icon: Factory },
  { id: 'refinery', name: 'REFINERY', subtitle: 'Atmospheric distillation, FCCU & hydroprocessing', icon: Droplets },
  { id: 'fertilizer', name: 'FERTILIZER', subtitle: 'Ammonia, urea & complex fertilizer plants', icon: Sprout },
  { id: 'chemical', name: 'CHEMICAL', subtitle: 'Specialty & bulk industrial chemical complexes', icon: FlaskConical },
  { id: 'cement', name: 'CEMENT', subtitle: 'Continuous kilns, clinker & grinding plants', icon: Building2 },
  { id: 'steel-sectors', name: 'STEEL SECTORS', subtitle: 'Blast furnaces, rolling mills & smelters', icon: Hammer },
  { id: 'power-sectors', name: 'POWER SECTORS', subtitle: 'Thermal, captive & substation utilities', icon: Zap },
];

export const IndustriesSection: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const topOffset = 75;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="industries" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Heading and Subtitle matching Vertex "BUILT ON EXPERTISE. FOCUSED ON RESULTS." */}
          <div className="lg:col-span-4 space-y-4">
            <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold">
              INDUSTRIES WE SERVE
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight leading-tight">
              BUILT ON EXPERTISE. <br className="hidden sm:inline" />
              FOCUSED ON RESULTS.
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed">
              Narayan Engineering delivers specialized instrumentation and electrical contracting across core continuous-process, hydrocarbon, and heavy industrial facilities.
            </p>
            <div className="pt-2">
              <button
                onClick={() => scrollTo('instrumentation')}
                className="inline-flex items-center gap-2 text-xs font-bold font-mono-tech uppercase text-[#F15A24] hover:text-orange-600 transition-colors group cursor-pointer"
              >
                <span>LEARN MORE ABOUT OUR DISCIPLINES</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Right Column: Clean Grid matching the 4-column capabilities icon cards */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {industries.map((ind, index) => {
                const Icon = ind.icon;
                return (
                  <div
                    key={ind.id}
                    className="p-5 rounded-md border border-slate-200/90 bg-slate-50/60 hover:bg-white hover:border-[#F15A24] hover:shadow-md transition-all group flex flex-col items-center text-center justify-between min-h-[170px]"
                  >
                    <div className="w-12 h-12 rounded-md bg-white border border-slate-200 flex items-center justify-center text-slate-700 group-hover:text-[#F15A24] group-hover:border-orange-200 group-hover:bg-orange-50/50 transition-all mb-3 shadow-xs">
                      <Icon size={24} />
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-bold text-xs sm:text-sm text-slate-900 font-sans tracking-wide uppercase group-hover:text-[#F15A24] transition-colors leading-snug">
                        {ind.name}
                      </h3>
                      <p className="text-[11px] text-slate-500 leading-tight line-clamp-2">
                        {ind.subtitle}
                      </p>
                    </div>

                    <span className="text-[10px] font-mono-tech text-slate-400 mt-2">
                      0{index + 1}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Industrial Continuous-Process Plant Facility Feature Strip */}
        <div className="rounded-xl overflow-hidden border border-slate-200 bg-[#070F1E] text-white shadow-xl relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
            {/* Refinery Photo Left/Center */}
            <div className="lg:col-span-7 relative h-64 sm:h-72 lg:h-80 overflow-hidden group">
              <img
                src={IMAGES.refinerySkyline.src}
                alt={IMAGES.refinerySkyline.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#070F1E]/30 to-[#070F1E]" />
              <div className="absolute top-4 left-4 bg-orange-600/90 backdrop-blur-xs text-white text-[10px] font-mono-tech uppercase font-bold px-3 py-1 rounded shadow-sm">
                HEAVY INDUSTRIAL FOOTPRINT
              </div>
            </div>

            {/* Industrial Plant Scope Highlights Right */}
            <div className="lg:col-span-5 p-6 sm:p-8 space-y-4">
              <div className="text-xs uppercase font-mono-tech tracking-wider text-orange-400 font-semibold">
                SECTOR LEADERSHIP
              </div>
              <h3 className="text-xl sm:text-2xl font-bold font-sans text-white uppercase tracking-tight">
                Continuous-Process Plants &amp; Refinery Complexes
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                From Gujarat Refinery (IOCL Vadodara) to MRPL Mangalore and Nayara Energy Vadinar, our certified engineers and technicians execute mission-critical instrumentation, impulse lines, and hazardous-area cabling with zero schedule slippage.
              </p>

              <div className="grid grid-cols-2 gap-2 pt-2 text-xs font-mono-tech text-slate-300">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-[#F15A24] shrink-0" />
                  <span>Hydrocracker Units</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-[#F15A24] shrink-0" />
                  <span>Ammonia / Urea Plants</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-[#F15A24] shrink-0" />
                  <span>Polymer &amp; Cracker Skids</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-[#F15A24] shrink-0" />
                  <span>Thermal Captive Units</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};


