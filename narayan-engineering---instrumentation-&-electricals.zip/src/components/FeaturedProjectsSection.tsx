import React, { useState } from 'react';
import {
  Building2,
  Calendar,
  CheckCircle2,
  MapPin,
  ShieldCheck,
  ArrowRight,
  ExternalLink,
  Layers,
  Sparkles,
  Sliders,
  Filter,
  X,
  FileText,
  Zap,
  Gauge,
  Activity,
} from 'lucide-react';
import { FEATURED_PROJECTS, FeaturedProject } from '../assets/images';
import { EnquiryModal } from './EnquiryModal';

export const FeaturedProjectsSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<FeaturedProject | null>(null);
  const [rfqModalOpen, setRfqModalOpen] = useState(false);

  const categories = [
    { id: 'all', label: 'All Projects', count: FEATURED_PROJECTS.length },
    {
      id: 'refinery',
      label: 'Refinery Infrastructure',
      count: FEATURED_PROJECTS.filter((p) => p.category === 'refinery').length,
    },
    {
      id: 'instrumentation',
      label: 'Field Instrumentation',
      count: FEATURED_PROJECTS.filter((p) => p.category === 'instrumentation').length,
    },
    {
      id: 'electrical',
      label: 'Industrial Electrical',
      count: FEATURED_PROJECTS.filter((p) => p.category === 'electrical').length,
    },
    {
      id: 'turnaround',
      label: 'Plant Turnaround',
      count: FEATURED_PROJECTS.filter((p) => p.category === 'turnaround').length,
    },
  ];

  const filteredProjects =
    activeCategory === 'all'
      ? FEATURED_PROJECTS
      : FEATURED_PROJECTS.filter((p) => p.category === activeCategory);

  return (
    <section id="projects" className="py-20 lg:py-24 bg-[#060D1A] text-white border-b border-slate-800 relative overflow-hidden">
      {/* Subtle Blueprint Grid Pattern in Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="projects-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#60A5FA" strokeWidth="0.5" strokeOpacity="0.3" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#projects-grid)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-slate-800 pb-8">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold mb-2">
              <span className="w-2 h-2 rounded-full bg-[#F15A24] animate-pulse" />
              <span>PROVEN TRACK RECORD · ESTD. 1991</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-sans uppercase tracking-tight text-white">
              Featured Projects
            </h2>
            <div className="w-16 h-1 bg-[#F15A24] mt-4 rounded-full" />
          </div>
          <p className="text-slate-300 text-sm sm:text-base max-w-xl leading-relaxed">
            Showcasing over three decades of mission-critical execution across major continuous-process complexes, refineries, chemical crackers, and heavy industrial facilities.
          </p>
        </div>

        {/* Category Filters Bar */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-sm text-xs font-mono-tech uppercase font-bold tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
                activeCategory === cat.id
                  ? 'bg-[#F15A24] text-white shadow-lg shadow-orange-950/40 border border-orange-500'
                  : 'bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>{cat.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded ${
                  activeCategory === cat.id
                    ? 'bg-orange-800 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {cat.count}
              </span>
            </button>
          ))}
        </div>

        {/* Masonry Grid Layout using CSS Columns */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="break-inside-avoid rounded-xl overflow-hidden bg-[#0A1324] border border-slate-800 hover:border-orange-500/60 shadow-xl transition-all duration-300 group cursor-pointer hover:translate-y-[-2px] flex flex-col"
            >
              {/* Project Image Container */}
              <div className={`relative w-full overflow-hidden ${project.aspectRatioClass} bg-slate-950`}>
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A1324] via-transparent to-transparent opacity-90 group-hover:opacity-75 transition-opacity" />

                {/* Category Pill Tag */}
                <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm">
                  {project.categoryLabel}
                </div>

                {/* Year Badge */}
                <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md border border-slate-700 text-slate-300 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm">
                  {project.year}
                </div>

                {/* Quick Client & Location Overlay */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono-tech text-slate-300">
                  <span className="flex items-center gap-1.5 text-white font-semibold truncate max-w-[65%]">
                    <Building2 size={13} className="text-[#F15A24] shrink-0" />
                    <span className="truncate">{project.client}</span>
                  </span>
                  <span className="flex items-center gap-1 text-slate-400 shrink-0">
                    <MapPin size={12} className="text-[#F15A24]" />
                    {project.location.split(',')[0]}
                  </span>
                </div>
              </div>

              {/* Project Content Body */}
              <div className="p-6 space-y-4 flex-grow flex flex-col justify-between">
                <div className="space-y-2.5">
                  <h3 className="text-lg font-bold font-sans text-white group-hover:text-orange-400 transition-colors leading-snug">
                    {project.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3">
                    {project.scope}
                  </p>
                </div>

                {/* Key Deliverables Checklist */}
                <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                  {project.deliverables.slice(0, 2).map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-300 font-sans">
                      <CheckCircle2 size={13} className="text-[#F15A24] shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                  ))}
                  {project.deliverables.length > 2 && (
                    <div className="text-[11px] font-mono-tech text-slate-400 pt-0.5">
                      +{project.deliverables.length - 2} more technical scopes verified
                    </div>
                  )}
                </div>

                {/* Card Footer Metric Ribbon */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-mono-tech text-emerald-400 font-semibold truncate max-w-[70%]">
                    {project.metrics}
                  </span>
                  <span className="text-xs font-mono-tech text-orange-400 group-hover:translate-x-1 transition-transform flex items-center gap-1 font-bold shrink-0">
                    <span>DETAILS</span>
                    <ArrowRight size={13} />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Callout Banner */}
        <div className="p-6 sm:p-8 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1.5 text-center md:text-left">
            <h3 className="text-lg sm:text-xl font-bold font-sans text-white">
              Have an Upcoming Project or Turnaround Requirement?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Submit your Bill of Quantities (BOQ), tender drawings, or plant scope for an estimation response.
            </p>
          </div>
          <button
            onClick={() => setRfqModalOpen(true)}
            className="shrink-0 px-6 py-3.5 bg-[#F15A24] hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider font-mono-tech rounded shadow-lg shadow-orange-950/40 transition-all cursor-pointer flex items-center gap-2"
          >
            <FileText size={15} />
            <span>REQUEST PROJECT RFQ / TENDER</span>
          </button>
        </div>
      </div>

      {/* Full Project Detail Modal (Technical Dossier) */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-3xl rounded-xl bg-[#0B1528] border border-slate-700 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Top Header */}
            <div className="px-6 py-4 bg-[#070E1B] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#F15A24]" />
                <span className="text-xs font-mono-tech uppercase font-bold text-orange-400">
                  PROJECT SPECIFICATION DOSSIER
                </span>
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
              {/* Big High-Res Image Banner */}
              <div className="relative h-64 sm:h-72 rounded-lg overflow-hidden border border-slate-800">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
                <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded">
                  {selectedProject.categoryLabel}
                </div>
                <div className="absolute bottom-3 left-4 right-4">
                  <div className="text-xl sm:text-2xl font-bold font-sans text-white">
                    {selectedProject.title}
                  </div>
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono-tech">
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase">CLIENT / SITE</div>
                  <div className="text-white font-bold mt-0.5 truncate">{selectedProject.client}</div>
                </div>
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase">LOCATION</div>
                  <div className="text-white font-bold mt-0.5 truncate">{selectedProject.location}</div>
                </div>
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase">EXECUTION YEAR</div>
                  <div className="text-orange-400 font-bold mt-0.5">{selectedProject.year}</div>
                </div>
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase">DELIVERY STATUS</div>
                  <div className="text-emerald-400 font-bold mt-0.5">100% Commissioned</div>
                </div>
              </div>

              {/* Scope Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-tech uppercase text-orange-400 font-bold">
                  PROJECT SCOPE &amp; CONTRACT SUMMARY
                </h4>
                <p className="text-sm text-slate-300 leading-relaxed font-normal">
                  {selectedProject.scope}
                </p>
              </div>

              {/* Verified Deliverables */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono-tech uppercase text-orange-400 font-bold">
                  VERIFIED DELIVERABLES &amp; COMPLIANCE
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedProject.deliverables.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded bg-slate-900/70 border border-slate-800 flex items-center gap-2.5 text-xs text-slate-200"
                    >
                      <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Benchmark */}
              <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-600/40 flex items-center justify-between text-xs font-mono-tech">
                <div className="flex items-center gap-2 text-emerald-300">
                  <ShieldCheck size={18} className="text-emerald-400 shrink-0" />
                  <span>PERFORMANCE BENCHMARK:</span>
                  <strong className="text-white">{selectedProject.metrics}</strong>
                </div>
                <span className="text-slate-400">ISO 9001:2015 QA Tagged</span>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="p-5 bg-[#070E1B] border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs font-mono-tech text-slate-400">
                Statutory Registration: MSME UAN GJ24D0009735
              </span>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="px-4 py-2.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono-tech uppercase font-bold cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProject(null);
                    setRfqModalOpen(true);
                  }}
                  className="px-5 py-2.5 rounded bg-[#F15A24] hover:bg-orange-600 text-white text-xs font-mono-tech uppercase font-bold tracking-wider cursor-pointer shadow-md shadow-orange-950/40 flex items-center gap-1.5"
                >
                  <FileText size={14} />
                  <span>Enquire for Similar Scope</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* RFQ / Enquiry Modal */}
      <EnquiryModal
        isOpen={rfqModalOpen}
        onClose={() => setRfqModalOpen(false)}
        defaultDiscipline="Instrumentation Engineering"
      />
    </section>
  );
};
