import React from 'react';
import { Building2, ShieldCheck, Quote } from 'lucide-react';

interface ClientItem {
  id: string;
  name: string;
  fullName: string;
  sector: string;
}

const clients: ClientItem[] = [
  {
    id: 'mrpl',
    name: 'MRPL',
    fullName: 'Mangalore Refinery and Petrochemicals Limited',
    sector: 'Refinery & Petrochemicals',
  },
  {
    id: 'gujarat-refinery',
    name: 'Gujarat Refinery',
    fullName: 'Indian Oil Corporation Limited (IOCL) - Gujarat Refinery, Vadodara',
    sector: 'Refinery & Processing',
  },
  {
    id: 'nayara',
    name: 'Nayara',
    fullName: 'Nayara Energy Limited (formerly Essar Oil)',
    sector: 'Refining & Petrochemicals',
  },
  {
    id: 'abb',
    name: 'ABB',
    fullName: 'ABB India Limited',
    sector: 'Automation & Power Technologies',
  },
  {
    id: 'reliance',
    name: 'Reliance',
    fullName: 'Reliance Industries Limited',
    sector: 'Petrochemicals & Energy',
  },
  {
    id: 'gail',
    name: 'GAIL',
    fullName: 'GAIL (India) Limited',
    sector: 'Natural Gas & Petrochemicals',
  },
];

export const ClientsSection: React.FC = () => {
  return (
    <section id="clients" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Vertex-Inspired Testimonial / Partnership Quote Strip */}
        <div className="p-8 sm:p-10 rounded-lg bg-slate-50 border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded bg-orange-500/10 text-[#F15A24] flex items-center justify-center shrink-0 mt-1">
              <Quote size={28} />
            </div>
            <div className="space-y-2">
              <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold">
                TRUSTED BY INDUSTRY PARTNERS
              </div>
              <p className="text-base sm:text-lg text-slate-800 font-medium italic leading-relaxed">
                “From our very first job we have maintained a good relationship with our clients, provided quality work &amp; timely completion of the entrusted jobs to us.”
              </p>
              <div className="text-xs font-mono-tech text-slate-500 font-semibold">
                — M/S. NARAYAN ENGINEERING · VADODARA, GUJARAT
              </div>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2 bg-white px-4 py-2.5 rounded border border-slate-200 shadow-xs">
            <ShieldCheck size={18} className="text-emerald-500" />
            <span className="text-xs font-mono-tech font-bold text-slate-800">
              ISO 9001:2015 ASSURED
            </span>
          </div>
        </div>

        {/* Section Heading */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <div className="text-xs uppercase font-mono-tech tracking-wider text-slate-400 font-semibold mb-1">
              RELATIONSHIPS &amp; REPUTATION
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
              Our Major Clients
            </h2>
          </div>
          <span className="text-xs font-mono-tech text-slate-500">
            6 Key Enterprise Partners
          </span>
        </div>

        {/* Major Clients Grid matching Vertex Clean Enterprise Boxes */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {clients.map((client, index) => (
            <div
              key={client.id}
              className="bg-slate-50 hover:bg-white rounded-md p-5 border border-slate-200 hover:border-[#F15A24] hover:shadow-md transition-all flex flex-col justify-between group min-h-[140px] text-center"
            >
              <div className="text-[10px] font-mono-tech text-slate-400 font-bold">
                0{index + 1}
              </div>

              <div className="my-auto py-2">
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 font-sans tracking-tight group-hover:text-[#F15A24] transition-colors">
                  {client.name}
                </h3>
              </div>

              <div className="text-[10px] font-mono-tech text-slate-500 uppercase tracking-wide truncate">
                {client.sector}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

