import React from 'react';
import { Users, FileSpreadsheet, CheckCircle2, ShieldCheck, HardHat, Wrench, Briefcase, Info, ArrowRight } from 'lucide-react';

interface DeploymentCategory {
  title: string;
  scope: string;
  code: string;
  responsibilities: string[];
}

const deploymentCategories: DeploymentCategory[] = [
  {
    title: 'Site In-charge & Project Engineers',
    scope: 'Engineering & Supervision',
    code: 'TIER 01',
    responsibilities: [
      'Project planning, client coordination, and execution scheduling',
      'Quality assurance, permit-to-work, and safety compliance oversight',
      'Testing protocol verification and as-built record maintenance',
    ],
  },
  {
    title: 'Instrumentation Calibration & Loop Technicians',
    scope: 'Specialized Technical',
    code: 'TIER 02',
    responsibilities: [
      'Bench and in-situ calibration of transmitters, gauges, and switches',
      'Loop checking, cable continuity, DCS/PLC signal simulation',
      'Control valve stroke checking, positioner alignment, and tubing',
    ],
  },
  {
    title: 'Certified Electricians & Cable Jointers',
    scope: 'Electrical Construction',
    code: 'TIER 03',
    responsibilities: [
      'MCC, PCC, and distribution panel erection and busbar coupling',
      'Power and control cable laying, glanding, ferruling, and termination',
      'Earth pit construction, earth grid testing, and motor trial runs',
    ],
  },
  {
    title: 'Instrument Fitters & Welders',
    scope: 'Mechanical / Piping',
    code: 'TIER 04',
    responsibilities: [
      'SS/Copper tube routing, fabrication, and proper fitting assembly',
      'Argon welding for impulse piping and air distribution headers',
      'Perforated/ladder cable tray and structural support fabrication',
    ],
  },
];

export const ManpowerSection: React.FC = () => {
  return (
    <section id="manpower" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header (Vertex Style "EXPERIENCED WORKFORCE. BUILT FOR WHAT'S NEXT.") */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-6">
          <div>
            <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold mb-1">
              RESOURCE MOBILIZATION
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
              MANPOWER SCHEDULE &amp; SUPERVISION
            </h2>
          </div>
          <div className="text-xs font-mono-tech text-slate-500 max-w-sm">
            Experienced engineers, certified technicians, and craft teams mobilized as per contract specifications.
          </div>
        </div>

        {/* 4 Deployment Tier Cards matching Vertex's Leadership 4-Card row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {deploymentCategories.map((cat) => (
            <div
              key={cat.code}
              className="bg-white rounded-md p-6 border border-slate-200 shadow-sm hover:border-[#F15A24] hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[11px] font-mono-tech uppercase text-[#F15A24] font-bold bg-orange-50 px-2 py-0.5 rounded border border-orange-100">
                    {cat.code}
                  </span>
                  <span className="text-[11px] font-mono-tech text-slate-400">
                    Vadodara Mobilized
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1 font-mono-tech">
                  {cat.scope}
                </div>

                <h3 className="font-bold text-base text-slate-900 font-sans mb-4 leading-snug">
                  {cat.title}
                </h3>

                <ul className="space-y-2.5 text-xs text-slate-600 mb-6">
                  {cat.responsibilities.map((resp, rIdx) => (
                    <li key={rIdx} className="flex items-start gap-2 leading-relaxed">
                      <CheckCircle2 size={13} className="text-[#F15A24] shrink-0 mt-0.5" />
                      <span>{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono-tech text-slate-500">
                <span>Site Induction Verified</span>
                <span className="text-emerald-600 font-bold">100% PPE</span>
              </div>
            </div>
          ))}
        </div>

        {/* Tender Dossier Notice Bar */}
        <div className="bg-slate-900 text-white rounded-md p-6 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs font-mono-tech uppercase text-orange-400 font-bold">
              Project Specific Rosters &amp; Organograms
            </div>
            <p className="text-xs sm:text-sm text-slate-300">
              Category-wise manpower schedules, qualification dossiers, and statutory compliance certificates (EPFO Code: GJ/20100 &amp; ESIC Code: 38240749840010999 under Regulation 14) are furnished directly with project tender bids.
            </p>
          </div>
          <a
            href="#contact"
            className="shrink-0 inline-flex items-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white text-xs font-bold font-mono-tech uppercase px-4 py-2.5 rounded-sm transition-colors"
          >
            <span>REQUEST SCHEDULE</span>
            <ArrowRight size={13} />
          </a>
        </div>
      </div>
    </section>
  );
};

