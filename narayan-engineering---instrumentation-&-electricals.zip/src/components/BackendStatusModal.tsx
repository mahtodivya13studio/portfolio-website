import React, { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  X,
  ShieldCheck,
  Server,
} from 'lucide-react';
import {
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  SUPABASE_SCHEMA_SQL,
  SUPABASE_SQL_EDITOR_URL,
  checkSupabaseStatus,
  syncLocalQueue,
  getPendingQueueCounts,
} from '../lib/supabase';

interface BackendStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BackendStatusModal: React.FC<BackendStatusModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [checking, setChecking] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<string | null>(null);
  const [status, setStatus] = useState<{
    connected: boolean;
    endpoint: string;
    projectId: string;
    tables: { enquiries: boolean; contacts: boolean };
    details: string;
  } | null>(null);

  const [queueCounts, setQueueCounts] = useState({ rfqs: 0, contacts: 0, total: 0 });

  const runCheck = async () => {
    setChecking(true);
    setSyncResult(null);
    try {
      const result = await checkSupabaseStatus();
      setStatus(result);
      setQueueCounts(getPendingQueueCounts());
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runCheck();
    }
  }, [isOpen]);

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSyncQueue = async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await syncLocalQueue();
      setQueueCounts(getPendingQueueCounts());
      if (res.errors.length > 0) {
        setSyncResult(`Synced ${res.syncedRfqs + res.syncedContacts} item(s). Note: ${res.errors[0]}`);
      } else {
        setSyncResult(`Successfully synced ${res.syncedRfqs + res.syncedContacts} pending item(s) to Supabase!`);
      }
    } finally {
      setSyncing(false);
    }
  };

  if (!isOpen) return null;

  const bothTablesReady = status?.tables.enquiries && status?.tables.contacts;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative bg-[#0B1528] text-white border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="backend-modal-title"
      >
        {/* Header */}
        <div className="bg-[#070E1B] p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
              <Database size={20} />
            </div>
            <div>
              <h3 id="backend-modal-title" className="text-base font-bold font-sans text-white flex items-center gap-2">
                <span>Supabase Backend Console</span>
                <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
                  ONLINE
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono-tech">
                Project Ref: <strong className="text-white">{SUPABASE_PROJECT_ID}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Connection Status Card */}
          <div className="bg-slate-900/90 rounded-lg p-4 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server size={16} className="text-[#F15A24]" />
                <span className="text-xs font-mono-tech uppercase font-bold text-slate-300">
                  Endpoint Status
                </span>
              </div>
              <button
                onClick={runCheck}
                disabled={checking}
                className="inline-flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 font-mono-tech disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw size={12} className={checking ? 'animate-spin' : ''} />
                <span>{checking ? 'Testing...' : 'Re-test Connection'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono-tech">
              <div className="bg-[#070E1B] p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">REST API URL</span>
                <span className="text-slate-200 truncate block mt-0.5" title={SUPABASE_URL}>
                  {SUPABASE_URL}
                </span>
              </div>
              <div className="bg-[#070E1B] p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">API KEY TYPE</span>
                <span className="text-emerald-400 block mt-0.5">
                  Publishable Key (sb_publishable_...)
                </span>
              </div>
            </div>

            {/* Table Readiness Indicators */}
            <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs font-mono-tech">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400">Table 'enquiries':</span>
                  {status?.tables.enquiries ? (
                    <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                      <CheckCircle2 size={13} /> Active
                    </span>
                  ) : (
                    <span className="text-amber-400 flex items-center gap-1 font-semibold">
                      <AlertCircle size={13} /> Schema Pending
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400">Table 'contacts':</span>
                  {status?.tables.contacts ? (
                    <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                      <CheckCircle2 size={13} /> Active
                    </span>
                  ) : (
                    <span className="text-amber-400 flex items-center gap-1 font-semibold">
                      <AlertCircle size={13} /> Schema Pending
                    </span>
                  )}
                </div>
              </div>

              {queueCounts.total > 0 && (
                <div className="text-orange-400 bg-orange-950/60 px-2 py-0.5 rounded border border-orange-500/30 text-[11px]">
                  {queueCounts.total} queued submission(s) in local backup
                </div>
              )}
            </div>
          </div>

          {/* If tables are not created yet, show the 1-Click SQL Setup box */}
          {!bothTablesReady && (
            <div className="bg-amber-950/20 border border-amber-600/40 rounded-lg p-4 space-y-3">
              <div className="flex items-start gap-2.5">
                <AlertCircle size={18} className="text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-amber-200 uppercase font-mono-tech">
                    One-Time Setup: Create Tables in Supabase
                  </h4>
                  <p className="text-xs text-amber-100/80 leading-relaxed">
                    Your Supabase project is connected. To store client submissions permanently in PostgreSQL, copy the SQL below and run it in your Supabase SQL Editor.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  onClick={handleCopySql}
                  className="inline-flex items-center gap-1.5 bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech text-xs font-bold px-3.5 py-2 rounded transition-colors cursor-pointer shadow"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copied ? 'SQL Copied to Clipboard!' : 'Copy Schema SQL'}</span>
                </button>

                <a
                  href={SUPABASE_SQL_EDITOR_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-tech text-xs px-3.5 py-2 rounded border border-slate-700 transition-colors"
                >
                  <span>Open Supabase SQL Editor</span>
                  <ExternalLink size={13} />
                </a>
              </div>

              <div className="relative">
                <pre className="text-[11px] font-mono-tech text-slate-300 bg-[#070E1B] p-3 rounded border border-slate-800 max-h-36 overflow-y-auto">
                  {SUPABASE_SCHEMA_SQL}
                </pre>
              </div>
            </div>
          )}

          {/* If queue has pending items, show sync button */}
          {queueCounts.total > 0 && (
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">
                  Pending Offline Submissions ({queueCounts.total})
                </span>
                <span className="text-[11px] text-slate-400">
                  {queueCounts.rfqs} Tender RFQs · {queueCounts.contacts} Contact messages
                </span>
              </div>
              <button
                onClick={handleSyncQueue}
                disabled={syncing}
                className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono-tech font-bold px-3.5 py-2 rounded transition-colors disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw size={13} className={syncing ? 'animate-spin' : ''} />
                <span>{syncing ? 'Syncing...' : 'Sync to Supabase Now'}</span>
              </button>
            </div>
          )}

          {syncResult && (
            <div className="text-xs font-mono-tech p-3 rounded bg-slate-800 text-emerald-400 border border-emerald-500/30">
              {syncResult}
            </div>
          )}

          {/* Security & RLS Note */}
          <div className="text-xs text-slate-400 flex items-center gap-2 pt-2 border-t border-slate-800">
            <ShieldCheck size={15} className="text-emerald-400 shrink-0" />
            <span>
              Connected via secure client-side Supabase protocol with Row Level Security (RLS) enforcement.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#070E1B] px-6 py-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono-tech">
          <span className="text-slate-400">
            Narayan Engineering · Backend Integration Desk
          </span>
          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white font-bold cursor-pointer"
          >
            Close Console
          </button>
        </div>
      </div>
    </div>
  );
};
