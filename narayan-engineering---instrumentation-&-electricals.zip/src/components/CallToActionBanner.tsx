import React, { useState } from 'react';
import { Mail, ArrowRight, Phone, ShieldCheck, MapPin, CheckCircle2 } from 'lucide-react';
import { EnquiryModal } from './EnquiryModal';
import { IMAGES } from '../assets/images';

export const CallToActionBanner: React.FC = () => {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <section className="relative bg-[#081120] text-white py-16 px-4 sm:px-6 lg:px-8 border-y border-slate-800 shadow-2xl overflow-hidden">
        {/* Authentic Industrial Refinery Skyline Background */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <img
            src={IMAGES.refinerySkyline.src}
            alt={IMAGES.refinerySkyline.alt}
            className="w-full h-full object-cover object-center opacity-20 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#070F1E] via-[#070F1E]/95 to-[#070F1E]/80" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#070F1E]/90 via-transparent to-[#070F1E]" />
        </div>

        {/* Subtle Industrial Architectural Grid */}
        <div className="absolute inset-0 pointer-events-none opacity-10">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="skyline-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#60A5FA" strokeWidth="0.5" strokeOpacity="0.25" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#skyline-grid)" />
          </svg>
        </div>

        {/* Industrial Silhouette Vector Conduits */}
        <div className="absolute right-0 bottom-0 top-0 w-1/3 pointer-events-none opacity-10 hidden md:block">
          <svg viewBox="0 0 400 200" className="w-full h-full text-blue-400 stroke-current" fill="none">
            <path d="M0,180 L120,180 L160,80 L280,80 L320,140 L400,140" strokeWidth="2" />
            <path d="M40,200 L140,200 L180,120 L260,120 L300,160 L400,160" strokeWidth="1.5" strokeDasharray="6 4" />
            <circle cx="160" cy="80" r="4" fill="#F15A24" />
            <circle cx="280" cy="80" r="4" fill="#60A5FA" />
          </svg>
        </div>

        {/* Atmospheric Glow */}
        <div className="absolute top-1/2 left-10 -translate-y-1/2 w-72 h-72 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-8 relative z-10">
          {/* Left Column: Envelope Icon + High-Impact Text */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left max-w-3xl">
            {/* Signature Orange Envelope Icon Box */}
            <div className="w-16 h-16 rounded-md bg-[#F15A24] text-white flex items-center justify-center shrink-0 shadow-lg shadow-orange-950/40 ring-4 ring-orange-500/20">
              <Mail size={32} />
            </div>

            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                <span className="text-xs font-mono-tech uppercase tracking-widest text-[#F15A24] font-bold">
                  PROJECT PROCUREMENT &amp; TENDER DESK
                </span>
                <span className="hidden sm:inline text-slate-600">•</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono-tech text-slate-300">
                  <ShieldCheck size={13} className="text-emerald-400" />
                  ISO 9001:2015 CERTIFIED
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold uppercase font-sans tracking-tight text-white leading-tight">
                LOOKING FOR A RELIABLE INSTRUMENTATION &amp; ELECTRICAL PARTNER?
              </h2>

              <p className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed">
                Connect directly with our Vadodara engineering estimation team for tenders, site walk-throughs, unit revamps, and turnkey project execution.
              </p>

              <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs font-mono-tech text-slate-400">
                <span className="flex items-center gap-1.5">
                  <MapPin size={13} className="text-[#F15A24]" />
                  Gorwa, Vadodara, Gujarat
                </span>
                <span>•</span>
                <span className="text-slate-300">
                  MSME UAN: <strong className="text-white">GJ24D0009735</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Pre-Footer Call to Action Buttons */}
          <div className="shrink-0 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full sm:w-auto">
            <button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center justify-center gap-2.5 bg-[#F15A24] hover:bg-orange-600 text-white font-bold text-xs uppercase px-7 py-4 rounded-sm shadow-xl shadow-orange-950/40 transition-all hover:translate-y-[-1px] cursor-pointer tracking-wider"
            >
              <span>SEND AN ENQUIRY</span>
              <ArrowRight size={15} />
            </button>

            <a
              href="tel:+919624017705"
              className="inline-flex items-center justify-center gap-2 bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-bold text-xs uppercase px-5 py-4 rounded-sm border border-slate-700 hover:border-slate-500 transition-all cursor-pointer tracking-wider"
              title="Call Office"
            >
              <Phone size={14} className="text-[#F15A24]" />
              <span>OFFICE: +91 9624017705</span>
            </a>
          </div>
        </div>
      </section>

      {/* Tender / Project Enquiry Modal */}
      <EnquiryModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
