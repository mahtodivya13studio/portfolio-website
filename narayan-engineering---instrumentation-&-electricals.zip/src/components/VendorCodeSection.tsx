import React from 'react';
import { ShieldCheck, FileCheck2, Building2, CheckCircle2, Award, Hash, ExternalLink, Calendar, UserCheck } from 'lucide-react';

interface RegistrationRecord {
  authority: string;
  department: string;
  idNumber: string;
  type: string;
  effectiveDate: string;
  status: string;
  notes: string;
}

const officialRegistrations: RegistrationRecord[] = [
  {
    authority: 'Ministry of MSME, Govt. of India',
    department: 'Udyog Aadhaar / MSME Portal',
    idNumber: 'GJ24D0009735',
    type: 'Micro Enterprise (Service)',
    effectiveDate: '01/04/1991',
    status: 'Active / Registered',
    notes: 'Official Udyog Aadhaar Acknowledgement for Instrumentation & Electrical Services.',
  },
  {
    authority: 'Government of Gujarat',
    department: 'District Industries Centre (DIC), Vadodara',
    idNumber: 'EM2 24 019 21 007201',
    type: 'EM Part - II (Ack No: 5816 / Form 112341)',
    effectiveDate: '01/04/1991 (Issue: 04/03/2014)',
    status: 'Acknowledged Service Enterprise',
    notes: 'Registered for Instrumentation & Electricals, Erection Commissioning & Plant Maintenance.',
  },
  {
    authority: 'Regional Provident Fund Commissioner',
    department: 'Employees Provident Fund Organization (EPFO), Baroda',
    idNumber: 'GJ / 20100',
    type: 'EPF Allotment Code [App/BRD/486]',
    effectiveDate: '01/07/1991 (Allotted: 16/08/1991)',
    status: 'Continuous Statutory Compliance',
    notes: 'The Employees’ Provident Funds and Miscellaneous Provisions Act, 1952 applicability.',
  },
  {
    authority: "Employees' State Insurance Corporation (ESIC)",
    department: 'Ministry of Labour & Employment, Govt. of India',
    idNumber: '38240749840010999',
    type: "Employer's Code No. (Return of Declaration / Regulation 14)",
    effectiveDate: 'Active (Verified 02/02/2017)',
    status: 'Statutory Labour Compliance',
    notes: "Mandatory compliance under Section 2(9) of the Employees' State Insurance Act, 1948, safeguarding field technical manpower and plant site personnel.",
  },
  {
    authority: 'Goods & Services Tax (GST), Govt. of India',
    department: 'Commercial Tax Department, Gujarat (State 24)',
    idNumber: '24ACEPM8370P1Z1',
    type: 'GSTIN / Regular Taxpayer Identification',
    effectiveDate: 'Active & Verified',
    status: 'Active / Tax Compliant',
    notes: 'Official GSTIN registration for instrumentation & electrical engineering works and continuous-process industrial erection contracts.',
  },
];

const nicCodes = [
  {
    code: '42202',
    heading: 'Utility & Power Transmission',
    description: 'Construction/erection and maintenance of power, telecommunication and transmission lines',
  },
  {
    code: '42901',
    heading: 'Industrial Plants & Refineries',
    description: 'Construction and maintenance of industrial facilities such as refineries, chemical plants etc.',
  },
  {
    code: '43211',
    heading: 'Electrical Installation & Wiring',
    description: 'Installation of electrical wiring, industrial fittings, control instrumentation and panels',
  },
  {
    code: '41003',
    heading: 'Prefabricated Assembly & Erection',
    description: 'Assembly and erection of prefabricated constructions and structural assemblies on the site',
  },
];

export const VendorCodeSection: React.FC = () => {
  return (
    <section id="vendor-code" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="border-b border-slate-200 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold mb-1">
              STATUTORY ENLISTMENT &amp; PROCUREMENT
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
              Registered Vendor Code &amp; Statutory Registrations
            </h2>
          </div>
          <div className="text-xs font-mono-tech text-slate-500">
            Govt. of India &amp; Gujarat Statutory Certifications
          </div>
        </div>

        {/* Official Registration Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {officialRegistrations.map((reg, idx) => (
            <div
              key={idx}
              className="bg-white rounded-md p-6 border border-slate-200 shadow-sm hover:border-[#F15A24] transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <span className="text-[10px] font-mono-tech uppercase font-bold text-slate-400">
                    REGISTRATION 0{idx + 1}
                  </span>
                  <span className="text-[10px] font-mono-tech text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
                    {reg.status}
                  </span>
                </div>

                <div>
                  <div className="text-[11px] font-mono-tech uppercase text-[#F15A24] font-bold">
                    {reg.authority}
                  </div>
                  <div className="text-xs text-slate-500 font-medium">
                    {reg.department}
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] uppercase font-mono-tech text-slate-400 font-semibold">
                    Registered Code / ID
                  </div>
                  <div className="text-lg font-black font-mono-tech text-slate-900 tracking-wider">
                    {reg.idNumber}
                  </div>
                  <div className="text-[11px] text-slate-600 font-medium mt-1">
                    {reg.type}
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {reg.notes}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono-tech text-slate-500">
                <span>Commencement:</span>
                <span className="font-bold text-slate-800">{reg.effectiveDate}</span>
              </div>
            </div>
          ))}
        </div>

        {/* National Industrial Classification (NIC) Approved Codes */}
        <div className="bg-white p-8 rounded-lg border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <span className="text-[11px] font-mono-tech uppercase text-[#F15A24] font-bold tracking-wider">
                MINISTRY OF MSME · CLASSIFICATION CODES
              </span>
              <h3 className="text-lg font-bold text-slate-900 font-sans tracking-tight">
                National Industry Classification (NIC 5-Digit) Activities
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-mono-tech">
              Udyog Aadhaar: GJ24D0009735
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {nicCodes.map((nic) => (
              <div
                key={nic.code}
                className="p-4 rounded border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-slate-300 transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2 py-0.5 rounded text-xs font-black font-mono-tech bg-[#0B1528] text-white">
                    NIC {nic.code}
                  </span>
                </div>
                <div className="font-bold text-xs text-slate-900 mb-1 font-sans">
                  {nic.heading}
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  {nic.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Key Statutory Personnel & Address Verification Strip */}
        <div className="bg-[#0B1528] text-white p-6 sm:p-8 rounded-lg border border-slate-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-1 max-w-2xl">
            <div className="text-xs font-mono-tech uppercase text-orange-400 font-bold">
              PROPRIETOR &amp; REGISTERED ENTERPRISE DETAILS
            </div>
            <div className="text-base font-bold text-white font-sans">
              M/s. Narayan Engineering · Key Principal: S. Narayan Mahto (Proprietor)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Officially acknowledged service enterprise operating from 36/842, Shivam Flats, Nr. Bhailalbhai Marriage Hall, New IPCL Road, Gorwa, Vadodara - 390016. All statutory registrations (EPFO, MSME, DIC) active and verified.
            </p>
          </div>

          <a
            href="#contact"
            className="shrink-0 inline-flex items-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white text-xs font-bold font-mono-tech uppercase px-5 py-3 rounded-sm transition-colors"
          >
            <span>VERIFY FOR TENDER</span>
            <CheckCircle2 size={14} />
          </a>
        </div>
      </div>
    </section>
  );
};

