import React, { useState, useEffect } from 'react';
import { ArrowUp, Phone, Mail } from 'lucide-react';
import { EnquiryModal } from './EnquiryModal';

export const BackToTop: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  if (!visible) return null;

  return (
    <>
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-2.5">
        {/* Floating Quick Enquiry Button */}
        <button
          type="button"
          onClick={() => setModalOpen(true)}
          className="w-11 h-11 rounded-full bg-[#F15A24] text-white flex items-center justify-center shadow-lg hover:bg-orange-600 transition-all focus:outline-none focus:ring-2 focus:ring-orange-400 cursor-pointer"
          aria-label="Enquire Now"
          title="Enquire Now"
        >
          <Mail size={18} />
        </button>

        {/* Quick Office Call Button */}
        <a
          href="tel:+919624017705"
          className="w-11 h-11 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg hover:bg-emerald-700 transition-all focus:outline-none focus:ring-2 focus:ring-emerald-400"
          aria-label="Call Office Narayan Engineering (+91 9624017705)"
          title="Call Office (+91 9624017705)"
        >
          <Phone size={18} />
        </a>

        {/* Back to top */}
        <button
          type="button"
          onClick={scrollToTop}
          className="w-11 h-11 rounded-full bg-[#0B1528] text-white flex items-center justify-center shadow-lg hover:bg-[#F15A24] transition-all focus:outline-none focus:ring-2 focus:ring-orange-400 cursor-pointer border border-slate-700"
          aria-label="Back to top"
          title="Back to top"
        >
          <ArrowUp size={18} />
        </button>
      </div>

      <EnquiryModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
