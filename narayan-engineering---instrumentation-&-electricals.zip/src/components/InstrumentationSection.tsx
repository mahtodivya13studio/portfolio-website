import React from 'react';
import { Gauge, Sliders, Box, Layers, Cable, Cpu, Pipette, CheckCircle, Users, Check, Sparkles, Activity, ShieldCheck } from 'lucide-react';
import { IMAGES } from '../assets/images';

interface InstrumentationItem {
  id: string;
  category: string;
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  exactText: string;
  highlight: string;
  image?: {
    src: string;
    alt: string;
    tag: string;
    specs: string;
  };
}

const instrumentationItems: InstrumentationItem[] = [
  {
    id: 'transmitters-gauges',
    category: 'Field Sensing & Measurement',
    title: 'Transmitters, Gauges & Switches',
    icon: Gauge,
    exactText: 'Installation of Transmitters, Gauges & Switches for Flow, Pressure, Temperature and Level applications.',
    highlight: 'Flow, Pressure, Temperature & Level',
    image: {
      src: IMAGES.transmitter.src,
      alt: IMAGES.transmitter.alt,
      tag: 'PRESSURE & LEVEL TRANSMITTERS',
      specs: 'HART Protocol · 4-20mA Output · 0-100 BAR',
    },
  },
  {
    id: 'valves',
    category: 'Final Control Elements',
    title: 'Control, ON/OFF & Safety Valves',
    icon: Sliders,
    exactText: 'Installations of all kind of Valves like Control Valves, ON/OFF Valves, Safety Valves, etc.',
    highlight: 'Control, ON/OFF & Safety Valves',
    image: {
      src: IMAGES.controlValves.src,
      alt: IMAGES.controlValves.alt,
      tag: 'PNEUMATIC & SMART ACTUATION',
      specs: 'Smart Digital Positioners · Class 300 / 600',
    },
  },
  {
    id: 'calibration-loop-check',
    category: 'Testing & Certification',
    title: 'Testing, Calibration & Loop Checking',
    icon: CheckCircle,
    exactText: 'Testing, Calibration & Loop Checking through fully trained & experienced Technician with Certified Testing Equipments.',
    highlight: 'Certified Master Test Equipments',
    image: {
      src: IMAGES.calibrationBench.src,
      alt: IMAGES.calibrationBench.alt,
      tag: 'NABL TRACEABLE CALIBRATION',
      specs: '5-Point Test Bench · Fluke Digital Calibrators',
    },
  },
  {
    id: 'manpower-supply',
    category: 'Technical Workforce',
    title: 'Engineers, Technicians & Manpower',
    icon: Users,
    exactText: 'Supply of Manpower like Experienced Engineers, Technicians & Unskilled Labours for Shutdown, Maintenance or for Installation & Commissioning Activities.',
    highlight: 'Shutdown, Maintenance & Installation Teams',
    image: {
      src: IMAGES.engineerOnSite.src,
      alt: IMAGES.engineerOnSite.alt,
      tag: 'TURNKEY FIELD CREWS',
      specs: '34+ Yrs Heritage · 100% Safety Compliance',
    },
  },
  {
    id: 'control-panels-dcs',
    category: 'Automation & Control Rooms',
    title: 'DCS, PLC, SCADA & Analyzer Panels',
    icon: Cpu,
    exactText: 'Installation of Marshalling Cabinets, DCS, PLC and SCADA System, Analyzer Panel including cabling, termination, assembling of panels and instrument air/gas tubing.',
    highlight: 'Cabinet Assembly, Cabling & Gas Tubing',
  },
  {
    id: 'tubing-welding',
    category: 'Impulse Piping & Tubing',
    title: 'SS/Copper Tubing & Argon Welding',
    icon: Pipette,
    exactText: 'Fabrication & Installation of SS Tube, Copper Tube, SS Pipe, CS Pipe with proper fitting & argon Welding.',
    highlight: 'SS, Copper, CS Piping with Argon Welding',
  },
  {
    id: 'junction-boxes',
    category: 'Field Distribution',
    title: 'Junction Boxes & Air Distribution Boxes',
    icon: Box,
    exactText: 'Installation of Junction Boxes & Air Distribution Boxes.',
    highlight: 'Junction Boxes & Air Headers',
  },
  {
    id: 'cable-tray',
    category: 'Containment Infrastructure',
    title: 'Cable Tray & Cable Duct Fabrication',
    icon: Layers,
    exactText: 'Fabrication & Installation of Cable Tray or Cable Duct.',
    highlight: 'Perforated, Ladder & Duct Fabrication',
  },
  {
    id: 'cabling-glanding',
    category: 'Signal Routing',
    title: 'Instrument Cable Laying & Termination',
    icon: Cable,
    exactText: 'Laying of Instrument Cable including Glanding & Termination.',
    highlight: 'Screened/Shielded Pair & Triad Cables',
  },
];

export const InstrumentationSection: React.FC = () => {
  return (
    <section id="instrumentation" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            CORE DISCIPLINE · M/S. NARAYAN ENGINEERING
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Field Instrumentation Services
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
            Comprehensive field instrumentation, smart sensor transmitters, pneumatic control valves, impulse line tubing, certified NABL calibration, and complete DCS loop commissioning for continuous process plants.
          </p>
        </div>

        {/* Industrial Visual Trio Showcase */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Transmitters */}
          <div className="group rounded-xl overflow-hidden border border-slate-200 bg-slate-900 text-white shadow-md hover:shadow-xl transition-all">
            <div className="relative h-48 sm:h-52 overflow-hidden">
              <img
                src={IMAGES.transmitter.src}
                alt={IMAGES.transmitter.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm">
                PRIMARY MEASUREMENT
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-xs">
                <div className="font-bold text-white text-sm font-sans">
                  Pressure, Differential &amp; Level Transmitters
                </div>
                <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5">
                  HART Protocol · 4-20mA · Hazardous Area Rated
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-900/90 text-xs text-slate-300 border-t border-slate-800 space-y-1">
              <div className="flex items-center justify-between text-slate-400 font-mono-tech text-[11px]">
                <span>Mounting: 2" Pipe / Manifold Skid</span>
                <span className="text-emerald-400 font-semibold">100% Tested</span>
              </div>
            </div>
          </div>

          {/* Card 2: Control Valves */}
          <div className="group rounded-xl overflow-hidden border border-slate-200 bg-slate-900 text-white shadow-md hover:shadow-xl transition-all">
            <div className="relative h-48 sm:h-52 overflow-hidden">
              <img
                src={IMAGES.controlValves.src}
                alt={IMAGES.controlValves.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute top-3 left-3 bg-blue-600 text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm">
                FINAL CONTROL ELEMENTS
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-xs">
                <div className="font-bold text-white text-sm font-sans">
                  Pneumatic Control &amp; Safety Relief Valves
                </div>
                <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5">
                  Smart Positioners · Stroke Checked · Hydro Tested
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-900/90 text-xs text-slate-300 border-t border-slate-800 space-y-1">
              <div className="flex items-center justify-between text-slate-400 font-mono-tech text-[11px]">
                <span>Piping: SS316 &amp; Carbon Steel</span>
                <span className="text-blue-400 font-semibold">Class 300 / 600</span>
              </div>
            </div>
          </div>

          {/* Card 3: Calibration */}
          <div className="group rounded-xl overflow-hidden border border-slate-200 bg-slate-900 text-white shadow-md hover:shadow-xl transition-all">
            <div className="relative h-48 sm:h-52 overflow-hidden">
              <img
                src={IMAGES.calibrationBench.src}
                alt={IMAGES.calibrationBench.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm">
                VERIFICATION &amp; QA
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-xs">
                <div className="font-bold text-white text-sm font-sans">
                  Certified Loop Testing &amp; 5-Point Calibration
                </div>
                <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5">
                  Fluke Digital Master Calibrators · NABL Traceable
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-900/90 text-xs text-slate-300 border-t border-slate-800 space-y-1">
              <div className="flex items-center justify-between text-slate-400 font-mono-tech text-[11px]">
                <span>Loop Validation: Cold &amp; Hot Loops</span>
                <span className="text-emerald-400 font-semibold">Zero Turnaround Error</span>
              </div>
            </div>
          </div>
        </div>

        {/* 9 Categorized Service Cards with Embedded Photo Integration */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {instrumentationItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="bg-slate-50/70 rounded-xl overflow-hidden border border-slate-200 hover:border-orange-500/40 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Optional Card Image Header */}
                  {item.image && (
                    <div className="relative h-36 w-full overflow-hidden border-b border-slate-200/90 group">
                      <img
                        src={item.image.src}
                        alt={item.image.alt}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                      <div className="absolute top-2 left-2 bg-slate-900/90 backdrop-blur-xs text-[#F15A24] border border-slate-700 text-[10px] font-mono-tech uppercase font-bold px-2 py-0.5 rounded">
                        {item.image.tag}
                      </div>
                      <div className="absolute bottom-2 left-2 right-2 text-[10px] font-mono-tech text-white truncate">
                        {item.image.specs}
                      </div>
                    </div>
                  )}

                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-mono-tech uppercase tracking-wide text-slate-500 bg-white border border-slate-200 px-2 py-1 rounded">
                        {item.category}
                      </span>
                      <span className="text-xs font-mono-tech text-slate-400 font-bold">
                        0{index + 1}
                      </span>
                    </div>

                    <div className="flex items-center gap-3.5 mb-3">
                      <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-[#F15A24] shadow-sm shrink-0">
                        <Icon size={22} />
                      </div>
                      <h3 className="font-bold text-base text-slate-900 font-sans leading-tight">
                        {item.title}
                      </h3>
                    </div>

                    <p className="text-sm text-slate-700 leading-relaxed font-normal bg-white/60 p-3 rounded-lg border border-slate-200/60 mt-3">
                      {item.exactText}
                    </p>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <div className="pt-4 border-t border-slate-200/70 flex items-center gap-2 text-xs font-medium text-slate-500">
                    <Check size={14} className="text-[#F15A24] shrink-0" />
                    <span className="truncate">{item.highlight}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

