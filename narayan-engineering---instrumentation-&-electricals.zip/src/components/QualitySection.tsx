import React from 'react';
import { Award, CheckCircle2, ShieldCheck, FileCheck, ArrowRight, UserCheck } from 'lucide-react';

const primaryObjectives = [
  'To establish and maintain a Quality Management System which satisfies the requirements of ISO 9001 :2015, and any other client specific quality requirements.',
  'To consistently provide services in a manner which will satisfy Client requirements in all respects.',
  'To implement appropriate actions to address any risks and opportunities associated with internal / external issues, and to meet the needs and expectations of Interested parties.',
  'To ensure all Company personnel are fully competent to carry out their assigned task.',
  'To strive to continually improve our services provided to clients, through the use of this Quality Policy, quality objectives performance evaluation including audit results, corrective actions and at Management Review.',
  'To establish annual quality objectives at strategic and operational levels within the Company, that will be measured and reported upon at the management review meeting.',
];

const continuingObjectives = [
  'To maintain documented information as objective evidence to demonstrate compliance with the Quality Management System.',
  'To control & continually monitor all projects undertaken.',
  'To comply with all applicable statutory and regulatory requirements.',
  'To review the Quality management System at planned intervals to ensure it is effective and achieving the stated quality policy.',
];

export const QualitySection: React.FC = () => {
  return (
    <section id="quality" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Governance &amp; Excellence
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Quality Policy
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            Structured quality management system satisfying ISO 9001:2015 and client-specific engineering specifications.
          </p>
        </div>

        {/* Quality Objectives Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          {/* Core Objectives (1 to 6) */}
          <div className="lg:col-span-7 bg-slate-50 rounded-xl p-8 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2.5 text-xs font-mono-tech uppercase font-bold text-[#F15A24] tracking-wide border-b border-slate-200 pb-3">
              <Award size={16} />
              Quality Management System Objectives
            </div>

            <ul className="space-y-4 pt-2">
              {primaryObjectives.map((obj, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm text-slate-700 leading-relaxed">
                  <div className="w-6 h-6 rounded-md bg-white border border-slate-300 text-slate-900 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                    {idx + 1}
                  </div>
                  <span>{obj}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Operational Governance & Continual Monitoring (7 to 10) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="bg-slate-50 rounded-xl p-8 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2.5 text-xs font-mono-tech uppercase font-bold text-slate-800 tracking-wide border-b border-slate-200 pb-3">
                <FileCheck size={16} className="text-[#F15A24]" />
                Compliance &amp; Project Monitoring
              </div>

              <ul className="space-y-3.5 pt-2">
                {continuingObjectives.map((obj, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-slate-700 leading-relaxed">
                    <div className="w-6 h-6 rounded-md bg-white border border-slate-300 text-slate-900 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                      {idx + 7}
                    </div>
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Formal Evaluation Note */}
            <div className="bg-emerald-50 border border-emerald-200/80 p-5 rounded-xl text-xs text-emerald-900 leading-relaxed">
              <span className="font-bold">Evaluation Standard: </span>
              “This Quality Policy is evaluated as part of the overall review of the quality Management system to ensure its stated objectives are met.”
            </div>
          </div>
        </div>

        {/* Senior Management Commitment Banner */}
        <div className="max-w-4xl mx-auto bg-[#0B1528] text-white rounded-xl p-8 border border-slate-800 shadow-md flex items-start gap-4">
          <div className="p-3 bg-orange-600/20 text-[#F15A24] rounded-lg shrink-0 mt-1">
            <UserCheck size={24} />
          </div>
          <div className="space-y-2">
            <div className="text-xs font-mono-tech uppercase text-orange-400 font-bold tracking-wider">
              Management Endorsement
            </div>
            <p className="text-sm sm:text-base text-slate-200 font-medium leading-relaxed italic">
              “The Senior management team are fully committed to the above and actively encourage a similar commitment by personnel at all levels of the Company.”
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
