import React, { useState } from 'react';
import { MapPin, Phone, Mail, Building, Send, CheckCircle2, Copy, Check, Clock, Loader2, Database } from 'lucide-react';
import { submitContactMessage } from '../lib/supabase';
import { BackendStatusModal } from './BackendStatusModal';

interface FormData {
  name: string;
  company: string;
  email: string;
  phone: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  phone?: string;
  message?: string;
}

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isBackendModalOpen, setIsBackendModalOpen] = useState(false);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your full name.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Please provide your contact phone number.';
    } else if (formData.phone.replace(/[^0-9]/g, '').length < 8) {
      newErrors.phone = 'Please enter a valid phone number (min 8 digits).';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Please provide your project or enquiry details.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters long.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      await submitContactMessage({
        name: formData.name,
        company: formData.company,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
      });
    } catch (err) {
      console.warn('Contact submission error:', err);
    } finally {
      setIsSubmitting(false);
      setSubmitted(true);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      company: '',
      email: '',
      phone: '',
      message: '',
    });
    setErrors({});
    setSubmitted(false);
  };

  return (
    <section id="contact" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Get in Touch
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Contact Us
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            Reach out for tenders, instrumentation &amp; electrical contracts, plant shutdowns, or manpower deputation enquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Official Contact Information */}
          <div className="lg:col-span-5 space-y-6">
            {/* Registered Office Card */}
            <div className="bg-white rounded-xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-orange-50 text-[#F15A24] shrink-0 mt-0.5">
                  <MapPin size={24} />
                </div>
                <div>
                  <div className="text-xs font-mono-tech uppercase text-slate-400 font-bold mb-1">
                    Registered Office
                  </div>
                  <h3 className="text-base font-bold text-slate-900 font-sans mb-2">
                    Narayan Engineering
                  </h3>
                  <address className="not-italic text-sm text-slate-700 leading-relaxed font-sans">
                    36/ 842, SHIVAM FLATS Nr.<br />
                    BHAILALBHAI MARRIAGE NEW IPCL<br />
                    ROAD, GORWA, VADODARA,<br />
                    GUJARAT 390016
                  </address>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>Location: Vadodara, Gujarat</span>
                <button
                  type="button"
                  onClick={() =>
                    copyToClipboard(
                      '36/ 842, SHIVAM FLATS Nr. BHAILALBHAI MARRIAGE NEW IPCL ROAD, GORWA, VADODARA, GUJARAT 390016',
                      'address'
                    )
                  }
                  className="inline-flex items-center gap-1 text-[#F15A24] hover:underline cursor-pointer"
                >
                  {copiedText === 'address' ? <Check size={12} /> : <Copy size={12} />}
                  <span>{copiedText === 'address' ? 'Copied' : 'Copy Address'}</span>
                </button>
              </div>

              <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs font-mono-tech">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 font-bold">GSTIN:</span>
                  <span className="font-bold text-slate-900 tracking-wider">24ACEPM8370P1Z1</span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard('24ACEPM8370P1Z1', 'gstin')}
                  className="inline-flex items-center gap-1 text-[#F15A24] hover:underline cursor-pointer"
                >
                  {copiedText === 'gstin' ? <Check size={12} /> : <Copy size={12} />}
                  <span>{copiedText === 'gstin' ? 'Copied' : 'Copy GST'}</span>
                </button>
              </div>

              <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs font-mono-tech">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 font-bold">ESIC:</span>
                  <span className="font-bold text-slate-900 tracking-wider">38240749840010999</span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard('38240749840010999', 'esic')}
                  className="inline-flex items-center gap-1 text-[#F15A24] hover:underline cursor-pointer"
                >
                  {copiedText === 'esic' ? <Check size={12} /> : <Copy size={12} />}
                  <span>{copiedText === 'esic' ? 'Copied' : 'Copy ESIC'}</span>
                </button>
              </div>
            </div>

            {/* Mobile Contact Numbers Card */}
            <div className="bg-white rounded-xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-blue-50 text-blue-900 shrink-0 mt-0.5">
                  <Phone size={24} />
                </div>
                <div className="w-full">
                  <div className="text-xs font-mono-tech uppercase text-slate-400 font-bold mb-1">
                    Direct Contact Numbers
                  </div>

                  {/* Mobile Numbers */}
                  <div className="mb-4">
                    <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 font-mono-tech">
                      Mobile:
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <a
                        href="tel:+919624017707"
                        className="inline-flex items-center justify-center gap-2 bg-slate-50 hover:bg-orange-50 border border-slate-200 hover:border-orange-300 text-slate-800 hover:text-[#F15A24] px-3.5 py-2 rounded-md text-sm font-semibold transition-colors"
                      >
                        <Phone size={14} className="text-[#F15A24]" />
                        +91 9624017707
                      </a>
                      <a
                        href="tel:+919913346418"
                        className="inline-flex items-center justify-center gap-2 bg-slate-50 hover:bg-orange-50 border border-slate-200 hover:border-orange-300 text-slate-800 hover:text-[#F15A24] px-3.5 py-2 rounded-md text-sm font-semibold transition-colors"
                      >
                        <Phone size={14} className="text-[#F15A24]" />
                        +91 99133 46418
                      </a>
                    </div>
                  </div>

                  {/* Office Contact Numbers */}
                  <div>
                    <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 font-mono-tech">
                      Office Contact:
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <a
                        href="tel:+919624017705"
                        className="inline-flex items-center justify-center gap-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 hover:text-blue-900 px-3.5 py-2 rounded-md text-sm font-semibold transition-colors"
                      >
                        <Phone size={14} className="text-blue-900" />
                        +91 9624017705
                      </a>
                      <a
                        href="tel:02652972379"
                        className="inline-flex items-center justify-center gap-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 hover:text-blue-900 px-3.5 py-2 rounded-md text-sm font-semibold transition-colors"
                      >
                        <Phone size={14} className="text-blue-900" />
                        0265-2972379
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Email Contact Card */}
            <div className="bg-white rounded-xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-emerald-50 text-emerald-800 shrink-0 mt-0.5">
                  <Mail size={24} />
                </div>
                <div className="w-full">
                  <div className="text-xs font-mono-tech uppercase text-slate-400 font-bold mb-1">
                    Official Email Addresses
                  </div>
                  <div className="space-y-2 mt-2">
                    <a
                      href="mailto:narayan_enggbaroda@yahoo.co.in"
                      className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 hover:bg-orange-50 border border-slate-200 hover:border-orange-300 text-sm font-medium text-slate-800 hover:text-[#F15A24] transition-colors"
                    >
                      <span className="truncate">narayan_enggbaroda@yahoo.co.in</span>
                      <Mail size={15} className="text-slate-400 shrink-0" />
                    </a>
                    <a
                      href="mailto:narayan.enggbaroda@gmail.com"
                      className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 hover:bg-orange-50 border border-slate-200 hover:border-orange-300 text-sm font-medium text-slate-800 hover:text-[#F15A24] transition-colors"
                    >
                      <span className="truncate">narayan.enggbaroda@gmail.com</span>
                      <Mail size={15} className="text-slate-400 shrink-0" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact / Enquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-xl p-8 sm:p-10 border border-slate-200 shadow-sm">
            <div className="border-b border-slate-100 pb-4 mb-6">
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-sans tracking-tight">
                Project &amp; Business Enquiry
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Submit your instrumentation or electrical scope details for a timely quotation and engineering review.
              </p>
            </div>

            {submitted ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-8 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 size={36} />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xl font-bold text-emerald-950 font-sans">
                    Enquiry Received Successfully
                  </h4>
                  <p className="text-sm text-emerald-800 max-w-md mx-auto">
                    Thank you, <span className="font-semibold">{formData.name}</span>. Your enquiry for <span className="font-semibold">{formData.company || 'your project'}</span> has been submitted to Narayan Engineering (Vadodara).
                  </p>
                </div>
                <div className="text-xs text-slate-600 bg-white p-3 rounded-lg border border-emerald-200/80 max-w-sm mx-auto space-y-1.5 shadow-xs">
                  <div className="font-semibold text-slate-800">
                    Transmitted to Engineering Project Desk
                  </div>
                  <div className="text-[11px] font-mono-tech text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 flex items-center justify-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Supabase Cloud Sync: hwxulckbvhdclrckqgdm</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={resetForm}
                  className="mt-4 inline-flex items-center justify-center bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-5 py-2.5 rounded-md transition-colors"
                >
                  Submit Another Enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <span className="text-xs font-mono-tech text-slate-500 uppercase font-semibold">
                    Direct Project &amp; Tender Inquiries
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsBackendModalOpen(true)}
                    className="inline-flex items-center gap-1.5 text-[11px] font-mono-tech text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded cursor-pointer transition-colors shadow-xs"
                    title="Click to view Supabase database connection and SQL schema"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-semibold">Supabase Connected: hwxulckbvhdclrckqgdm</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Name Field */}
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono-tech mb-1.5"
                    >
                      Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Ramesh Patel"
                      className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 ${
                        errors.name
                          ? 'border-red-400 focus:ring-red-300 bg-red-50/30'
                          : 'border-slate-300 focus:ring-orange-400 focus:border-orange-500'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.name}</p>
                    )}
                  </div>

                  {/* Company Field */}
                  <div>
                    <label
                      htmlFor="contact-company"
                      className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono-tech mb-1.5"
                    >
                      Company
                    </label>
                    <input
                      id="contact-company"
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="e.g. Process Plant / EPC Enterprise"
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-orange-500 transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Email Field */}
                  <div>
                    <label
                      htmlFor="contact-email"
                      className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono-tech mb-1.5"
                    >
                      Email <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@company.com"
                      className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 ${
                        errors.email
                          ? 'border-red-400 focus:ring-red-300 bg-red-50/30'
                          : 'border-slate-300 focus:ring-orange-400 focus:border-orange-500'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.email}</p>
                    )}
                  </div>

                  {/* Phone Field */}
                  <div>
                    <label
                      htmlFor="contact-phone"
                      className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono-tech mb-1.5"
                    >
                      Phone <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+91 98765 43210"
                      className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 ${
                        errors.phone
                          ? 'border-red-400 focus:ring-red-300 bg-red-50/30'
                          : 'border-slate-300 focus:ring-orange-400 focus:border-orange-500'
                      }`}
                    />
                    {errors.phone && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.phone}</p>
                    )}
                  </div>
                </div>

                {/* Message Field */}
                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono-tech mb-1.5"
                  >
                    Message <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Specify project scope, instrumentation/electrical requirements, location, and timelines..."
                    className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 ${
                      errors.message
                        ? 'border-red-400 focus:ring-red-300 bg-red-50/30'
                        : 'border-slate-300 focus:ring-orange-400 focus:border-orange-500'
                    }`}
                  />
                  {errors.message && (
                    <p className="text-xs text-red-600 mt-1 font-medium">{errors.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white font-bold text-sm px-8 py-3.5 rounded-md shadow transition-all disabled:opacity-70 cursor-pointer tracking-wider"
                >
                  {isSubmitting ? (
                    <span>Processing Enquiry...</span>
                  ) : (
                    <>
                      <span>Submit Enquiry</span>
                      <Send size={16} />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      <BackendStatusModal
        isOpen={isBackendModalOpen}
        onClose={() => setIsBackendModalOpen(false)}
      />
    </section>
  );
};
