import React, { useState } from 'react';
import { MapPin, Phone, Mail, ShieldCheck, Calendar, ArrowUp, Database, Shield } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';
import { BackendStatusModal } from './BackendStatusModal';
import { SUPABASE_PROJECT_ID } from '../lib/supabase';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  const [isBackendModalOpen, setIsBackendModalOpen] = useState(false);

  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#060D1A] text-slate-300 border-t border-slate-800 text-sm">
      {/* Main Footer Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-4">
            <CompanyLogo variant="footer" theme="dark" />

            <p className="text-xs text-slate-400 leading-relaxed pt-2">
              Narayan Engineering is an ISO 9001 Certified proprietary concern dealing with construction &amp; engineering activities for instrumentation and electrical jobs for various projects.
            </p>

            <div className="space-y-1.5 pt-2 text-xs font-mono-tech text-slate-400">
              <div className="flex items-center gap-2">
                <Calendar size={13} className="text-[#F15A24]" />
                <span>Established in 1991</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={13} className="text-[#F15A24]" />
                <span>Vadodara, Gujarat</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck size={13} className="text-emerald-400" />
                <span>ISO 9001:2015 Certified</span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <span className="text-slate-400 font-bold">GSTIN:</span>
                <span className="font-mono-tech text-white font-bold tracking-wider">24ACEPM8370P1Z1</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-bold">ESIC:</span>
                <span className="font-mono-tech text-slate-300 font-semibold tracking-wider">38240749840010999</span>
              </div>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold border-b border-slate-800 pb-2">
              Navigation
            </div>
            <ul className="grid grid-cols-2 gap-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => scrollTo('#home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#about')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#services')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#instrumentation')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Instrumentation
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#electrical')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Electrical
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#expertise')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Expertise
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#safety')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Safety Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#quality')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Quality Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#clients')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Clients
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#certification')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Certification
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('#contact')}
                  className="hover:text-[#F15A24] font-semibold transition-colors cursor-pointer"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Office Address Column */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold border-b border-slate-800 pb-2">
              Office Location
            </div>
            <address className="not-italic text-xs text-slate-400 leading-relaxed font-sans space-y-1">
              <span className="block font-semibold text-slate-300">Narayan Engineering</span>
              <span>36/ 842, SHIVAM FLATS Nr.</span>
              <span className="block">BHAILALBHAI MARRIAGE NEW IPCL</span>
              <span className="block">ROAD, GORWA, VADODARA,</span>
              <span className="block">GUJARAT 390016</span>
            </address>
          </div>

          {/* Contact Details Column */}
          <div className="lg:col-span-2 space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold border-b border-slate-800 pb-2">
              Communications
            </div>
            <div className="space-y-2 text-xs text-slate-400">
              <div>
                <div className="text-[11px] font-mono-tech text-slate-500 uppercase font-semibold">Mobile:</div>
                <div className="space-y-0.5 mt-0.5">
                  <a href="tel:+919624017707" className="block hover:text-[#F15A24] transition-colors">
                    +91 9624017707
                  </a>
                  <a href="tel:+919913346418" className="block hover:text-[#F15A24] transition-colors">
                    +91 99133 46418
                  </a>
                </div>
              </div>

              <div>
                <div className="text-[11px] font-mono-tech text-slate-500 uppercase font-semibold">Office Contact:</div>
                <div className="space-y-0.5 mt-0.5">
                  <a href="tel:+919624017705" className="block hover:text-[#F15A24] transition-colors">
                    +91 9624017705
                  </a>
                  <a href="tel:02652972379" className="block hover:text-[#F15A24] transition-colors">
                    0265-2972379
                  </a>
                </div>
              </div>

              <div>
                <div className="text-[11px] font-mono-tech text-slate-500 uppercase font-semibold">Email:</div>
                <div className="space-y-0.5 mt-0.5">
                  <a
                    href="mailto:narayan_enggbaroda@yahoo.co.in"
                    className="block truncate hover:text-[#F15A24] transition-colors"
                  >
                    narayan_enggbaroda@yahoo.co.in
                  </a>
                  <a
                    href="mailto:narayan.enggbaroda@gmail.com"
                    className="block truncate hover:text-[#F15A24] transition-colors"
                  >
                    narayan.enggbaroda@gmail.com
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} Narayan Engineering – Instrumentation and Electrical Works. All rights reserved. Vadodara, Gujarat (Established 1991).
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <button
              onClick={() => setIsBackendModalOpen(true)}
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-emerald-400 font-mono-tech transition-colors cursor-pointer"
              title="View Supabase backend sync status & SQL setup"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Supabase Cloud ({SUPABASE_PROJECT_ID})</span>
            </button>

            {onOpenAdmin && (
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 text-slate-400 hover:text-orange-400 font-mono-tech transition-colors cursor-pointer"
                title="Open Admin Operations Desk"
              >
                <Shield size={13} className="text-[#F15A24]" />
                <span>Admin Portal</span>
              </button>
            )}

            <span className="text-slate-400">
              ISO 9001:2015 Certified
            </span>

            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Scroll to top"
            >
              <span>Back to Top</span>
              <ArrowUp size={14} />
            </button>
          </div>
        </div>
      </div>

      <BackendStatusModal
        isOpen={isBackendModalOpen}
        onClose={() => setIsBackendModalOpen(false)}
      />
    </footer>
  );
};
