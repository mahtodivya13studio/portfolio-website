import React from 'react';
import { ShieldAlert, ShieldCheck, HardHat, AlertTriangle, Users, CheckCircle2 } from 'lucide-react';

const managementResponsibilities = [
  'A safe working environment.',
  'Plant and substances in safe condition & provide facilities for the welfare of workers.',
  'Information, instruction, training and supervision that is reasonably necessary to ensure that each worker is safe from injury and risks to health.',
  'A commitment to consult and co-operate with workers in all matters relating to health and safety in the workplace.',
  'A commitment to continually improve our performance through effective safety management.',
];

const workersResponsibilities = [
  'Comply with safe work practices, with the intent of avoiding injury to themselves and others and damage to plant and equipment.',
  'Take reasonable care of the health and safety of themselves and others.',
  'Wear personal protective equipment and clothing where necessary.',
  'Comply with any direction given by management for health and safety.',
  'Not misuse or interfere with anything provided for health and safety.',
  'Report all accidents and incidents on the job immediately.',
  'Report all known or observed hazards to their supervisor or manager.',
];

export const SafetySection: React.FC = () => {
  return (
    <section id="safety" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            HSE Standards
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Health &amp; Safety Policy
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
        </div>

        {/* Policy Introduction Quote */}
        <div className="max-w-4xl mx-auto bg-white border-l-4 border-emerald-600 p-6 sm:p-8 rounded-r-xl shadow-sm mb-12">
          <div className="flex items-center gap-3 text-emerald-800 font-bold text-sm uppercase tracking-wider mb-3">
            <ShieldCheck size={20} className="text-emerald-600" />
            Policy Commitment
          </div>
          <p className="text-slate-800 text-base sm:text-lg leading-relaxed font-medium">
            “Narayan Engineering is firmly committed to a policy enabling all work activities to be carried out safely, and with all possible measures taken to remove risk; to the health, safety and welfare of workers, supervisors, authorised visitors, and anyone else who may be affected by our operation.”
          </p>
        </div>

        {/* Management & Workers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Management Responsibilities */}
          <div className="bg-white rounded-xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
                <div className="p-2.5 rounded-lg bg-blue-50 text-blue-900 shrink-0">
                  <ShieldCheck size={22} />
                </div>
                <div>
                  <div className="text-xs uppercase font-mono-tech text-slate-400 font-bold">
                    Executive Governance
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 font-sans tracking-tight">
                    MANAGEMENT RESPONSIBILITIES
                  </h3>
                </div>
              </div>

              <ul className="space-y-3.5">
                {managementResponsibilities.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-slate-700 leading-relaxed">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-900 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Workers Responsibilities */}
          <div className="bg-white rounded-xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
                <div className="p-2.5 rounded-lg bg-orange-50 text-[#F15A24] shrink-0">
                  <HardHat size={22} />
                </div>
                <div>
                  <div className="text-xs uppercase font-mono-tech text-slate-400 font-bold">
                    Site Field Protocol
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 font-sans tracking-tight">
                    WORKERS
                  </h3>
                </div>
              </div>

              <ul className="space-y-3.5">
                {workersResponsibilities.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-slate-700 leading-relaxed">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-[#F15A24] text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Application of This Policy */}
        <div className="max-w-4xl mx-auto bg-[#0B1528] text-white rounded-xl p-8 border border-slate-800 shadow-lg">
          <div className="flex items-center gap-2 text-orange-400 font-bold text-xs uppercase font-mono-tech tracking-wider mb-3">
            <AlertTriangle size={16} />
            APPLICATION OF THIS POLICY
          </div>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            “We seek the co-operation of all workers, customers and other persons. We encourage suggestion for realising our health and safety objectives to create a safe working environment with a zero accident rate. This policy applies to all business operations and functions, including those situations where workers are required to work on-site.”
          </p>
        </div>
      </div>
    </section>
  );
};
