import React from 'react';
import { Package, Wrench, RefreshCw, Users, ShieldAlert, Sliders, ArrowRight, ChevronRight, CheckCircle2, Zap, Gauge, Activity, ShieldCheck } from 'lucide-react';
import { IMAGES } from '../assets/images';

interface ServiceItem {
  id: string;
  number: string;
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  description: string;
  linkAnchor: string;
  image?: {
    src: string;
    alt: string;
    tag: string;
  };
}

const servicesList: ServiceItem[] = [
  {
    id: 'material-supply',
    number: '01',
    title: 'Supply of Basic Project Materials',
    icon: Package,
    description: 'Procurement and delivery of project infrastructure including cable trays, cable ducts, junction boxes, conduits, air distribution manifolds, tubes, and installation fittings.',
    linkAnchor: '#instrumentation',
  },
  {
    id: 'erection-commissioning',
    number: '02',
    title: 'Erection & Commissioning',
    icon: Wrench,
    description: 'Complete mechanical and electrical erection, alignment, switchgear mounting, interconnection cabling, busbar torque checking, and system commissioning across industrial project sites.',
    linkAnchor: '#electrical',
    image: {
      src: IMAGES.electricalPanel.src,
      alt: IMAGES.electricalPanel.alt,
      tag: 'ELECTRICAL PANELS & SWITCHGEAR',
    },
  },
  {
    id: 'installation-loop-checking',
    number: '03',
    title: 'Installation, Loop Checking & Commissioning',
    icon: RefreshCw,
    description: 'Comprehensive installation of field instrumentation, stainless steel impulse tubing, process pressure gauges, rigorous loop checking with master calibrators, and DCS startup.',
    linkAnchor: '#instrumentation',
    image: {
      src: IMAGES.instrumentGauges.src,
      alt: IMAGES.instrumentGauges.alt,
      tag: 'GAUGES & PROCESS MANIFOLDS',
    },
  },
  {
    id: 'manpower-deputation',
    number: '04',
    title: 'Deputation of Skilled & Technical Manpower',
    icon: Users,
    description: 'Deputation of qualified site engineers, experienced calibration technicians, certified electricians, tube fitters, riggers, and unskilled manpower for project sites.',
    linkAnchor: '#manpower',
  },
  {
    id: 'shutdown-contracts',
    number: '05',
    title: 'Project, Maintenance & Shutdown Contracts',
    icon: ShieldAlert,
    description: 'Turnkey execution of planned plant turnaround/shutdown jobs, emergency field maintenance, transmitter revamping, retrofitting, and annual maintenance contracts (AMC).',
    linkAnchor: '#expertise',
    image: {
      src: IMAGES.fieldMaintenance.src,
      alt: IMAGES.fieldMaintenance.alt,
      tag: 'FIELD MAINTENANCE & OVERHAUL',
    },
  },
  {
    id: 'calibration-services',
    number: '06',
    title: 'Calibration & Loop Certification',
    icon: Sliders,
    description: 'Precision on-site and bench testing, calibration, and loop certification of pressure, temperature, flow, level instruments and control valves using master calibrated test benches.',
    linkAnchor: '#instrumentation',
    image: {
      src: IMAGES.calibrationBench.src,
      alt: IMAGES.calibrationBench.alt,
      tag: 'NABL TRACEABLE CALIBRATION',
    },
  },
];

const deliveryProcess = [
  {
    step: '01',
    title: 'PROCURE & SUPPLY',
    desc: 'Supply of certified project materials, trays, ducts, fittings & accessories.',
  },
  {
    step: '02',
    title: 'FABRICATION AND ERECTION WORK',
    desc: 'Precision structural fabrication and erection, panel placement, impulse tubing & cable routing.',
  },
  {
    step: '03',
    title: 'CALIBRATE & LOOP CHECK',
    desc: 'Rigorous bench and field testing with master calibrated test instruments.',
  },
  {
    step: '04',
    title: 'COMMISSION & HANDOVER',
    desc: 'Pre-commissioning verification, DCS/PLC loop simulation & hot plant startup.',
  },
];

export const ServicesSection: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      const topOffset = 75;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-8">
          <div>
            <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold mb-2">
              PROJECT EXECUTION SCOPE
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
              Services Offered
            </h2>
          </div>
          <p className="text-slate-600 text-sm max-w-lg leading-relaxed">
            Turnkey engineering, electrical switchgear erection, precision gauge installation, field maintenance overhauls, and continuous-process plant commissioning.
          </p>
        </div>

        {/* Featured Industrial Photography Showcase (Deep Navy & Safety Orange Theme) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#F15A24]" />
              <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-700 font-bold">
                CORE TECHNICAL DISCIPLINES IN ACTION
              </span>
            </div>
            <span className="text-xs font-mono-tech text-slate-500 hidden sm:inline">
              ISO 9001:2015 Verified Operations
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* 1. Electrical Switchgear Panels Card */}
            <div className="group rounded-xl overflow-hidden bg-[#070F1E] border border-slate-800 text-white shadow-xl hover:border-orange-500/60 transition-all flex flex-col justify-between">
              <div>
                <div className="relative h-52 sm:h-56 overflow-hidden">
                  <img
                    src={IMAGES.electricalPanel.src}
                    alt={IMAGES.electricalPanel.alt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070F1E] via-[#070F1E]/40 to-transparent" />
                  
                  {/* Top Badge */}
                  <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm flex items-center gap-1.5">
                    <Zap size={11} className="text-amber-200" />
                    <span>ELECTRICAL PANELS</span>
                  </div>

                  <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-xs border border-slate-700 text-slate-300 text-[10px] font-mono-tech px-2 py-0.5 rounded">
                    415V MCC / PCC
                  </div>

                  {/* Image Bottom Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 text-xs">
                    <div className="font-bold text-white text-base font-sans leading-tight">
                      Switchgear &amp; Motor Control Panels
                    </div>
                    <div className="text-[11px] text-orange-300 font-mono-tech mt-0.5">
                      Substation Breakers · Busbar Torque Checked
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    Complete installation, alignment, busbar coupling, and cable gland termination for HT/LT power distribution switchboards, MCC/PCC panels, and flameproof panels.
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2 text-[11px] font-mono-tech text-slate-300">
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      Megger &amp; Hi-Pot Testing
                    </span>
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      Relay &amp; ACB Checks
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  type="button"
                  onClick={() => scrollTo('#electrical')}
                  className="w-full py-2.5 px-3 rounded bg-slate-900 hover:bg-[#F15A24] text-slate-200 hover:text-white border border-slate-800 hover:border-orange-500 text-xs font-mono-tech uppercase font-bold tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>EXPLORE ELECTRICAL SCOPE</span>
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>

            {/* 2. Process Instrumentation Gauges Card */}
            <div className="group rounded-xl overflow-hidden bg-[#070F1E] border border-slate-800 text-white shadow-xl hover:border-orange-500/60 transition-all flex flex-col justify-between">
              <div>
                <div className="relative h-52 sm:h-56 overflow-hidden">
                  <img
                    src={IMAGES.instrumentGauges.src}
                    alt={IMAGES.instrumentGauges.alt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070F1E] via-[#070F1E]/40 to-transparent" />

                  {/* Top Badge */}
                  <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm flex items-center gap-1.5">
                    <Gauge size={11} className="text-amber-200" />
                    <span>PROCESS GAUGES</span>
                  </div>

                  <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-xs border border-slate-700 text-slate-300 text-[10px] font-mono-tech px-2 py-0.5 rounded">
                    0-250 kg/cm²
                  </div>

                  {/* Image Bottom Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 text-xs">
                    <div className="font-bold text-white text-base font-sans leading-tight">
                      Instrumentation Gauges &amp; Manifolds
                    </div>
                    <div className="text-[11px] text-orange-300 font-mono-tech mt-0.5">
                      SS316 Dial Gauges · 2/3/5-Way Manifold Hookups
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    Precision installation of Bourdon tube process pressure gauges, differential indicators, digital dials, and stainless steel impulse tubing manifolds with argon welding.
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2 text-[11px] font-mono-tech text-slate-300">
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      5-Point Calibration
                    </span>
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      Hydrostatic Tested
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  type="button"
                  onClick={() => scrollTo('#instrumentation')}
                  className="w-full py-2.5 px-3 rounded bg-slate-900 hover:bg-[#F15A24] text-slate-200 hover:text-white border border-slate-800 hover:border-orange-500 text-xs font-mono-tech uppercase font-bold tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>EXPLORE GAUGES SCOPE</span>
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>

            {/* 3. Field Maintenance Operations Card */}
            <div className="group rounded-xl overflow-hidden bg-[#070F1E] border border-slate-800 text-white shadow-xl hover:border-orange-500/60 transition-all flex flex-col justify-between">
              <div>
                <div className="relative h-52 sm:h-56 overflow-hidden">
                  <img
                    src={IMAGES.fieldMaintenance.src}
                    alt={IMAGES.fieldMaintenance.alt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070F1E] via-[#070F1E]/40 to-transparent" />

                  {/* Top Badge */}
                  <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm flex items-center gap-1.5">
                    <Activity size={11} className="text-amber-200" />
                    <span>FIELD MAINTENANCE</span>
                  </div>

                  <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-xs border border-slate-700 text-slate-300 text-[10px] font-mono-tech px-2 py-0.5 rounded">
                    24/7 Turnaround
                  </div>

                  {/* Image Bottom Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 text-xs">
                    <div className="font-bold text-white text-base font-sans leading-tight">
                      Field Maintenance &amp; Plant Overhaul
                    </div>
                    <div className="text-[11px] text-orange-300 font-mono-tech mt-0.5">
                      Shutdown Crews · Loop Diagnostics &amp; Servicing
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    Scheduled preventive maintenance, emergency plant turnaround operations, transmitter recertification, junction box servicing, and zero-delay loop recommissioning.
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2 text-[11px] font-mono-tech text-slate-300">
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      Emergency Mobilization
                    </span>
                    <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800 flex items-center gap-1">
                      <CheckCircle2 size={12} className="text-[#F15A24]" />
                      Certified Technicians
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  type="button"
                  onClick={() => scrollTo('#expertise')}
                  className="w-full py-2.5 px-3 rounded bg-slate-900 hover:bg-[#F15A24] text-slate-200 hover:text-white border border-slate-800 hover:border-orange-500 text-xs font-mono-tech uppercase font-bold tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>EXPLORE SHUTDOWN SCOPE</span>
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Delivery Process Ribbon (A PROVEN APPROACH. CONSISTENT RESULTS.) */}
        <div className="bg-white p-6 sm:p-8 rounded-lg border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <span className="text-[11px] font-mono-tech uppercase text-[#F15A24] font-bold tracking-wider">
                ENGINEERING EXECUTION FLOW
              </span>
              <h3 className="text-lg font-bold text-slate-900 font-sans tracking-tight">
                A PROVEN APPROACH. CONSISTENT RESULTS.
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-mono-tech">
              ISO 9001:2015 Process Adherence
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {deliveryProcess.map((proc, index) => (
              <div key={proc.step} className="relative flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-2xl font-black font-sans text-[#F15A24]">
                      {proc.step}
                    </span>
                    {index < 3 && (
                      <span className="hidden lg:block text-slate-300">
                        <ChevronRight size={20} />
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 font-sans tracking-wide uppercase mb-1">
                    {proc.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {proc.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 6 Core Service Cards (Vertex Clean Industrial Card Grid with Photographic Badges) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesList.map((svc) => {
            const Icon = svc.icon;
            return (
              <div
                key={svc.id}
                className="bg-white rounded-md overflow-hidden border border-slate-200 shadow-sm hover:border-[#F15A24] hover:shadow-lg transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Photo Header if available */}
                  {svc.image && (
                    <div className="relative h-36 w-full overflow-hidden border-b border-slate-100">
                      <img
                        src={svc.image.src}
                        alt={svc.image.alt}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                      <div className="absolute top-2 left-2 bg-[#070F1E]/90 backdrop-blur-xs text-[#F15A24] border border-slate-700 text-[10px] font-mono-tech uppercase font-bold px-2 py-0.5 rounded">
                        {svc.image.tag}
                      </div>
                    </div>
                  )}

                  <div className="p-7">
                    <div className="flex items-center justify-between mb-5">
                      <span className="text-xs font-mono-tech font-bold text-slate-900 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-sm">
                        SERVICE {svc.number}
                      </span>
                      <div className="w-11 h-11 rounded-md bg-orange-50/80 border border-orange-100 flex items-center justify-center text-[#F15A24] group-hover:bg-[#F15A24] group-hover:text-white transition-all shadow-xs">
                        <Icon size={20} />
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900 font-sans tracking-tight mb-3 group-hover:text-[#F15A24] transition-colors leading-snug">
                      {svc.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {svc.description}
                    </p>
                  </div>
                </div>

                <div className="p-7 pt-0">
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => scrollTo(svc.linkAnchor)}
                      className="inline-flex items-center gap-1.5 text-xs font-bold font-mono-tech uppercase text-slate-800 hover:text-[#F15A24] transition-colors cursor-pointer group-hover:translate-x-1"
                    >
                      <span>VIEW SCOPE</span>
                      <ArrowRight size={13} className="text-[#F15A24]" />
                    </button>
                    <span className="text-[10px] font-mono-tech text-slate-400 uppercase">
                      ESTD 1991
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};


