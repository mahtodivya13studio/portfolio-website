import React from 'react';
import {
  Calendar,
  MapPin,
  Award,
  CheckCircle2,
  ShieldCheck,
  Target,
  ArrowRight,
  FileCheck,
  Building,
  UserCheck,
  Briefcase,
  Activity,
} from 'lucide-react';
import { CompanyLogo, OfficialLogoMark } from './CompanyLogo';
import { IMAGES } from '../assets/images';

export const AboutSection: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const topOffset = 75;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-20 lg:py-24 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="border-b border-slate-200 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-bold mb-1 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F15A24]" />
              ESTABLISHED 01/04/1991 · VADODARA, GUJARAT
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
              About Narayan Engineering
            </h2>
          </div>
          <div className="text-xs font-mono-tech text-slate-500 bg-slate-50 px-3.5 py-1.5 rounded border border-slate-200">
            Proprietary Concern · ISO 9001:2015 Certified
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Official Profile Prose */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-slate-50 border-l-4 border-[#F15A24] p-6 sm:p-7 rounded-r-lg shadow-xs">
              <p className="text-slate-800 text-lg sm:text-xl leading-relaxed font-semibold">
                “M/s. Narayan Engineering an ISO 9001 Certified company is a proprietary concern dealing with construction &amp; engineering activities for the instrumentation and electrical jobs for various projects.”
              </p>
            </div>

            <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
              “From our very first job we have maintained a good relationship with our clients, provided quality work &amp; timely completion of the entrusted jobs to us.”
            </p>

            {/* Company Objective Box */}
            <div className="bg-[#0B1528] text-white p-6 sm:p-7 rounded-lg space-y-2.5 border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-600/10 rounded-full blur-2xl pointer-events-none" />
              <div className="flex items-center gap-2 text-orange-400 font-bold text-xs uppercase tracking-wider font-mono-tech">
                <Target size={17} />
                COMPANY OBJECTIVE
              </div>
              <p className="text-slate-200 text-base sm:text-lg font-semibold italic leading-relaxed">
                “To satisfy our Clients &amp; Consultants by giving committed schedule and Quality assured performance.”
              </p>
            </div>

            {/* Core Verification Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/80 hover:bg-white hover:border-orange-500/40 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-slate-400 font-mono-tech font-bold">ESTABLISHED</div>
                <div className="text-sm sm:text-base font-extrabold text-slate-900 font-sans mt-0.5">01/04/1991</div>
                <div className="text-[10px] text-slate-500 font-mono-tech mt-1">35+ Yrs Heritage</div>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/80 hover:bg-white hover:border-orange-500/40 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-slate-400 font-mono-tech font-bold">PROPRIETOR</div>
                <div className="text-xs sm:text-sm font-extrabold text-slate-900 font-sans mt-0.5 truncate" title="S. Narayan Mahto">
                  S. Narayan Mahto
                </div>
                <div className="text-[10px] text-slate-500 font-mono-tech mt-1">Founder &amp; Head</div>
              </div>

              <div className="p-3.5 rounded-lg border border-orange-200 bg-orange-50/60 hover:bg-white hover:border-orange-500 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-[#F15A24] font-mono-tech font-bold">GSTIN NUMBER</div>
                <div className="text-xs sm:text-sm font-extrabold font-mono-tech text-slate-900 mt-0.5 tracking-tight">
                  24ACEPM8370P1Z1
                </div>
                <div className="text-[10px] text-[#F15A24] font-mono-tech mt-1 font-semibold">Gujarat (State 24)</div>
              </div>

              <div className="p-3.5 rounded-lg border border-emerald-200 bg-emerald-50/60 hover:bg-white hover:border-emerald-500 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-emerald-700 font-mono-tech font-bold">ESIC CODE</div>
                <div className="text-[11px] sm:text-xs font-extrabold font-mono-tech text-slate-900 mt-0.5 tracking-tighter truncate" title="38240749840010999">
                  38240749840010999
                </div>
                <div className="text-[10px] text-emerald-700 font-mono-tech mt-1 font-semibold">Labour ESI Act</div>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/80 hover:bg-white hover:border-orange-500/40 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-slate-400 font-mono-tech font-bold">MSME UAN</div>
                <div className="text-xs sm:text-sm font-extrabold font-mono-tech text-slate-900 mt-0.5">GJ24D0009735</div>
                <div className="text-[10px] text-slate-500 font-mono-tech mt-1">Govt of India</div>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/80 hover:bg-white hover:border-orange-500/40 hover:shadow-md transition-all text-center">
                <div className="text-[10px] uppercase text-slate-400 font-mono-tech font-bold">EPFO CODE</div>
                <div className="text-xs sm:text-sm font-extrabold font-mono-tech text-slate-900 mt-0.5">GJ / 20100</div>
                <div className="text-[10px] text-slate-500 font-mono-tech mt-1">Baroda Region</div>
              </div>
            </div>
          </div>

          {/* Right Column: Corporate Visual Card & Technical Commitments */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#0B1528] text-white rounded-xl shadow-2xl border border-slate-800 overflow-hidden">
              {/* Authentic On-Site Instrumentation Engineer Photograph */}
              <div className="relative h-52 sm:h-56 overflow-hidden group">
                <img
                  src={IMAGES.engineerOnSite.src}
                  alt={IMAGES.engineerOnSite.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1528] via-[#0B1528]/40 to-transparent" />
                <div className="absolute top-3 left-3 bg-[#F15A24] text-white text-[10px] font-mono-tech uppercase font-bold px-2.5 py-1 rounded shadow-sm">
                  ON-SITE ENGINEERING FIELD TEAMS
                </div>
                <div className="absolute bottom-3 left-4 right-4 text-xs">
                  <div className="font-bold text-white text-base font-sans">
                    34+ Years of Proven EPC Execution
                  </div>
                  <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5">
                    Field Telemetry · DCS Interfacing · Refinery Compliance
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-7 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                  <span className="text-xs uppercase font-mono-tech tracking-wider text-orange-400 font-bold flex items-center gap-1.5">
                    <FileCheck size={14} />
                    STATUTORY CREDENTIALS
                  </span>
                  <span className="text-xs font-mono-tech text-slate-400">
                    DIC Vadodara: EM-II 5816
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="text-xl font-bold font-sans text-white">
                    Narayan Engineering
                  </div>
                  <div className="text-xs font-mono-tech text-orange-400">
                    Proprietor: S. Narayan Mahto
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Executing specialized construction &amp; engineering activities for instrumentation and electrical jobs across continuous-process plant sites.
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800 space-y-2.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>Proprietary Concern established 01/04/1991</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>GSTIN: <strong className="text-white font-mono-tech">24ACEPM8370P1Z1</strong> (State 24 - Gujarat)</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>Ministry of MSME Registered (UAN: GJ24D0009735)</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>EPFO Statutory Code: GJ / 20100 (Effective 1991)</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>ESIC Employer Code: <strong className="text-white font-mono-tech">38240749840010999</strong> (ESI Act, 1948)</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} className="text-[#F15A24] shrink-0" />
                    <span>ISO 9001:2015 Quality Management System</span>
                  </div>
                </div>

                <div className="pt-2">
                  <CompanyLogo variant="badge" className="w-full justify-center" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
