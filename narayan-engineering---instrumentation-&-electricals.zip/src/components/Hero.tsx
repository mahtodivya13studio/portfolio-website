import React, { useState } from 'react';
import {
  ShieldCheck,
  Calendar,
  ArrowRight,
  Phone,
  Building2,
  Sliders,
  Cpu,
  Zap,
  Activity,
  FileText,
  CheckCircle2,
  Clock,
  Layers,
  Sparkles,
  ChevronRight,
  Flame,
  Gauge,
  Pipette,
  Check,
} from 'lucide-react';
import { CompanyLogo, OfficialLogoMark } from './CompanyLogo';
import { EnquiryModal } from './EnquiryModal';
import { IMAGES } from '../assets/images';

export const Hero: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'instrumentation' | 'electrical' | 'turnaround'>('instrumentation');
  const [activeInstrument, setActiveInstrument] = useState<'transmitter' | 'gauges' | 'valves' | 'calibration'>('transmitter');
  const [rfqModalOpen, setRfqModalOpen] = useState(false);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const topOffset = 75;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  const clientLogos = [
    { name: 'MRPL', sector: 'Petroleum Refining', tag: 'Mangalore Refinery' },
    { name: 'IOCL GUJARAT REFINERY', sector: 'Refinery & Petrochem', tag: 'Vadodara Refinery' },
    { name: 'NAYARA ENERGY', sector: 'Hydrocarbon Refining', tag: 'Vadinar Refinery' },
    { name: 'ABB INDIA', sector: 'Automation & Power', tag: 'Industrial Technology' },
    { name: 'RELIANCE INDUSTRIES', sector: 'Petrochemical & Energy', tag: 'Dahej / Hazira Units' },
    { name: 'GAIL (INDIA) LIMITED', sector: 'Natural Gas & Polymers', tag: 'Petrochemical Complex' },
  ];

  const instrumentDetails = {
    transmitter: {
      image: IMAGES.transmitter.src,
      alt: IMAGES.transmitter.alt,
      tag: 'PRESSURE & DIFFERENTIAL SENSORS',
      name: 'Smart Pressure Transmitter',
      protocol: 'HART / 4-20mA Output',
      range: '0 – 100 BAR · Class 1 Div 1',
      badge: 'Calibrated & Loop Verified',
    },
    gauges: {
      image: IMAGES.instrumentGauges.src,
      alt: IMAGES.instrumentGauges.alt,
      tag: 'PROCESS GAUGES & MANIFOLDS',
      name: 'Precision Pressure Gauges & Dials',
      protocol: 'SS316 Bourdon Tube · Dual Scale',
      range: '0 – 250 kg/cm² · 2/3/5-Way Manifold',
      badge: 'Hydro Tested & Master Verified',
    },
    valves: {
      image: IMAGES.controlValves.src,
      alt: IMAGES.controlValves.alt,
      tag: 'FINAL CONTROL ELEMENTS',
      name: 'Pneumatic Control Valves',
      protocol: 'Smart Electro-Pneumatic Positioner',
      range: 'Class 300 / 600 · SS316 Trim',
      badge: 'Stroke Tested & Hydro Verified',
    },
    calibration: {
      image: IMAGES.calibrationBench.src,
      alt: IMAGES.calibrationBench.alt,
      tag: 'FIELD TESTING & VERIFICATION',
      name: 'NABL Certified Loop Calibration',
      protocol: '5-Point Sensor Calibration',
      range: 'Process Calibrators & Test Bench',
      badge: '100% QA Inspection Tagged',
    },
  };

  return (
    <section id="home" className="relative bg-[#060D1A] text-white overflow-hidden border-b border-slate-800">
      {/* Cinematic Refinery Factory Photograph & Blueprint Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Real Refinery Factory Photo with Dusk Lighting */}
        <img
          src={IMAGES.heroBanner.src}
          alt={IMAGES.heroBanner.alt}
          className="w-full h-full object-cover object-center opacity-30 scale-105 transition-transform duration-1000"
        />

        {/* Deep Industrial Gradient Layers for Contrast & Legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#060D1A] via-[#060D1A]/92 to-[#060D1A]/75" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#060D1A]/95 via-transparent to-[#060D1A]" />

        {/* Industrial Blueprint Subtle Grid */}
        <div className="absolute inset-0 opacity-15">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="industrial-blueprint" width="60" height="60" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#60A5FA" strokeWidth="0.5" strokeOpacity="0.18" />
                <circle cx="0" cy="0" r="1.5" fill="#F15A24" fillOpacity="0.4" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#industrial-blueprint)" />
          </svg>
        </div>

        {/* Atmospheric Glow Highlights */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-700/10 rounded-full blur-3xl" />
        <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-orange-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-1/3 w-80 h-80 bg-emerald-600/5 rounded-full blur-2xl" />
      </div>

      {/* Main Hero Container */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 sm:pt-16 lg:pt-20 pb-16 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Industrial Authority, Headline & Call to Action */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-7 text-center sm:text-left">
            
            {/* Status & Credential Pills */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
              <span className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-wider text-orange-300 bg-orange-950/40 border border-orange-700/50 px-3 py-1.5 rounded-sm shadow-sm">
                <span className="w-2 h-2 rounded-full bg-[#F15A24] animate-pulse" />
                <span>ESTABLISHED 1991 · VADODARA, GUJARAT</span>
              </span>

              <span className="inline-flex items-center gap-1.5 text-xs font-mono-tech uppercase tracking-wider text-slate-300 bg-slate-900/80 border border-slate-700 px-3 py-1.5 rounded-sm shadow-sm">
                <ShieldCheck size={14} className="text-emerald-400" />
                <span>ISO 9001:2015 CERTIFIED</span>
              </span>
            </div>

            {/* Headline Block */}
            <div className="space-y-2 sm:space-y-3">
              <div className="text-xs sm:text-sm font-mono-tech uppercase tracking-[0.22em] text-slate-400 font-semibold">
                M/S. NARAYAN ENGINEERING · INSTRUMENTATION AND ELECTRICAL WORKS
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold tracking-tight uppercase font-sans leading-[1.04]">
                REDEFINING{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-[#F15A24] to-amber-300">
                  AUTOMATION.
                </span>
              </h1>

              <div className="text-lg sm:text-2xl font-bold text-slate-200 tracking-wide uppercase font-sans">
                Instrumentation and Electrical Works
              </div>
            </div>

            {/* Authoritative Mission Paragraph */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal max-w-2xl">
              Narayan Engineering is an ISO 9001 Certified company dealing with construction &amp; engineering activities for instrumentation and electrical jobs for various projects across refineries, petrochemical complexes, chemical plants, and heavy industrial facilities.
            </p>

            {/* Key Assurance Bullet Points */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <CheckCircle2 size={16} className="text-[#F15A24] shrink-0" />
                <span>Turnkey Field Instrumentation &amp; Loop Checks</span>
              </div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <CheckCircle2 size={16} className="text-[#F15A24] shrink-0" />
                <span>HT/LT Industrial Electrical Power Distribution</span>
              </div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <CheckCircle2 size={16} className="text-[#F15A24] shrink-0" />
                <span>Rapid Plant Shutdown &amp; Turnaround Overhauls</span>
              </div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <CheckCircle2 size={16} className="text-[#F15A24] shrink-0" />
                <span>100% Certified Technical Workforce &amp; Tooling</span>
              </div>
            </div>

            {/* High-Impact Actions */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
              <button
                onClick={() => setRfqModalOpen(true)}
                className="inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-[#F15A24] to-orange-600 hover:from-orange-500 hover:to-orange-700 text-white font-bold text-sm uppercase px-7 py-4 rounded-sm shadow-xl shadow-orange-950/50 transition-all hover:translate-y-[-1px] cursor-pointer tracking-wider"
              >
                <FileText size={17} />
                <span>ENQUIRE NOW / REQUEST RFQ</span>
              </button>

              <button
                onClick={() => scrollTo('services')}
                className="inline-flex items-center justify-center gap-2 bg-slate-900/90 hover:bg-slate-800 text-white font-bold text-sm uppercase px-6 py-4 rounded-sm border border-slate-700 hover:border-slate-500 transition-all cursor-pointer tracking-wider"
              >
                <span>EXPLORE SERVICES</span>
                <ArrowRight size={16} />
              </button>
            </div>

            {/* Core Capability Photographic Pills (Deep Navy & Orange) */}
            <div className="pt-2 grid grid-cols-3 gap-2 max-w-xl">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('electrical');
                }}
                className="group p-2 rounded bg-slate-900/90 border border-slate-700/80 hover:border-[#F15A24] transition-all text-left flex items-center gap-2 cursor-pointer"
              >
                <img
                  src={IMAGES.electricalPanel.src}
                  alt={IMAGES.electricalPanel.alt}
                  className="w-9 h-9 rounded object-cover border border-slate-700 shrink-0 group-hover:scale-105 transition-transform"
                />
                <div className="min-w-0">
                  <div className="text-[10px] font-mono-tech text-orange-400 font-bold uppercase truncate">
                    01. PANELS
                  </div>
                  <div className="text-xs font-bold text-slate-200 truncate">
                    HT/LT Switchgear
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('instrumentation');
                  setActiveInstrument('gauges');
                }}
                className="group p-2 rounded bg-slate-900/90 border border-slate-700/80 hover:border-[#F15A24] transition-all text-left flex items-center gap-2 cursor-pointer"
              >
                <img
                  src={IMAGES.instrumentGauges.src}
                  alt={IMAGES.instrumentGauges.alt}
                  className="w-9 h-9 rounded object-cover border border-slate-700 shrink-0 group-hover:scale-105 transition-transform"
                />
                <div className="min-w-0">
                  <div className="text-[10px] font-mono-tech text-orange-400 font-bold uppercase truncate">
                    02. GAUGES
                  </div>
                  <div className="text-xs font-bold text-slate-200 truncate">
                    Process Dials
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('turnaround');
                }}
                className="group p-2 rounded bg-slate-900/90 border border-slate-700/80 hover:border-[#F15A24] transition-all text-left flex items-center gap-2 cursor-pointer"
              >
                <img
                  src={IMAGES.fieldMaintenance.src}
                  alt={IMAGES.fieldMaintenance.alt}
                  className="w-9 h-9 rounded object-cover border border-slate-700 shrink-0 group-hover:scale-105 transition-transform"
                />
                <div className="min-w-0">
                  <div className="text-[10px] font-mono-tech text-orange-400 font-bold uppercase truncate">
                    03. FIELD CREWS
                  </div>
                  <div className="text-xs font-bold text-slate-200 truncate">
                    Maintenance
                  </div>
                </div>
              </button>
            </div>

            {/* Direct Telephone Hotline Bar */}
            <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs font-mono-tech text-slate-400">
              <div className="flex items-center gap-2">
                <Phone size={13} className="text-[#F15A24]" />
                <span>OFFICE:</span>
                <a href="tel:+919624017705" className="text-white hover:text-orange-400 font-bold">
                  +91 9624017705
                </a>
              </div>
              <span className="hidden sm:inline text-slate-600">•</span>
              <div className="flex items-center gap-1.5">
                <span>DIRECT:</span>
                <a href="tel:+919624017707" className="text-slate-300 hover:text-orange-400 font-semibold">
                  +91 9624017707
                </a>
                <span>/</span>
                <a href="tel:+919913346418" className="text-slate-300 hover:text-orange-400 font-semibold">
                  +91 99133 46418
                </a>
              </div>
              <span className="hidden sm:inline text-slate-600">•</span>
              <div className="text-slate-400">
                LL: 0265-2972379
              </div>
            </div>

          </div>

          {/* Right Column: Industrial Project Capabilities Console (Interactive Tech Cockpit) */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto w-full max-w-lg lg:max-w-none">
              
              {/* Outer Radiant Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-orange-500/30 via-blue-500/20 to-emerald-500/20 rounded-xl blur-lg opacity-75" />

              {/* Console Container */}
              <div className="relative bg-[#0B1528] rounded-xl border border-slate-700/80 shadow-2xl overflow-hidden backdrop-blur-xl">
                
                {/* Console Top Plaque / Brand Stamp */}
                <div className="bg-[#070E1B] px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <OfficialLogoMark size={28} color="#F15A24" />
                    <div>
                      <div className="text-xs font-bold font-sans tracking-wide text-white">
                        NARAYAN ENGINEERING
                      </div>
                      <div className="text-[10px] font-mono-tech text-orange-400 uppercase tracking-wider">
                        Instrumentation &amp; Electrical Works
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-600/40 text-emerald-400 text-[10px] font-mono-tech uppercase px-2.5 py-1 rounded">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>MOBILIZATION READY</span>
                  </div>
                </div>

                {/* Interactive Mode Tabs */}
                <div className="grid grid-cols-3 bg-[#0A1222] border-b border-slate-800 p-1 gap-1">
                  <button
                    onClick={() => setActiveTab('instrumentation')}
                    className={`py-2.5 px-2 text-center text-xs font-mono-tech font-bold uppercase tracking-wider rounded transition-all cursor-pointer flex flex-col items-center gap-1 ${
                      activeTab === 'instrumentation'
                        ? 'bg-[#F15A24] text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Sliders size={15} />
                    <span className="truncate">01. INSTRUMENT</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('electrical')}
                    className={`py-2.5 px-2 text-center text-xs font-mono-tech font-bold uppercase tracking-wider rounded transition-all cursor-pointer flex flex-col items-center gap-1 ${
                      activeTab === 'electrical'
                        ? 'bg-[#F15A24] text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Zap size={15} />
                    <span className="truncate">02. ELECTRICAL</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('turnaround')}
                    className={`py-2.5 px-2 text-center text-xs font-mono-tech font-bold uppercase tracking-wider rounded transition-all cursor-pointer flex flex-col items-center gap-1 ${
                      activeTab === 'turnaround'
                        ? 'bg-[#F15A24] text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Clock size={15} />
                    <span className="truncate">03. SHUTDOWN</span>
                  </button>
                </div>

                {/* Tab Dynamic Body */}
                <div className="p-5 sm:p-6 space-y-4">
                  {activeTab === 'instrumentation' && (
                    <div className="space-y-4 animate-in fade-in duration-200">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="text-[11px] font-mono-tech text-orange-400 uppercase tracking-widest font-semibold">
                            CORE DISCIPLINE · 01
                          </div>
                          <h3 className="text-lg sm:text-xl font-bold font-sans text-white mt-0.5">
                            Turnkey Instrumentation Systems
                          </h3>
                        </div>
                        <span className="text-[10px] font-mono-tech bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                          Continuous Process
                        </span>
                      </div>

                      {/* Interactive Instrument Photo Showcase */}
                      <div className="rounded-lg overflow-hidden border border-slate-700/80 bg-slate-950">
                        {/* Instrument Selector Pill Row */}
                        <div className="grid grid-cols-4 bg-slate-900 border-b border-slate-800 text-[10px] font-mono-tech">
                          <button
                            type="button"
                            onClick={() => setActiveInstrument('transmitter')}
                            className={`py-1.5 px-1 text-center transition-colors truncate cursor-pointer ${
                              activeInstrument === 'transmitter'
                                ? 'bg-[#F15A24] text-white font-bold'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Transmitters
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveInstrument('gauges')}
                            className={`py-1.5 px-1 text-center transition-colors truncate cursor-pointer ${
                              activeInstrument === 'gauges'
                                ? 'bg-[#F15A24] text-white font-bold'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Gauges
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveInstrument('valves')}
                            className={`py-1.5 px-1 text-center transition-colors truncate cursor-pointer ${
                              activeInstrument === 'valves'
                                ? 'bg-[#F15A24] text-white font-bold'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Valves
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveInstrument('calibration')}
                            className={`py-1.5 px-1 text-center transition-colors truncate cursor-pointer ${
                              activeInstrument === 'calibration'
                                ? 'bg-[#F15A24] text-white font-bold'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Calibration
                          </button>
                        </div>

                        {/* Selected Instrument Image Display with Industrial HUD */}
                        <div className="relative h-44 sm:h-48 group overflow-hidden">
                          <img
                            src={instrumentDetails[activeInstrument].image}
                            alt={instrumentDetails[activeInstrument].alt}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                          {/* Technical Telemetry Badge */}
                          <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-700/90 text-orange-400 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                            <span>{instrumentDetails[activeInstrument].tag}</span>
                          </div>

                          <div className="absolute top-2 right-2 bg-emerald-950/90 border border-emerald-600/50 text-emerald-300 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                            <Check size={11} className="text-emerald-400" />
                            <span>{instrumentDetails[activeInstrument].badge}</span>
                          </div>

                          {/* Bottom Spec Details */}
                          <div className="absolute bottom-2 left-2 right-2 p-2 rounded bg-slate-900/85 backdrop-blur-md border border-slate-800 text-xs">
                            <div className="font-bold text-white font-sans flex items-center justify-between">
                              <span>{instrumentDetails[activeInstrument].name}</span>
                              <span className="text-[10px] font-mono-tech text-orange-400 font-normal">
                                {instrumentDetails[activeInstrument].protocol}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5 truncate">
                              {instrumentDetails[activeInstrument].range}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Capabilities Spec Checklist */}
                      <div className="grid grid-cols-2 gap-2 text-xs text-slate-200 font-sans">
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#F15A24] shrink-0" />
                          <span className="truncate">Field Transmitters (P/T/F/L)</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#F15A24] shrink-0" />
                          <span className="truncate">Control &amp; On-Off Valves</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#F15A24] shrink-0" />
                          <span className="truncate">DCS / PLC Loop Checks</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-[#F15A24] shrink-0" />
                          <span className="truncate">SS Tubing &amp; Argon Welding</span>
                        </div>
                      </div>

                      <div className="pt-1 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
                        <span>Quality Standard: <strong className="text-white">ISO 9001:2015</strong></span>
                        <button
                          onClick={() => scrollTo('instrumentation')}
                          className="text-orange-400 hover:text-orange-300 inline-flex items-center gap-1 font-semibold"
                        >
                          View All Instruments <ChevronRight size={13} />
                        </button>
                      </div>
                    </div>
                  )}

                  {activeTab === 'electrical' && (
                    <div className="space-y-4 animate-in fade-in duration-200">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="text-[11px] font-mono-tech text-orange-400 uppercase tracking-widest font-semibold">
                            CORE DISCIPLINE · 02
                          </div>
                          <h3 className="text-lg sm:text-xl font-bold font-sans text-white mt-0.5">
                            Industrial Electrical Contracting
                          </h3>
                        </div>
                        <span className="text-[10px] font-mono-tech bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                          Heavy Duty Power
                        </span>
                      </div>

                      {/* Industrial Electrical Switchgear Panel Snapshot Banner */}
                      <div className="relative h-44 sm:h-48 rounded-lg overflow-hidden border border-slate-700/80 group">
                        <img
                          src={IMAGES.electricalPanel.src}
                          alt={IMAGES.electricalPanel.alt}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                        <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-700 text-orange-400 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm">
                          <Zap size={11} className="text-amber-400" />
                          <span>HT / LT POWER &amp; MCC SWITCHGEAR</span>
                        </div>
                        <div className="absolute top-2 right-2 bg-emerald-950/90 border border-emerald-600/50 text-emerald-300 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                          <Check size={11} className="text-emerald-400" />
                          <span>415V MCC Verified</span>
                        </div>
                        <div className="absolute bottom-2 left-2 right-2 p-2 rounded bg-slate-900/85 backdrop-blur-md border border-slate-800 text-xs">
                          <div className="font-bold text-white font-sans flex items-center justify-between">
                            <span>MCC / PCC Substation Panels</span>
                            <span className="text-[10px] font-mono-tech text-orange-400">Busbars &amp; ACB</span>
                          </div>
                          <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5 truncate">
                            Megger &amp; Hi-Pot Verified · Flameproof Gland Terminations
                          </div>
                        </div>
                      </div>

                      {/* Capabilities Spec Checklist */}
                      <div className="grid grid-cols-2 gap-2 text-xs text-slate-200 font-sans">
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                          <span className="truncate">HT / LT Power Cable Laying</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                          <span className="truncate">MCC &amp; PCC Switchgear Panels</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                          <span className="truncate">Flameproof Glanding &amp; Terms</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                          <span className="truncate">Sub-station Earthing Grid Pits</span>
                        </div>
                      </div>

                      <div className="pt-1 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
                        <span>Cable Integrity: <strong className="text-white">Megger &amp; Hi-Pot Verified</strong></span>
                        <button
                          onClick={() => scrollTo('electrical')}
                          className="text-orange-400 hover:text-orange-300 inline-flex items-center gap-1 font-semibold"
                        >
                          View Tech Details <ChevronRight size={13} />
                        </button>
                      </div>
                    </div>
                  )}

                  {activeTab === 'turnaround' && (
                    <div className="space-y-4 animate-in fade-in duration-200">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="text-[11px] font-mono-tech text-orange-400 uppercase tracking-widest font-semibold">
                            SPECIALIZED EXPEDITION
                          </div>
                          <h3 className="text-lg sm:text-xl font-bold font-sans text-white mt-0.5">
                            Plant Turnaround &amp; Revamp
                          </h3>
                        </div>
                        <span className="text-[10px] font-mono-tech bg-orange-950/80 text-orange-300 px-2 py-0.5 rounded border border-orange-700/50">
                          24/7 Overhaul
                        </span>
                      </div>

                      {/* On-Site Field Maintenance Technicians Photograph */}
                      <div className="relative h-44 sm:h-48 rounded-lg overflow-hidden border border-slate-700/80 group">
                        <img
                          src={IMAGES.fieldMaintenance.src}
                          alt={IMAGES.fieldMaintenance.alt}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-transparent" />
                        <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-700 text-orange-400 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm">
                          <Activity size={11} className="text-[#F15A24]" />
                          <span>FIELD MAINTENANCE &amp; OVERHAUL</span>
                        </div>
                        <div className="absolute top-2 right-2 bg-emerald-950/90 border border-emerald-600/50 text-emerald-300 text-[10px] font-mono-tech px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                          <Check size={11} className="text-emerald-400" />
                          <span>24/7 Rapid Response</span>
                        </div>
                        <div className="absolute bottom-2 left-2 right-2 p-2 rounded bg-slate-900/85 backdrop-blur-md border border-slate-800 text-xs">
                          <div className="font-bold text-white font-sans flex items-center justify-between">
                            <span>Field Technicians &amp; Loop Crews</span>
                            <span className="text-[10px] font-mono-tech text-orange-400">Preventive Overhaul</span>
                          </div>
                          <div className="text-[11px] text-slate-300 font-mono-tech mt-0.5 truncate">
                            Junction Boxes · Transmitter Servicing · Zero Downtime
                          </div>
                        </div>
                      </div>

                      {/* Capabilities Spec Checklist */}
                      <div className="grid grid-cols-2 gap-2 text-xs text-slate-200 font-sans">
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-amber-400 shrink-0" />
                          <span className="truncate">24/7 Turnaround Mobilization</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-amber-400 shrink-0" />
                          <span className="truncate">Hot Loop Pre-Commissioning</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-amber-400 shrink-0" />
                          <span className="truncate">Calibration Test Benches</span>
                        </div>
                        <div className="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center gap-2">
                          <CheckCircle2 size={13} className="text-amber-400 shrink-0" />
                          <span className="truncate">Multi-disciplinary Crews</span>
                        </div>
                      </div>

                      <div className="pt-1 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
                        <span>Delivery Record: <strong className="text-white">Zero Turnaround Delays</strong></span>
                        <button
                          onClick={() => scrollTo('expertise')}
                          className="text-orange-400 hover:text-orange-300 inline-flex items-center gap-1 font-semibold"
                        >
                          View Tech Details <ChevronRight size={13} />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Quick Action Footer in Cockpit */}
                  <div className="pt-2">
                    <button
                      onClick={() => setRfqModalOpen(true)}
                      className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded font-bold text-xs uppercase tracking-wider border border-slate-700 hover:border-orange-500 transition-all flex items-center justify-center gap-2"
                    >
                      <Sparkles size={14} className="text-[#F15A24]" />
                      <span>Request Scope Evaluation / Fast RFQ</span>
                    </button>
                  </div>
                </div>

                {/* Bottom Verification Strip */}
                <div className="bg-[#08101E] px-6 py-3 border-t border-slate-800/90 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-tech text-slate-400">
                  <span className="text-slate-300">GST: <strong className="text-white">24ACEPM8370P1Z1</strong></span>
                  <span>ESIC: <strong className="text-slate-300">38240749840010999</strong></span>
                  <span>EPFO: GJ/20100</span>
                  <span>MSME: GJ24D0009735</span>
                  <span className="text-orange-400 font-bold">EST. 1991</span>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>

      {/* DOCKED METRIC / CREDENTIAL BAR (4-Segment Architectural Ribbon) */}
      <div className="relative border-t border-slate-800 bg-[#070F1E] shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 divide-x-0 lg:divide-x divide-slate-800">
            {/* Metric Box 1 */}
            <div className="p-6 sm:p-7 flex items-center gap-4 group hover:bg-slate-900/50 transition-colors">
              <div className="p-3 rounded-md bg-orange-500/10 text-[#F15A24] border border-orange-500/20 shrink-0 group-hover:bg-[#F15A24] group-hover:text-white transition-all">
                <Calendar size={26} />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold font-sans text-white tracking-tight">
                  1991
                </div>
                <div className="text-xs font-mono-tech uppercase text-slate-400 font-semibold tracking-wider mt-0.5">
                  ESTABLISHED IN VADODARA
                </div>
              </div>
            </div>

            {/* Metric Box 2 */}
            <div className="p-6 sm:p-7 flex items-center gap-4 group hover:bg-slate-900/50 transition-colors">
              <div className="p-3 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                <ShieldCheck size={26} />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold font-sans text-white tracking-tight">
                  ISO 9001
                </div>
                <div className="text-xs font-mono-tech uppercase text-slate-400 font-semibold tracking-wider mt-0.5">
                  CERTIFIED QUALITY SYSTEM
                </div>
              </div>
            </div>

            {/* Metric Box 3 */}
            <div className="p-6 sm:p-7 flex items-center gap-4 group hover:bg-slate-900/50 transition-colors">
              <div className="p-3 rounded-md bg-blue-500/10 text-blue-400 border border-blue-500/20 shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-all">
                <Sliders size={26} />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold font-sans text-white tracking-tight">
                  2 CORE
                </div>
                <div className="text-xs font-mono-tech uppercase text-slate-400 font-semibold tracking-wider mt-0.5">
                  INSTRUMENTATION &amp; ELECTRICAL
                </div>
              </div>
            </div>

            {/* Metric Box 4 */}
            <div className="p-6 sm:p-7 flex items-center gap-4 group hover:bg-slate-900/50 transition-colors">
              <div className="p-3 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0 group-hover:bg-amber-500 group-hover:text-white transition-all">
                <Building2 size={26} />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold font-sans text-white tracking-tight">
                  PROPRIETARY
                </div>
                <div className="text-xs font-mono-tech uppercase text-slate-400 font-semibold tracking-wider mt-0.5">
                  CONSTRUCTION &amp; ENGINEERING
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enterprise Client Trust Bar (Instant Credibility for Refineries & Petrochemicals) */}
      <div className="bg-[#050B16] border-t border-slate-800/80 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
            <span className="text-[11px] font-mono-tech uppercase tracking-widest text-slate-400 font-semibold flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F15A24]" />
              TRUSTED CONTRACTING PARTNER FOR LEADING INFRASTRUCTURE GIANTS
            </span>
            <span className="text-[11px] font-mono-tech text-slate-500">
              Refineries · Petrochemicals · Power · Continuous Process
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
            {clientLogos.map((client) => (
              <div
                key={client.name}
                onClick={() => scrollTo('clients')}
                className="bg-slate-900/70 hover:bg-slate-800/90 border border-slate-800 hover:border-orange-500/50 p-3 rounded transition-all cursor-pointer group text-center"
              >
                <div className="text-xs sm:text-sm font-bold font-sans text-slate-200 group-hover:text-white tracking-wide truncate">
                  {client.name}
                </div>
                <div className="text-[10px] font-mono-tech text-[#F15A24] truncate mt-0.5">
                  {client.sector}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Fast RFQ / Project Consultation Modal */}
      <EnquiryModal
        isOpen={rfqModalOpen}
        onClose={() => setRfqModalOpen(false)}
        defaultDiscipline={
          activeTab === 'turnaround'
            ? 'Plant Shutdown / Turnaround'
            : activeTab === 'electrical'
            ? 'Electrical Contracting'
            : 'Instrumentation Engineering'
        }
      />
    </section>
  );
};
