import React from 'react';
import { Award, Cpu, ShieldCheck, HeartHandshake, Compass, Wrench } from 'lucide-react';

interface StrengthItem {
  id: string;
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  description: string;
}

const strengths: StrengthItem[] = [
  {
    id: 'operational-excellance',
    title: 'Operational excellance',
    icon: Award,
    description: 'Disciplined project execution ensuring timely delivery, strict workflow governance, and robust engineering performance on site.',
  },
  {
    id: 'redefined-automation',
    title: 'Redefined automation',
    icon: Cpu,
    description: 'Advanced modern instrumentation systems, PLC, DCS, SCADA panel integration, and high-precision calibration workflows.',
  },
  {
    id: 'safety-quality',
    title: 'Commitment towards safety and quality',
    icon: ShieldCheck,
    description: 'Uncompromising adherence to ISO 9001:2015 standards and a zero-accident occupational health and safety culture.',
  },
  {
    id: 'client-satisfaction',
    title: 'Client satisfaction',
    icon: HeartHandshake,
    description: 'Maintaining trusted long-term relationships from our very first job through dependable quality and committed schedules.',
  },
  {
    id: 'holistic-approach',
    title: 'Holistic approach',
    icon: Compass,
    description: 'End-to-end capabilities spanning material supply, erection, testing, commissioning, shutdown support, and maintenance contracts.',
  },
  {
    id: 'technical-competencies',
    title: 'Technical competencies',
    icon: Wrench,
    description: 'Trained and experienced engineers, certified technicians, calibrated instruments, and expert supervisory leadership.',
  },
];

export const StrengthSection: React.FC = () => {
  return (
    <section id="strength" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Core Value Proposition
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Our Strength
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            The foundational capabilities that distinguish Narayan Engineering in industrial electrical and instrumentation contracting.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {strengths.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="bg-slate-50 rounded-xl p-8 border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-14 h-14 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-800 group-hover:text-white group-hover:bg-[#F15A24] group-hover:border-[#F15A24] transition-all shadow-sm">
                      <Icon size={26} />
                    </div>
                    <span className="text-xs font-mono-tech font-bold text-slate-400">
                      0{index + 1}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 font-sans tracking-tight mb-3">
                    {item.title}
                  </h3>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-200/80 flex items-center text-xs font-semibold text-slate-500 group-hover:text-[#F15A24] transition-colors">
                  <span>Narayan Engineering Core Capability</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
