import React from 'react';
import { Layers, Zap, Cpu, Activity, ShieldCheck, Check } from 'lucide-react';

interface ElectricalItem {
  id: string;
  category: string;
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  exactText: string;
  technicalScope: string;
}

const electricalItems: ElectricalItem[] = [
  {
    id: 'basic-infra',
    category: 'Infrastructure',
    title: 'Basic Project Infrastructure',
    icon: Layers,
    exactText: 'Installation of basic project infrastructure like Cable Tray, Junction Box, Laying Of Conduit, etc.',
    technicalScope: 'Cable Trays, Junction Boxes, Conduit Laying & Support Fabrication',
  },
  {
    id: 'power-lightning',
    category: 'Power & Illumination',
    title: 'Power & Lightning Systems and Illumination',
    icon: Zap,
    exactText: 'Installation, Testing & Commissioning of Power and Lightning System and illumination Works including Cable Laying, Glanding & Termination.',
    technicalScope: 'Power Distribution, Lightning Protection, Illumination, Cabling & Glanding',
  },
  {
    id: 'mcc-panels',
    category: 'Switchgear & Distribution',
    title: 'MCC Panels (MV/LV) & Distribution',
    icon: Cpu,
    exactText: 'Installation, Testing & Commissioning of MCC Panels (MV/LV), Lighting Distribution Panel, etc.',
    technicalScope: 'MV/LV Motor Control Centers, PCC, LDB, Interlocking & Busbar Coupling',
  },
  {
    id: 'industrial-motors',
    category: 'Rotating Machinery',
    title: 'Industrial Motors Testing & Commissioning',
    icon: Activity,
    exactText: 'Testing & Commissioning of Industrial Motors.',
    technicalScope: 'Insulation Resistance, No-load/Full-load Trial, Direction Check, Vibration & Temperature',
  },
  {
    id: 'earth-pit',
    category: 'Grounding & Safety',
    title: 'Earth Pit Making & Testing',
    icon: ShieldCheck,
    exactText: 'Making & Testing of Earth Pit.',
    technicalScope: 'Electrode Excavation, Chemical Backfilling, Earth Resistance Measurement & Grid Connection',
  },
];

export const ElectricalSection: React.FC = () => {
  return (
    <section id="electrical" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Discipline Capability
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Electrical Services
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            Turnkey industrial electrical construction, switchgear installation, motor testing, plant grounding, and power distribution systems.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {electricalItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md hover:border-orange-500/40 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono-tech uppercase tracking-wide text-slate-500 bg-slate-100 border border-slate-200 px-2 py-1 rounded">
                      {item.category}
                    </span>
                    <span className="text-xs font-mono-tech text-slate-400 font-bold">
                      0{index + 1}
                    </span>
                  </div>

                  <div className="flex items-center gap-3.5 mb-3">
                    <div className="p-2.5 rounded-lg bg-orange-50 border border-orange-100 text-[#F15A24] shadow-sm shrink-0">
                      <Icon size={22} />
                    </div>
                    <h3 className="font-bold text-base text-slate-900 font-sans leading-tight">
                      {item.title}
                    </h3>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed font-normal bg-slate-50 p-3.5 rounded-lg border border-slate-200/60 mt-3">
                    {item.exactText}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-2 text-xs font-medium text-slate-500">
                  <Check size={14} className="text-[#F15A24] shrink-0" />
                  <span className="truncate">{item.technicalScope}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
