import React, { useState } from 'react';
import { X, Send, CheckCircle2, Phone, Building2, Sliders, ShieldCheck, Loader2 } from 'lucide-react';
import { OfficialLogoMark } from './CompanyLogo';
import { submitRfqEnquiry } from '../lib/supabase';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultDiscipline?: string;
}

export interface RfqFormData {
  name: string;
  company: string;
  email: string;
  phone: string;
  discipline: string;
  plantType: string;
  location: string;
  scope: string;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({
  isOpen,
  onClose,
  defaultDiscipline = 'Instrumentation Engineering',
}) => {
  const [formData, setFormData] = useState<RfqFormData>({
    name: '',
    company: '',
    email: '',
    phone: '',
    discipline: defaultDiscipline,
    plantType: 'Refinery / Petrochemical',
    location: '',
    scope: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await submitRfqEnquiry({
        name: formData.name,
        company: formData.company,
        email: formData.email,
        phone: formData.phone,
        discipline: formData.discipline,
        plantType: formData.plantType,
        location: formData.location,
        scope: formData.scope,
      });
    } catch (err) {
      console.warn('Enquiry submission error:', err);
    } finally {
      setIsSubmitting(false);
      setSubmitted(true);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      company: '',
      email: '',
      phone: '',
      discipline: 'Instrumentation Engineering',
      plantType: 'Refinery / Petrochemical',
      location: '',
      scope: '',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative bg-[#0B1528] text-white border border-slate-700 w-full max-w-xl rounded-lg shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="enquiry-modal-title"
      >
        {/* Header */}
        <div className="bg-[#070E1B] p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-[#F15A24] p-1.5 rounded shrink-0">
              <OfficialLogoMark size={28} color="#FFFFFF" />
            </div>
            <div>
              <h3 id="enquiry-modal-title" className="text-base font-bold font-sans text-white">
                Request Tender / Project Enquiry
              </h3>
              <p className="text-xs text-slate-400 font-mono-tech">
                Narayan Engineering · Vadodara Project Estimation Desk
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {submitted ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 size={32} />
              </div>
              <h4 className="text-lg font-bold text-white font-sans">
                Project Enquiry Received!
              </h4>
              <p className="text-slate-300 max-w-md mx-auto leading-relaxed">
                Thank you, <strong className="text-white">{formData.name || 'Valued Client'}</strong>. Our engineering estimation desk has received your requisition for{' '}
                <strong className="text-[#F15A24]">{formData.discipline}</strong>. We will review the requirements and contact you within 24 business hours.
              </p>

              <div className="text-[11px] font-mono-tech text-emerald-400 bg-emerald-950/60 p-2.5 rounded border border-emerald-500/30 max-w-xs mx-auto flex items-center justify-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Supabase Cloud Sync: hwxulckbvhdclrckqgdm</span>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <a
                  href="tel:+919624017705"
                  className="inline-flex items-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white px-5 py-2.5 rounded font-bold text-xs uppercase transition-all shadow-md"
                >
                  <Phone size={14} />
                  <span>Call Office: +91 9624017705</span>
                </a>
                <button
                  onClick={handleReset}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-5 py-2.5 rounded font-bold text-xs uppercase transition-all"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Rajesh Sharma"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24]"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Enterprise / Organization *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="e.g. Petrochemical Refinery / EPC"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Direct Phone / Mobile *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24]"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Official Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. procurement@company.com"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Target Discipline
                  </label>
                  <select
                    value={formData.discipline}
                    onChange={(e) => setFormData({ ...formData, discipline: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[#F15A24]"
                  >
                    <option>Instrumentation Engineering</option>
                    <option>Electrical Contracting</option>
                    <option>Plant Shutdown / Turnaround</option>
                    <option>Technical Manpower Supply</option>
                    <option>Combined Turnkey Package</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                    Facility / Industry Type
                  </label>
                  <select
                    value={formData.plantType}
                    onChange={(e) => setFormData({ ...formData, plantType: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[#F15A24]"
                  >
                    <option>Refinery / Petrochemical</option>
                    <option>Chemical Plant</option>
                    <option>Fertilizer Plant</option>
                    <option>Power Generation</option>
                    <option>Steel &amp; Metals</option>
                    <option>Cement Plant</option>
                    <option>Other Continuous Process Plant</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                  Project Location / Site
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g. Dahej / Vadodara / Pan-India"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24]"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1 font-mono-tech uppercase text-[10px]">
                  Scope Summary / Bill of Quantities (BOQ)
                </label>
                <textarea
                  rows={3}
                  value={formData.scope}
                  onChange={(e) => setFormData({ ...formData, scope: e.target.value })}
                  placeholder="Provide brief details on transmitter counts, cable running, loop testing scope, or turnaround dates..."
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#F15A24] resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <span className="text-[11px] text-slate-400 font-mono-tech">
                  Office: +91 9624017705 · Direct: +91 9624017707
                </span>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 bg-[#F15A24] hover:bg-orange-600 disabled:opacity-60 text-white font-bold px-6 py-2.5 rounded text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={13} className="animate-spin" />
                      <span>SUBMITTING...</span>
                    </>
                  ) : (
                    <>
                      <Send size={13} />
                      <span>SUBMIT ENQUIRY</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
