import React, { useState } from 'react';

interface LogoProps {
  variant?: 'badge' | 'header' | 'hero' | 'footer' | 'mark-only';
  className?: string;
  theme?: 'dark' | 'light' | 'orange';
  interactive?: boolean;
}

export const OfficialLogoMark: React.FC<{
  size?: number;
  color?: string;
  accentColor?: string;
  className?: string;
  isCalibrating?: boolean;
  interactive?: boolean;
  onCalibrate?: () => void;
}> = ({
  size = 54,
  color = '#FFFFFF',
  accentColor = '#FBBF24',
  className = '',
  isCalibrating = false,
  interactive = true,
  onCalibrate,
}) => {
  const [localCalibrating, setLocalCalibrating] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const activeCalibrating = isCalibrating || localCalibrating;

  const handleClick = (e: React.MouseEvent) => {
    if (!interactive) return;
    e.stopPropagation();
    setLocalCalibrating(true);
    if (onCalibrate) onCalibrate();
    setTimeout(() => {
      setLocalCalibrating(false);
    }, 1800);
  };

  // Generate unique filter ID to prevent collisions across multiple instances
  const filterId = React.useId().replace(/:/g, '');

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 cursor-pointer group ${className}`}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title="Narayan Engineering Official Emblem (Click to trigger telemetry calibration)"
    >
      {/* Background Interactive Calibration Ripple */}
      {activeCalibrating && (
        <span
          className="absolute inset-0 rounded-full border-2 border-orange-400 pointer-events-none"
          style={{ animation: 'calibrationRipple 1.4s ease-out forwards' }}
        />
      )}

      {/* Subtle Specular Sheen Overlay container */}
      <div className="absolute inset-0 overflow-hidden rounded pointer-events-none">
        <div
          className="w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent logo-sheen-sweep pointer-events-none"
        />
      </div>

      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`shrink-0 transition-transform duration-300 ${
          isHovered ? 'scale-[1.05]' : 'scale-100'
        }`}
        aria-label="Narayan Engineering N/E Official Logo Emblem with Motion Graphics"
      >
        <defs>
          {/* Laser & Circuit Bloom Glow Filter */}
          <filter id={`bloom-${filterId}`} x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="1.8" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Circuit Gradient for Top Tracer */}
          <linearGradient id={`circuitGradTop-${filterId}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={color} stopOpacity="0.1" />
            <stop offset="50%" stopColor={accentColor} stopOpacity="1" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.9" />
          </linearGradient>

          {/* Circuit Gradient for Bottom Tracer */}
          <linearGradient id={`circuitGradBottom-${filterId}`} x1="0%" y1="100%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity="0.1" />
            <stop offset="60%" stopColor={accentColor} stopOpacity="1" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.9" />
          </linearGradient>

          {/* Laser Gradient for Diagonal Divider */}
          <linearGradient id={`laserGrad-${filterId}`} x1="26" y1="74" x2="74" y2="26" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor={color} stopOpacity="0.2" />
            <stop offset="50%" stopColor={accentColor} stopOpacity="1" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.9" />
          </linearGradient>
        </defs>

        {/* -----------------------------------------------------------------
            LAYER 0: Corner Telemetry Calibration Reticles (Industrial Ticks)
            ----------------------------------------------------------------- */}
        <g className="logo-reticle-tick" stroke={color} strokeWidth="1.2" opacity="0.45">
          {/* Top-Left Reticle */}
          <path d="M 6 12 L 6 6 L 12 6" fill="none" />
          {/* Top-Right Reticle */}
          <path d="M 88 6 L 94 6 L 94 12" fill="none" />
          {/* Bottom-Left Reticle */}
          <path d="M 6 88 L 6 94 L 12 94" fill="none" />
          {/* Bottom-Right Reticle */}
          <path d="M 88 94 L 94 94 L 94 88" fill="none" />
        </g>

        {/* -----------------------------------------------------------------
            LAYER 1: Base Structural Solid Geometry (Official Engineering Specs)
            ----------------------------------------------------------------- */}
        {/* Top Bracket */}
        <path
          d="M 14 38 L 14 14 L 86 14 L 86 36"
          stroke={color}
          strokeWidth="4.5"
          strokeLinecap="square"
          strokeLinejoin="miter"
          opacity="0.9"
        />

        {/* Bottom Bracket */}
        <path
          d="M 14 62 L 14 86 L 86 86"
          stroke={color}
          strokeWidth="4.5"
          strokeLinecap="square"
          strokeLinejoin="miter"
          opacity="0.9"
        />

        {/* Diagonal Divider Line */}
        <line
          x1="26"
          y1="74"
          x2="74"
          y2="26"
          stroke={color}
          strokeWidth="4.5"
          strokeLinecap="square"
          opacity="0.85"
        />

        {/* -----------------------------------------------------------------
            LAYER 2: Motion Graphics Circuit Overlays (Dynamic Current Pulse)
            ----------------------------------------------------------------- */}
        {/* Top Bracket Electric Pulse Tracer */}
        <path
          d="M 14 38 L 14 14 L 86 14 L 86 36"
          stroke={`url(#circuitGradTop-${filterId})`}
          strokeWidth={isHovered ? '5.5' : '4.8'}
          strokeLinecap="round"
          strokeLinejoin="miter"
          fill="none"
          filter={`url(#bloom-${filterId})`}
          className="logo-circuit-top pointer-events-none"
        />

        {/* Bottom Bracket Electric Pulse Tracer */}
        <path
          d="M 14 62 L 14 86 L 86 86"
          stroke={`url(#circuitGradBottom-${filterId})`}
          strokeWidth={isHovered ? '5.5' : '4.8'}
          strokeLinecap="round"
          strokeLinejoin="miter"
          fill="none"
          filter={`url(#bloom-${filterId})`}
          className="logo-circuit-bottom pointer-events-none"
        />

        {/* Diagonal Laser Signal Trail */}
        <line
          x1="26"
          y1="74"
          x2="74"
          y2="26"
          stroke={`url(#laserGrad-${filterId})`}
          strokeWidth={isHovered ? '5.5' : '4.8'}
          strokeLinecap="round"
          filter={`url(#bloom-${filterId})`}
          className="logo-laser-trail pointer-events-none"
        />

        {/* -----------------------------------------------------------------
            LAYER 3: Sonar / Node Ping Rings at Telemetry Intersections
            ----------------------------------------------------------------- */}
        <circle
          cx="26"
          cy="74"
          r="3"
          stroke={accentColor}
          fill="none"
          className="logo-sonar-ping pointer-events-none"
        />
        <circle
          cx="74"
          cy="26"
          r="3"
          stroke={accentColor}
          fill="none"
          className="logo-sonar-ping-delayed pointer-events-none"
        />

        {/* -----------------------------------------------------------------
            LAYER 4: Telemetry Photon Particle (Laser Spark gliding along diagonal)
            ----------------------------------------------------------------- */}
        {/* Outer Aura */}
        <circle
          cx="50"
          cy="50"
          r="5"
          fill={accentColor}
          opacity="0.35"
          filter={`url(#bloom-${filterId})`}
          className="logo-laser-particle pointer-events-none"
        />
        {/* Core Photon */}
        <circle
          cx="50"
          cy="50"
          r="3"
          fill="#FFFFFF"
          filter={`url(#bloom-${filterId})`}
          className="logo-laser-particle pointer-events-none"
        />

        {/* -----------------------------------------------------------------
            LAYER 5: Typography ('N' and 'E') with Luminescence Aura
            ----------------------------------------------------------------- */}
        {/* Serif 'N' (Narayan) */}
        <text
          x="32"
          y="45"
          fontFamily="'Times New Roman', Times, Georgia, serif"
          fontSize="28"
          fontWeight="bold"
          fill={color}
          textAnchor="middle"
          className="logo-letter-aura select-none pointer-events-none"
        >
          N
        </text>

        {/* Serif 'E' (Engineering) */}
        <text
          x="68"
          y="77"
          fontFamily="'Times New Roman', Times, Georgia, serif"
          fontSize="28"
          fontWeight="bold"
          fill={color}
          textAnchor="middle"
          className="logo-letter-aura select-none pointer-events-none"
        >
          E
        </text>
      </svg>
    </div>
  );
};

export const CompanyLogo: React.FC<LogoProps> = ({
  variant = 'header',
  className = '',
  theme = 'light',
  interactive = true,
}) => {
  const [calibrated, setCalibrated] = useState(false);

  const handleCalibrate = () => {
    setCalibrated(true);
    setTimeout(() => setCalibrated(false), 3000);
  };

  // ---------------------------------------------------------------------------
  // Variant: Official Badge Card (as in company photo profile)
  // ---------------------------------------------------------------------------
  if (variant === 'badge') {
    return (
      <div
        className={`group relative bg-gradient-to-br from-[#F15A24] via-[#ea511a] to-[#d94812] text-white px-5 py-4 rounded-xl shadow-lg border border-orange-500/40 flex items-center gap-4.5 overflow-hidden transition-all duration-300 hover:shadow-orange-500/20 hover:border-orange-300 ${className}`}
      >
        {/* Ambient Grid Background inside badge */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)',
            backgroundSize: '12px 12px',
          }}
        />

        {/* Ambient Radial Energy Glow behind the Logo */}
        <div className="absolute -left-6 -top-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

        {/* Motion Graphics Emblem */}
        <div className="relative z-10 shrink-0">
          <OfficialLogoMark
            size={58}
            color="#FFFFFF"
            accentColor="#FDE047"
            interactive={interactive}
            onCalibrate={handleCalibrate}
          />
        </div>

        {/* Typography Content */}
        <div className="relative z-10 flex flex-col justify-center leading-tight">
          <div className="flex items-center gap-2">
            <span className="font-bold text-lg md:text-xl tracking-tight text-white font-sans drop-shadow-sm">
              Narayan Engineering
            </span>
          </div>

          <span className="text-xs md:text-sm font-medium text-orange-50 tracking-normal mt-0.5">
            Instrumentation and Electrical Works
          </span>

          <div className="flex items-center gap-2 mt-1">
            <span className="text-[11px] md:text-xs text-orange-200 italic font-sans">
              “Redefining Automation.”
            </span>
            <span className="text-[9px] font-mono-tech text-orange-300 opacity-75">
              [EST. 1991]
            </span>
          </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // Variant: Mark Only
  // ---------------------------------------------------------------------------
  if (variant === 'mark-only') {
    return (
      <div
        className={`group relative inline-flex items-center justify-center p-2.5 rounded-xl bg-gradient-to-br from-[#F15A24] to-[#d94812] shadow-md border border-orange-500/30 overflow-hidden ${className}`}
      >
        <OfficialLogoMark
          size={42}
          color="#FFFFFF"
          accentColor="#FDE047"
          interactive={interactive}
          onCalibrate={handleCalibrate}
        />
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // Variant: Hero Presentation (Large Scale Motion Graphics Console)
  // ---------------------------------------------------------------------------
  if (variant === 'hero') {
    return (
      <div className={`flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 ${className}`}>
        <div className="group relative bg-gradient-to-br from-[#F15A24] via-[#ea511a] to-[#c73b07] p-4.5 rounded-2xl shadow-2xl shadow-orange-950/30 ring-1 ring-white/20 shrink-0 overflow-hidden">
          {/* Subtle Ambient Radial Aura */}
          <div className="absolute -inset-4 bg-orange-500/30 rounded-full blur-xl pointer-events-none group-hover:opacity-100 opacity-60 transition-opacity" />
          <OfficialLogoMark
            size={76}
            color="#FFFFFF"
            accentColor="#FDE047"
            interactive={interactive}
            onCalibrate={handleCalibrate}
          />
        </div>

        <div className="text-center sm:text-left flex flex-col justify-center">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white font-sans leading-none">
              Narayan Engineering
            </h1>
            <span className="inline-flex items-center gap-1.5 text-[10px] font-mono-tech uppercase bg-orange-950/60 border border-orange-600/40 text-orange-300 px-2 py-0.5 rounded-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              TELEMETRY ACTIVE
            </span>
          </div>

          <p className="text-base sm:text-lg md:text-xl font-medium text-orange-400 tracking-wide mt-2">
            Instrumentation and Electrical Works
          </p>

          <p className="text-sm sm:text-base text-slate-300 italic tracking-wider mt-1">
            “Redefining Automation”
          </p>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // Variant: Footer Dark Presentation
  // ---------------------------------------------------------------------------
  if (variant === 'footer') {
    return (
      <div className={`flex items-center gap-3.5 group select-none ${className}`}>
        <div className="relative bg-gradient-to-br from-[#F15A24] to-[#c73b07] p-2.5 rounded-lg shadow-md ring-1 ring-orange-400/20 shrink-0 overflow-hidden">
          <OfficialLogoMark
            size={46}
            color="#FFFFFF"
            accentColor="#FDE047"
            interactive={interactive}
            onCalibrate={handleCalibrate}
          />
        </div>

        <div className="flex flex-col leading-snug">
          <span className="font-bold text-lg text-white font-sans tracking-tight group-hover:text-orange-400 transition-colors">
            Narayan Engineering
          </span>
          <span className="text-xs font-medium text-slate-300">
            Instrumentation and Electrical Works
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-[11px] text-orange-400 italic">
              “Redefining Automation”
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // Default: Header / Nav Variant
  // ---------------------------------------------------------------------------
  const isDark = theme === 'dark';
  return (
    <div
      className={`group flex items-center gap-3 select-none transition-all duration-200 ${className}`}
    >
      {/* Motion Graphics Emblem Box */}
      <div className="relative bg-gradient-to-br from-[#F15A24] to-[#d94812] p-2 rounded-lg shadow-sm border border-orange-500/20 shrink-0 overflow-hidden group-hover:shadow-md group-hover:border-orange-400 transition-all duration-300">
        <OfficialLogoMark
          size={38}
          color="#FFFFFF"
          accentColor="#FDE047"
          interactive={interactive}
          onCalibrate={handleCalibrate}
        />
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col leading-tight">
        <div className="flex items-center gap-1.5">
          <span
            className={`font-bold text-base md:text-lg font-sans tracking-tight transition-colors duration-200 ${
              isDark
                ? 'text-white group-hover:text-orange-300'
                : 'text-slate-900 group-hover:text-[#F15A24]'
            }`}
          >
            Narayan Engineering
          </span>
          <span
            className={`hidden sm:inline-block w-1.5 h-1.5 rounded-full ${
              calibrated ? 'bg-emerald-400 animate-ping' : 'bg-emerald-500 animate-pulse'
            }`}
            title="Telemetry Online"
          />
        </div>

        <span
          className={`text-[11px] md:text-xs font-medium tracking-normal ${
            isDark ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          Instrumentation and Electrical Works
        </span>

        <div className="flex items-center gap-1 text-[10px] text-[#F15A24] font-medium tracking-wide">
          <span>“Redefining Automation”</span>
        </div>
      </div>
    </div>
  );
};
