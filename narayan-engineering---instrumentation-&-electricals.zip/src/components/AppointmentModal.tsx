import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Building,
  User,
  Mail,
  Phone,
  CheckCircle2,
  X,
  FileText,
  ShieldCheck,
  ArrowRight,
  Database,
  CalendarCheck,
  Download,
} from 'lucide-react';
import { OfficialLogoMark } from './CompanyLogo';
import {
  AppointmentPayload,
  submitAppointment,
  SUPABASE_PROJECT_ID,
} from '../lib/supabase';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: string;
}

const TIME_SLOTS = [
  '09:30 AM - 10:30 AM (Morning Technical Session)',
  '11:30 AM - 12:30 PM (Mid-Day Engineering Review)',
  '02:30 PM - 03:30 PM (Afternoon Site / BOQ Session)',
  '04:30 PM - 05:30 PM (Late-Afternoon Project Discussion)',
];

const CONSULTATION_TYPES = [
  {
    id: 'site_survey',
    label: 'On-Site Plant Survey & Routing Assessment',
    desc: 'Our senior engineer visits your continuous process plant in Gujarat / Western India.',
  },
  {
    id: 'office_meeting',
    label: 'Vadodara Head Office Technical Meeting',
    desc: 'In-person meeting at 36/842 Shivam Flats, New IPCL Road, Gorwa, Vadodara.',
  },
  {
    id: 'boq_tender',
    label: 'Turnkey Tender BOQ & Cost Estimation Review',
    desc: 'Line-by-line review of instrumentation, cable schedules, panels, and calibration scopes.',
  },
  {
    id: 'virtual_meeting',
    label: 'Virtual / Video Engineering Conference',
    desc: 'Online technical session via Google Meet / Microsoft Teams.',
  },
];

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  initialType,
}) => {
  // Today's date in YYYY-MM-DD for min date
  const todayStr = new Date().toISOString().split('T')[0];

  // Default next business day
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const [formData, setFormData] = useState<AppointmentPayload>({
    client_name: '',
    company: '',
    email: '',
    phone: '',
    appointment_date: defaultDate,
    time_slot: TIME_SLOTS[0],
    appointment_type: initialType || CONSULTATION_TYPES[0].label,
    project_location: '',
    notes: '',
  });

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submissionId, setSubmissionId] = useState<string | number | null>(null);
  const [submissionSource, setSubmissionSource] = useState<'database' | 'local_backup'>('database');
  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.client_name.trim()) errs.client_name = 'Name is required';
    if (!formData.email.trim()) {
      errs.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (!formData.phone.trim()) {
      errs.phone = 'Phone number is required';
    } else if (formData.phone.replace(/\D/g, '').length < 8) {
      errs.phone = 'Enter a valid phone number';
    }
    if (!formData.appointment_date) errs.appointment_date = 'Please pick a date';
    if (!formData.time_slot) errs.time_slot = 'Please select a time slot';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      const res = await submitAppointment(formData);
      setSubmissionId(res.id || `APT-${Date.now().toString().slice(-6)}`);
      setSubmissionSource(res.source);
      setSubmitted(true);
    } catch (err) {
      console.error('Failed to submit appointment', err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setSubmissionId(null);
    setFormData({
      client_name: '',
      company: '',
      email: '',
      phone: '',
      appointment_date: defaultDate,
      time_slot: TIME_SLOTS[0],
      appointment_type: CONSULTATION_TYPES[0].label,
      project_location: '',
      notes: '',
    });
    setErrors({});
    onClose();
  };

  // Generate .ics calendar download
  const handleDownloadIcs = () => {
    const title = `Technical Consultation - Narayan Engineering (${formData.client_name})`;
    const desc = `Consultation Type: ${formData.appointment_type}\\nLocation: ${formData.project_location || 'Vadodara Head Office / Online'}\\nNotes: ${formData.notes || 'Technical discussion on instrumentation & electrical works'}`;
    const dateFormatted = formData.appointment_date.replace(/-/g, '');

    const icsData = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Narayan Engineering//Appointment Scheduler//EN',
      'BEGIN:VEVENT',
      `SUMMARY:${title}`,
      `DESCRIPTION:${desc}`,
      `LOCATION:${formData.project_location || 'Vadodara, Gujarat'}`,
      `DTSTART;VALUE=DATE:${dateFormatted}`,
      `DTEND;VALUE=DATE:${dateFormatted}`,
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Narayan_Engineering_Appointment_${dateFormatted}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative bg-[#090F1D] text-white border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="appointment-modal-title"
      >
        {/* Header */}
        <div className="bg-[#050914] px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-[#F15A24] p-1.5 rounded shrink-0 shadow-sm">
              <OfficialLogoMark size={26} color="#FFFFFF" />
            </div>
            <div>
              <h3 id="appointment-modal-title" className="text-base font-bold font-sans text-white">
                Book Technical Consultation &amp; Site Visit
              </h3>
              <p className="text-xs text-slate-400 font-mono-tech">
                Narayan Engineering · Vadodara Project Engineering Desk
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {submitted ? (
            <div className="py-8 text-center space-y-5">
              <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 size={36} />
              </div>

              <div className="space-y-1">
                <h4 className="text-xl font-bold text-white font-sans">
                  Appointment Confirmed!
                </h4>
                <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                  Thank you, <strong className="text-white">{formData.client_name}</strong>. Your consultation has been scheduled with the Narayan Engineering estimation &amp; field project coordination team.
                </p>
              </div>

              {/* Appointment Summary Plaque */}
              <div className="bg-[#0B1528] border border-slate-800 rounded-xl p-4 max-w-md mx-auto text-left font-mono-tech space-y-2 text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 uppercase text-[10px]">Reference Number</span>
                  <span className="text-orange-400 font-bold">{submissionId}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 uppercase text-[10px]">Date &amp; Time</span>
                  <span className="text-white font-semibold">
                    {new Date(formData.appointment_date).toLocaleDateString(undefined, {
                      weekday: 'short',
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}{' '}
                    · {formData.time_slot.split(' ')[0]}
                  </span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 uppercase text-[10px]">Consultation Type</span>
                  <span className="text-slate-200 truncate max-w-[200px]" title={formData.appointment_type}>
                    {formData.appointment_type}
                  </span>
                </div>
                {formData.company && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 uppercase text-[10px]">Enterprise</span>
                    <span className="text-slate-200">{formData.company}</span>
                  </div>
                )}
              </div>

              {/* Supabase Transmission Badge */}
              <div className="text-[11px] font-mono-tech text-emerald-400 bg-emerald-950/60 p-2.5 rounded-lg border border-emerald-500/30 max-w-md mx-auto flex items-center justify-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  Saved to Supabase Backend Tables (Ref: {SUPABASE_PROJECT_ID})
                </span>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleDownloadIcs}
                  className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2.5 rounded font-bold text-xs uppercase transition-all border border-slate-700 cursor-pointer"
                >
                  <Download size={14} />
                  <span>Add to Calendar (.ics)</span>
                </button>

                <a
                  href="tel:+919624017705"
                  className="inline-flex items-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white px-5 py-2.5 rounded font-bold text-xs uppercase transition-all shadow-md"
                >
                  <Phone size={14} />
                  <span>Call Desk: +91 9624017705</span>
                </a>

                <button
                  onClick={handleReset}
                  className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white px-4 py-2.5 rounded font-bold text-xs uppercase transition-all cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Type Selection */}
              <div>
                <label className="block text-slate-300 font-mono-tech font-bold uppercase text-[11px] mb-2">
                  1. Consultation / Survey Nature <span className="text-orange-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {CONSULTATION_TYPES.map((type) => {
                    const isSelected = formData.appointment_type === type.label;
                    return (
                      <button
                        type="button"
                        key={type.id}
                        onClick={() =>
                          setFormData({ ...formData, appointment_type: type.label })
                        }
                        className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#15243E] border-[#F15A24] text-white shadow-sm'
                            : 'bg-[#0B1528] border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-xs text-white">
                            {type.label}
                          </span>
                          {isSelected && (
                            <CheckCircle2 size={14} className="text-[#F15A24] shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 leading-snug">
                          {type.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label
                    htmlFor="appointment-date"
                    className="block text-slate-300 font-mono-tech font-bold uppercase text-[11px] mb-1.5"
                  >
                    2. Preferred Date <span className="text-orange-400">*</span>
                  </label>
                  <div className="relative">
                    <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      id="appointment-date"
                      type="date"
                      min={todayStr}
                      value={formData.appointment_date}
                      onChange={(e) =>
                        setFormData({ ...formData, appointment_date: e.target.value })
                      }
                      className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs font-mono-tech focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>
                  {errors.appointment_date && (
                    <span className="text-[10px] text-rose-400 font-mono-tech mt-1 block">
                      {errors.appointment_date}
                    </span>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="time-slot"
                    className="block text-slate-300 font-mono-tech font-bold uppercase text-[11px] mb-1.5"
                  >
                    3. Preferred Time Slot <span className="text-orange-400">*</span>
                  </label>
                  <div className="relative">
                    <Clock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <select
                      id="time-slot"
                      value={formData.time_slot}
                      onChange={(e) =>
                        setFormData({ ...formData, time_slot: e.target.value })
                      }
                      className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs font-mono-tech focus:outline-none focus:border-[#F15A24] cursor-pointer"
                    >
                      {TIME_SLOTS.map((slot) => (
                        <option key={slot} value={slot}>
                          {slot}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Client Contact Info */}
              <div className="pt-2 border-t border-slate-800 space-y-3">
                <span className="block text-slate-400 font-mono-tech font-bold uppercase text-[10px]">
                  4. Professional / Contact Information
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="client-name"
                      className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                    >
                      Your Name <span className="text-orange-400">*</span>
                    </label>
                    <div className="relative">
                      <User size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        id="client-name"
                        type="text"
                        placeholder="e.g. Rajesh K. Patel"
                        value={formData.client_name}
                        onChange={(e) =>
                          setFormData({ ...formData, client_name: e.target.value })
                        }
                        className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>
                    {errors.client_name && (
                      <span className="text-[10px] text-rose-400 font-mono-tech mt-1 block">
                        {errors.client_name}
                      </span>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="client-company"
                      className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                    >
                      Enterprise / Company Name
                    </label>
                    <div className="relative">
                      <Building size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        id="client-company"
                        type="text"
                        placeholder="e.g. GACL / L&T / IOCL / ONGC"
                        value={formData.company}
                        onChange={(e) =>
                          setFormData({ ...formData, company: e.target.value })
                        }
                        className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="client-email"
                      className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                    >
                      Official Email <span className="text-orange-400">*</span>
                    </label>
                    <div className="relative">
                      <Mail size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        id="client-email"
                        type="email"
                        placeholder="name@company.com"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>
                    {errors.email && (
                      <span className="text-[10px] text-rose-400 font-mono-tech mt-1 block">
                        {errors.email}
                      </span>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="client-phone"
                      className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                    >
                      Phone / Mobile <span className="text-orange-400">*</span>
                    </label>
                    <div className="relative">
                      <Phone size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        id="client-phone"
                        type="tel"
                        placeholder="+91 98250 XXXXX"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>
                    {errors.phone && (
                      <span className="text-[10px] text-rose-400 font-mono-tech mt-1 block">
                        {errors.phone}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="project-location"
                    className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                  >
                    Plant Site / City Location
                  </label>
                  <div className="relative">
                    <MapPin size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      id="project-location"
                      type="text"
                      placeholder="e.g. Dahej PCPIR / Vadodara / Hazira / Ankleshwar"
                      value={formData.project_location}
                      onChange={(e) =>
                        setFormData({ ...formData, project_location: e.target.value })
                      }
                      className="w-full bg-[#0B1528] border border-slate-700 text-white pl-9 pr-3 py-2 rounded-lg text-xs focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="appointment-notes"
                    className="block text-slate-300 font-mono-tech text-[11px] mb-1"
                  >
                    Scope of Discussion / Project Requisition Brief
                  </label>
                  <textarea
                    id="appointment-notes"
                    rows={2}
                    placeholder="Briefly describe what you would like to discuss (e.g. DCS panel erection, cable tray laying, calibration schedules, site safety audits)..."
                    value={formData.notes}
                    onChange={(e) =>
                      setFormData({ ...formData, notes: e.target.value })
                    }
                    className="w-full bg-[#0B1528] border border-slate-700 text-white p-3 rounded-lg text-xs focus:outline-none focus:border-[#F15A24] resize-none"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-[11px] font-mono-tech text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck size={14} className="text-emerald-400 shrink-0" />
                  <span>Synced directly to Supabase Backend (hwxulck...)</span>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="flex-1 sm:flex-none px-4 py-2.5 rounded-lg text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 font-mono-tech text-xs uppercase cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-[#F15A24] hover:bg-orange-600 text-white px-6 py-2.5 rounded-lg font-mono-tech font-bold text-xs uppercase transition-all shadow-md cursor-pointer disabled:opacity-50"
                  >
                    {submitting ? (
                      <span>Scheduling...</span>
                    ) : (
                      <>
                        <span>Confirm Appointment</span>
                        <ArrowRight size={14} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
