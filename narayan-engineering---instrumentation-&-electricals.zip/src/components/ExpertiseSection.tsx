import React from 'react';
import { ShieldAlert, RefreshCw, Sliders, Settings, Users, CheckCircle2 } from 'lucide-react';

interface ExpertiseItem {
  id: string;
  name: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  description: string;
  highlights: string[];
}

const expertiseAreas: ExpertiseItem[] = [
  {
    id: 'plant-shutdown',
    name: 'PLANT SHUTDOWN SERVICES',
    icon: ShieldAlert,
    description: 'Specialized plant turnaround and shutdown management for critical process industries requiring time-bound execution, rapid mobilization, round-the-clock safety supervision, and zero downtime delays.',
    highlights: [
      'Rapid mobilization of technical workforce',
      'Valve overhaul, calibration & reinstallation',
      'Time-critical shutdown execution',
      'Strict adherence to site permit-to-work systems',
    ],
  },
  {
    id: 'commissioning-services',
    name: 'COMMISSIONING SERVICES',
    icon: RefreshCw,
    description: 'Full pre-commissioning checks, loop continuity, signal simulation, interlock testing, logic verification, and live process commissioning under consultant and client supervision.',
    highlights: [
      'Pre-commissioning and cold loop checks',
      'Hot loop checking with DCS/PLC simulation',
      'Interlock and safety trip functional testing',
      'As-built documentation and commissioning handover',
    ],
  },
  {
    id: 'calibration-services',
    name: 'CALIBRATION SERVICES',
    icon: Sliders,
    description: 'Precision on-site and bench calibration of field instrumentation using master instruments and certified testing equipments with traceability.',
    highlights: [
      'Pressure transmitters, DP transmitters & switches',
      'Temperature sensors (RTDs, Thermocouples) & gauges',
      'Flow meters, level transmitters & displacers',
      'Control valve stroke checks & positioner calibration',
    ],
  },
  {
    id: 'installation-testing-commissioning',
    name: 'INSTALLATION, TESTING & COMMISSIONING OF EQUIPMENTS',
    icon: Settings,
    description: 'Comprehensive installation, pre-testing, high-pot testing, loop checking, and integrated commissioning of major electrical and instrumentation equipment.',
    highlights: [
      'MCC panels, PCC, and power distribution systems',
      'DCS cabinets, PLC racks, SCADA and analyzer panels',
      'Industrial motors, drives, and control stations',
      'Impulse lines, manifold valves, and pneumatic tubing',
    ],
  },
  {
    id: 'manpower-deputation',
    name: 'DEPUTATION OF SKILLED AND UNSKILLED MANPOWER',
    icon: Users,
    description: 'Deployment of technically competent manpower to industrial project sites, refineries, chemical plants, and maintenance hubs for short-term and long-term contracts.',
    highlights: [
      'Experienced Site Engineers & Supervisors',
      'Certified Calibration Technicians & Electricians',
      'Skilled Tube Fitters, Instrument Mechanics & Riggers',
      'Trained Unskilled Labor with safety induction',
    ],
  },
];

export const ExpertiseSection: React.FC = () => {
  return (
    <section id="expertise" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Specialized Capabilities
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Our Expertise
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            Proven execution strength across five core pillars of industrial electrical and instrumentation engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {expertiseAreas.map((area, index) => {
            const Icon = area.icon;
            const isFullWidth = index === 4;
            return (
              <div
                key={area.id}
                className={`${
                  isFullWidth ? 'lg:col-span-12' : 'lg:col-span-6'
                } bg-slate-50 rounded-xl p-8 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-lg bg-white border border-slate-200 text-[#F15A24] shadow-sm">
                        <Icon size={24} />
                      </div>
                      <span className="text-xs font-mono-tech text-slate-400 font-bold">
                        Pillar 0{index + 1}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono-tech uppercase bg-orange-100 text-[#F15A24] px-2.5 py-1 rounded font-semibold">
                      Core Domain
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 font-sans tracking-tight mb-3">
                    {area.name}
                  </h3>

                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {area.description}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-4 border-t border-slate-200/80">
                    {area.highlights.map((highlight, hIndex) => (
                      <div key={hIndex} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 size={14} className="text-[#F15A24] shrink-0 mt-0.5" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
