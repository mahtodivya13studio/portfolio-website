import React, { useState, useEffect } from 'react';
import { Phone, Mail, MapPin, Menu, X, ChevronRight, ShieldCheck, ArrowRight, Shield } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';
import { EnquiryModal } from './EnquiryModal';

interface NavItem {
  name: string;
  href: string;
}

interface NavbarProps {
  onOpenAdmin?: () => void;
}

const navItems: NavItem[] = [
  { name: 'HOME', href: '#home' },
  { name: 'ABOUT US', href: '#about' },
  { name: 'SERVICES', href: '#services' },
  { name: 'INSTRUMENTATION', href: '#instrumentation' },
  { name: 'ELECTRICAL', href: '#electrical' },
  { name: 'PROJECTS', href: '#projects' },
  { name: 'EXPERTISE', href: '#expertise' },
  { name: 'SAFETY', href: '#safety' },
  { name: 'QUALITY', href: '#quality' },
  { name: 'CLIENTS', href: '#clients' },
  { name: 'CERTIFICATION', href: '#certification' },
  { name: 'CONTACT', href: '#contact' },
];

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmin }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = navItems.map((item) => item.href.substring(1));
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 140) {
            setActiveSection(sections[i]);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const topOffset = 75;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full transition-all bg-white border-b border-slate-200/90 shadow-xs">
        {/* Top Utility Strip */}
        <div className="bg-[#0B1528] text-slate-300 text-xs py-1.5 px-4 sm:px-6 lg:px-8 border-b border-slate-800 hidden md:block">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-6">
              <span className="flex items-center gap-1.5 text-slate-300">
                <MapPin size={13} className="text-[#F15A24]" />
                Vadodara, Gujarat (Established 1991)
              </span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck size={13} className="text-emerald-400" />
                ISO 9001:2015 Certified
              </span>
              <span className="hidden xl:inline-flex items-center gap-1.5 text-slate-300 font-mono-tech text-[11px]">
                <span className="text-[#F15A24] font-bold">GSTIN:</span>
                <span className="text-white font-semibold tracking-wider">24ACEPM8370P1Z1</span>
              </span>
            </div>

            <div className="flex items-center gap-6 font-mono-tech text-[11px]">
              <a
                href="tel:+919624017705"
                className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
                title="Office Contact"
              >
                <Phone size={13} className="text-[#F15A24]" />
                <span>Office: <strong className="text-white">+91 9624017705</strong></span>
              </a>
              <a
                href="tel:+919624017707"
                className="hidden lg:flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
                title="Direct Mobile"
              >
                <span>Direct: +91 9624017707</span>
              </a>
              <a
                href="mailto:narayan_enggbaroda@yahoo.co.in"
                className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
              >
                <Mail size={13} className="text-[#F15A24]" />
                narayan_enggbaroda@yahoo.co.in
              </a>

              {onOpenAdmin && (
                <button
                  onClick={onOpenAdmin}
                  className="flex items-center gap-1.5 text-slate-300 hover:text-orange-400 bg-slate-800/80 hover:bg-slate-700/80 px-2 py-0.5 rounded border border-slate-700 transition-colors font-mono-tech cursor-pointer"
                  title="Admin Portal - View recorded enquiries"
                >
                  <Shield size={12} className="text-[#F15A24]" />
                  <span>ADMIN DESK</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Main Clean White Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Official Company Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick('#home');
              }}
              className="flex items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 rounded"
            >
              <CompanyLogo variant="header" theme="light" />
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden xl:flex items-center gap-1 text-[12px] font-semibold text-slate-700 tracking-wider">
              {navItems.map((item) => {
                const isActive = activeSection === item.href.substring(1);
                return (
                  <button
                    key={item.name}
                    onClick={() => handleNavClick(item.href)}
                    className={`px-2.5 py-1.5 rounded transition-all relative cursor-pointer ${
                      isActive
                        ? 'text-[#F15A24] font-bold'
                        : 'text-slate-700 hover:text-[#F15A24] hover:bg-slate-50'
                    }`}
                  >
                    {item.name}
                    {isActive && (
                      <span className="absolute bottom-0 left-2.5 right-2.5 h-0.5 bg-[#F15A24] rounded-full shadow-[0_0_6px_rgba(241,90,36,0.6)]" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Action Button: ENQUIRE NOW */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setEnquiryModalOpen(true)}
                className="hidden sm:inline-flex items-center justify-center gap-1.5 bg-[#F15A24] hover:bg-orange-600 text-white font-bold text-xs uppercase px-5 py-2.5 rounded-sm shadow-md shadow-orange-950/20 transition-all hover:translate-y-[-1px] cursor-pointer tracking-wider"
              >
                <span>ENQUIRE NOW</span>
                <ArrowRight size={14} />
              </button>

              {/* Mobile Menu Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="xl:hidden inline-flex items-center justify-center p-2 rounded-md text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-orange-500"
                aria-label="Toggle navigation menu"
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-white border-t border-slate-200 px-4 pt-3 pb-6 shadow-2xl max-h-[calc(100vh-5rem)] overflow-y-auto">
            {/* Quick contact on mobile */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mb-4 text-xs space-y-1.5 text-slate-700">
              <div className="font-semibold text-slate-900">Narayan Engineering · Vadodara</div>
              <a
                href="tel:+919624017705"
                className="flex items-center gap-2 text-slate-800 hover:text-[#F15A24] font-medium"
              >
                <Phone size={13} className="text-[#F15A24]" /> Office: +91 9624017705
              </a>
              <a
                href="tel:+919624017707"
                className="flex items-center gap-2 text-slate-600 hover:text-[#F15A24]"
              >
                <span className="text-[10px] font-mono-tech text-slate-400">Direct:</span> +91 9624017707 / +91 99133 46418
              </a>
              <a
                href="mailto:narayan_enggbaroda@yahoo.co.in"
                className="flex items-center gap-2 text-slate-700 hover:text-[#F15A24]"
              >
                <Mail size={13} className="text-[#F15A24]" /> narayan_enggbaroda@yahoo.co.in
              </a>
            </div>

            <div className="grid grid-cols-1 gap-1">
              {navItems.map((item) => {
                const isActive = activeSection === item.href.substring(1);
                return (
                  <button
                    key={item.name}
                    onClick={() => handleNavClick(item.href)}
                    className={`w-full flex items-center justify-between text-left px-3 py-2.5 rounded-md text-xs font-semibold tracking-wider ${
                      isActive
                        ? 'bg-orange-50 text-[#F15A24] font-bold border-l-4 border-[#F15A24]'
                        : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <span>{item.name}</span>
                    <ChevronRight size={16} className="text-slate-400" />
                  </button>
                );
              })}
            </div>

            <div className="mt-5 pt-4 border-t border-slate-200 space-y-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setEnquiryModalOpen(true);
                }}
                className="w-full flex items-center justify-center gap-2 bg-[#F15A24] text-white py-3 rounded-sm font-bold text-xs uppercase shadow tracking-wider cursor-pointer"
              >
                <span>ENQUIRE NOW</span>
                <ArrowRight size={14} />
              </button>

              {onOpenAdmin && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAdmin();
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-sm font-mono-tech font-bold text-xs uppercase transition-colors cursor-pointer border border-slate-800"
                >
                  <Shield size={14} className="text-[#F15A24]" />
                  <span>ADMIN ENQUIRIES DESK</span>
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Shared Quick Enquiry Dialog */}
      <EnquiryModal isOpen={enquiryModalOpen} onClose={() => setEnquiryModalOpen(false)} />
    </>
  );
};
