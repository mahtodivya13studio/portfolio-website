import React from 'react';
import { Award, ShieldCheck, CheckCircle2, FileCheck, Layers } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

export const CertificationSection: React.FC = () => {
  return (
    <section id="certification" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-mono-tech tracking-wider text-[#F15A24] font-semibold mb-2">
            Quality Assurance Standard
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans uppercase tracking-tight">
            Recognition and Certification
          </h2>
          <div className="w-16 h-1 bg-[#F15A24] mx-auto mt-4 rounded-full" />
          <p className="mt-4 text-slate-600 text-sm sm:text-base">
            Committed to international standards of quality management, operational governance, and continuous improvement.
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Official ISO 9001:2015 Plaque */}
          <div className="md:col-span-6 bg-slate-900 text-white p-8 sm:p-10 rounded-2xl border border-slate-800 shadow-xl flex flex-col justify-between relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <span className="text-xs font-mono-tech uppercase tracking-wider text-emerald-400 font-bold">
                  Quality Management System
                </span>
                <span className="text-xs font-mono-tech text-slate-400">
                  Est. 1991
                </span>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-xl bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                  <ShieldCheck size={44} />
                </div>
                <div>
                  <div className="text-3xl font-extrabold font-sans text-white tracking-tight">
                    ISO 9001:2015
                  </div>
                  <div className="text-xs font-mono-tech text-emerald-400 font-semibold tracking-wide uppercase mt-1">
                    Certified Company
                  </div>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Narayan Engineering operates under an ISO 9001:2015 certified Quality Management System governing all construction &amp; engineering activities for instrumentation and electrical project jobs.
              </p>

              <div className="pt-4 border-t border-slate-800 space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                  <span>Quality Management System conforming to ISO 9001:2015</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                  <span>Documented testing, calibration, and loop checking</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                  <span>Regular management review meetings &amp; compliance audits</span>
                </div>
              </div>
            </div>
          </div>

          {/* Technical Scope Description */}
          <div className="md:col-span-6 space-y-6">
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
              <div className="text-xs font-mono-tech uppercase text-[#F15A24] font-semibold">
                Scope of Certification
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-sans">
                Construction &amp; Engineering Activities
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                “Narayan Engineering is an ISO 9001 Certified company dealing with construction &amp; engineering activities for the instrumentation and electrical jobs for various projects.”
              </p>
            </div>

            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
              <div className="text-xs font-mono-tech uppercase text-slate-500 font-semibold">
                Client &amp; Consultant Assurance
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-sans">
                Committed Schedule &amp; Quality
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                “To satisfy our Clients &amp; Consultants by giving committed schedule and Quality assured performance.”
              </p>
            </div>

            <div className="pt-2">
              <CompanyLogo variant="badge" className="w-full justify-center" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
