import React, { useState, useEffect, useMemo } from 'react';
import {
  Shield,
  Lock,
  LogOut,
  RefreshCw,
  Search,
  Download,
  Filter,
  CheckCircle2,
  Clock,
  Mail,
  Phone,
  Building,
  MapPin,
  FileText,
  Trash2,
  ExternalLink,
  AlertCircle,
  Database,
  X,
  Eye,
  PlusCircle,
  Check,
  Copy,
  Layers,
  Calendar,
  CalendarCheck,
  UserCheck,
  UserPlus,
  ShieldAlert,
  Key,
} from 'lucide-react';
import {
  UnifiedEnquiry,
  EnquiryStatus,
  fetchAllEnquiries,
  deleteEnquiryRecord,
  setEnquiryStatusLocal,
  createDemoEnquiry,
  SUPABASE_PROJECT_ID,
  SUPABASE_SQL_EDITOR_URL,
  SUPABASE_SCHEMA_SQL,
  checkSupabaseStatus,
  UnifiedAppointment,
  fetchAllAppointments,
  updateAppointmentStatus,
  deleteAppointmentRecord,
  checkAdminSlotStatus,
  registerSingleAdmin,
  verifyAdminCredentials,
} from '../lib/supabase';
import { OfficialLogoMark } from './CompanyLogo';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const AUTH_STORAGE_KEY = 'ne_admin_authenticated';
const AUTH_USER_KEY = 'ne_admin_current_user';

export const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose }) => {
  // Navigation Tabs in Admin Dashboard
  const [activeTab, setActiveTab] = useState<'enquiries' | 'appointments' | 'profile'>('enquiries');

  // Single-Slot Admin State
  const [slotStatus, setSlotStatus] = useState<{
    isClaimed: boolean;
    admin?: { full_name: string; email: string; created_at: string };
  }>({ isClaimed: false });
  const [isCheckingSlot, setIsCheckingSlot] = useState(true);

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem(AUTH_STORAGE_KEY) === 'true';
  });
  const [currentAdmin, setCurrentAdmin] = useState<{ full_name: string; email: string } | null>(() => {
    try {
      const stored = sessionStorage.getItem(AUTH_USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // Auth Mode: 'login' | 'signup'
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [usePinMode, setUsePinMode] = useState(false);

  // Signup Fields (Only 1 slot allowed!)
  const [signupFullName, setSignupFullName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [signupError, setSignupError] = useState('');
  const [signupSuccess, setSignupSuccess] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);

  // Data State - Enquiries
  const [enquiries, setEnquiries] = useState<UnifiedEnquiry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'rfq' | 'contact' | 'local'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedEnquiry, setSelectedEnquiry] = useState<UnifiedEnquiry | null>(null);
  const [copiedId, setCopiedId] = useState<string | number | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);

  // Data State - Appointments
  const [appointments, setAppointments] = useState<UnifiedAppointment[]>([]);
  const [appointmentSearch, setAppointmentSearch] = useState('');
  const [appointmentStatusFilter, setAppointmentStatusFilter] = useState<string>('all');
  const [selectedAppointment, setSelectedAppointment] = useState<UnifiedAppointment | null>(null);

  // Supabase Backend Status
  const [dbStatus, setDbStatus] = useState<{
    connected: boolean;
    tables: { enquiries: boolean; contacts: boolean };
    details: string;
  } | null>(null);

  // Check Admin Slot on Open
  const refreshSlotStatus = async () => {
    setIsCheckingSlot(true);
    try {
      const res = await checkAdminSlotStatus();
      setSlotStatus(res);
      // If slot is unclaimed and not authenticated, default to signup tab so user can claim it
      if (!res.isClaimed && !isAuthenticated) {
        setAuthMode('signup');
      } else {
        setAuthMode('login');
      }
    } catch (err) {
      console.error('Failed to check admin slot', err);
    } finally {
      setIsCheckingSlot(false);
    }
  };

  // Load All Data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [enqRes, apptRes, status, slot] = await Promise.all([
        fetchAllEnquiries(),
        fetchAllAppointments(),
        checkSupabaseStatus(),
        checkAdminSlotStatus(),
      ]);
      setEnquiries(enqRes.data);
      setAppointments(apptRes.data);
      setDbStatus(status);
      setSlotStatus(slot);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      refreshSlotStatus();
      if (isAuthenticated) {
        loadData();
      }
    }
  }, [isOpen, isAuthenticated]);

  // Handle Admin Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (usePinMode) {
      if (loginIdentifier.trim() === '1991' || loginIdentifier.trim().toLowerCase() === 'admin1991') {
        const adminObj = {
          full_name: 'Narayan Engineering Principal (Master PIN)',
          email: 'admin@narayanengineering.com',
        };
        setIsAuthenticated(true);
        setCurrentAdmin(adminObj);
        sessionStorage.setItem(AUTH_STORAGE_KEY, 'true');
        sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(adminObj));
        loadData();
        return;
      }
      setLoginError('Invalid Master PIN. (Default founding year: 1991)');
      return;
    }

    if (!loginIdentifier.trim()) {
      setLoginError('Please enter your admin email or master PIN.');
      return;
    }

    const res = await verifyAdminCredentials({
      identifier: loginIdentifier,
      password: loginPassword,
    });

    if (res.success && res.admin) {
      setIsAuthenticated(true);
      setCurrentAdmin(res.admin);
      sessionStorage.setItem(AUTH_STORAGE_KEY, 'true');
      sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(res.admin));
      loadData();
    } else {
      setLoginError(res.error || 'Invalid admin credentials');
    }
  };

  // Handle Single-Slot Admin Registration
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError('');
    setSignupSuccess('');

    if (slotStatus.isClaimed) {
      setSignupError('Registration is permanently closed. The single admin slot is already occupied.');
      return;
    }

    if (!signupFullName.trim()) {
      setSignupError('Full Name is required.');
      return;
    }
    if (!signupEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signupEmail)) {
      setSignupError('Please provide a valid administrative email.');
      return;
    }
    if (signupPassword.length < 6) {
      setSignupError('Password must be at least 6 characters long.');
      return;
    }
    if (signupPassword !== signupConfirmPassword) {
      setSignupError('Passwords do not match.');
      return;
    }

    setIsRegistering(true);
    try {
      const res = await registerSingleAdmin({
        fullName: signupFullName,
        email: signupEmail,
        password: signupPassword,
      });

      if (res.success && res.admin) {
        setSignupSuccess('Admin account created! The single admin slot is now permanently locked.');
        setSlotStatus({ isClaimed: true, admin: res.admin });
        setIsAuthenticated(true);
        setCurrentAdmin(res.admin);
        sessionStorage.setItem(AUTH_STORAGE_KEY, 'true');
        sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(res.admin));
        loadData();
      } else {
        setSignupError(res.error || 'Failed to register admin account.');
      }
    } catch (err) {
      setSignupError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setIsRegistering(false);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentAdmin(null);
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
    sessionStorage.removeItem(AUTH_USER_KEY);
    setLoginIdentifier('');
    setLoginPassword('');
    refreshSlotStatus();
  };

  // Status Change Handlers
  const handleEnquiryStatusChange = (item: UnifiedEnquiry, newStatus: EnquiryStatus) => {
    setEnquiryStatusLocal(item.id, newStatus);
    setEnquiries((prev) =>
      prev.map((e) => (e.id === item.id ? { ...e, status: newStatus } : e))
    );
    if (selectedEnquiry && selectedEnquiry.id === item.id) {
      setSelectedEnquiry({ ...selectedEnquiry, status: newStatus });
    }
  };

  const handleAppointmentStatusChange = async (
    item: UnifiedAppointment,
    newStatus: 'confirmed' | 'completed' | 'rescheduled' | 'cancelled'
  ) => {
    await updateAppointmentStatus(item, newStatus);
    setAppointments((prev) =>
      prev.map((a) => (a.id === item.id ? { ...a, status: newStatus } : a))
    );
    if (selectedAppointment && selectedAppointment.id === item.id) {
      setSelectedAppointment({ ...selectedAppointment, status: newStatus });
    }
  };

  // Delete Handlers
  const handleDeleteEnquiry = async (item: UnifiedEnquiry) => {
    if (!window.confirm(`Delete enquiry from ${item.name}?`)) return;
    const res = await deleteEnquiryRecord(item);
    if (res.success) {
      setEnquiries((prev) => prev.filter((e) => e.id !== item.id));
      if (selectedEnquiry?.id === item.id) setSelectedEnquiry(null);
    } else {
      alert(`Could not delete: ${res.error}`);
    }
  };

  const handleDeleteAppointment = async (item: UnifiedAppointment) => {
    if (!window.confirm(`Delete appointment for ${item.client_name}?`)) return;
    const res = await deleteAppointmentRecord(item);
    if (res.success) {
      setAppointments((prev) => prev.filter((a) => a.id !== item.id));
      if (selectedAppointment?.id === item.id) setSelectedAppointment(null);
    } else {
      alert(`Could not delete: ${res.error}`);
    }
  };

  // Demo Generator
  const handleAddDemo = async () => {
    setIsLoading(true);
    try {
      const demo = await createDemoEnquiry();
      setEnquiries((prev) => [demo, ...prev]);
    } catch (err) {
      console.error('Failed to add demo record', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Copy Details Shortcut
  const handleCopyDetails = (item: UnifiedEnquiry) => {
    const text = `
Enquiry ID: ${item.id} (${item.type === 'rfq' ? 'TENDER RFQ' : 'GENERAL INQUIRY'})
Date: ${new Date(item.created_at).toLocaleString()}
Client: ${item.name}
Company: ${item.company || 'N/A'}
Email: ${item.email}
Phone: ${item.phone}
Discipline: ${item.discipline || 'N/A'}
Facility: ${item.plantType || 'N/A'}
Location: ${item.location || 'N/A'}
Scope Details:
${item.scope || item.message || 'No description provided'}
    `.trim();
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Export Enquiries CSV
  const handleExportEnquiriesCsv = () => {
    if (filteredEnquiries.length === 0) {
      alert('No enquiries to export.');
      return;
    }
    const headers = [
      'ID',
      'Type',
      'Status',
      'Date',
      'Name',
      'Company',
      'Email',
      'Phone',
      'Discipline',
      'Facility / Plant Type',
      'Location',
      'Scope / Requirements',
      'Data Source',
    ];

    const rows = filteredEnquiries.map((e) => [
      `"${e.id}"`,
      `"${e.type.toUpperCase()}"`,
      `"${(e.status || 'new').toUpperCase()}"`,
      `"${new Date(e.created_at).toLocaleString()}"`,
      `"${(e.name || '').replace(/"/g, '""')}"`,
      `"${(e.company || '').replace(/"/g, '""')}"`,
      `"${e.email}"`,
      `"${e.phone}"`,
      `"${(e.discipline || '').replace(/"/g, '""')}"`,
      `"${(e.plantType || '').replace(/"/g, '""')}"`,
      `"${(e.location || '').replace(/"/g, '""')}"`,
      `"${(e.scope || e.message || '').replace(/"/g, '""')}"`,
      `"${e.source === 'database' ? 'Supabase DB' : 'Local Queue'}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `Narayan_Engineering_Enquiries_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export Appointments CSV
  const handleExportAppointmentsCsv = () => {
    if (filteredAppointments.length === 0) {
      alert('No appointments to export.');
      return;
    }
    const headers = [
      'ID',
      'Status',
      'Appointment Date',
      'Time Slot',
      'Consultation Type',
      'Client Name',
      'Company',
      'Email',
      'Phone',
      'Plant Location',
      'Scope Notes',
      'Booked At',
      'Data Source',
    ];

    const rows = filteredAppointments.map((a) => [
      `"${a.id}"`,
      `"${(a.status || 'confirmed').toUpperCase()}"`,
      `"${a.appointment_date}"`,
      `"${a.time_slot}"`,
      `"${a.appointment_type}"`,
      `"${(a.client_name || '').replace(/"/g, '""')}"`,
      `"${(a.company || '').replace(/"/g, '""')}"`,
      `"${a.email}"`,
      `"${a.phone}"`,
      `"${(a.project_location || '').replace(/"/g, '""')}"`,
      `"${(a.notes || '').replace(/"/g, '""')}"`,
      `"${new Date(a.created_at || '').toLocaleString()}"`,
      `"${a.source === 'database' ? 'Supabase DB' : 'Local Backup'}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `Narayan_Engineering_Appointments_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered Enquiries
  const filteredEnquiries = useMemo(() => {
    return enquiries.filter((item) => {
      if (typeFilter === 'rfq' && item.type !== 'rfq') return false;
      if (typeFilter === 'contact' && item.type !== 'contact') return false;
      if (typeFilter === 'local' && item.source !== 'local_backup') return false;
      if (statusFilter !== 'all' && (item.status || 'new') !== statusFilter) return false;

      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        return (
          item.name.toLowerCase().includes(q) ||
          (item.company || '').toLowerCase().includes(q) ||
          item.email.toLowerCase().includes(q) ||
          item.phone.toLowerCase().includes(q) ||
          (item.discipline || '').toLowerCase().includes(q) ||
          (item.location || '').toLowerCase().includes(q) ||
          (item.scope || item.message || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [enquiries, typeFilter, statusFilter, searchTerm]);

  // Filtered Appointments
  const filteredAppointments = useMemo(() => {
    return appointments.filter((item) => {
      if (appointmentStatusFilter !== 'all' && (item.status || 'confirmed') !== appointmentStatusFilter) {
        return false;
      }
      if (appointmentSearch.trim()) {
        const q = appointmentSearch.toLowerCase();
        return (
          item.client_name.toLowerCase().includes(q) ||
          (item.company || '').toLowerCase().includes(q) ||
          item.email.toLowerCase().includes(q) ||
          item.phone.toLowerCase().includes(q) ||
          item.appointment_type.toLowerCase().includes(q) ||
          (item.project_location || '').toLowerCase().includes(q) ||
          (item.notes || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [appointments, appointmentStatusFilter, appointmentSearch]);

  // Aggregate Metrics
  const stats = useMemo(() => {
    const totalEnquiries = enquiries.length;
    const rfqs = enquiries.filter((e) => e.type === 'rfq').length;
    const contacts = enquiries.filter((e) => e.type === 'contact').length;
    const totalAppts = appointments.length;
    const confirmedAppts = appointments.filter((a) => (a.status || 'confirmed') === 'confirmed').length;
    return { totalEnquiries, rfqs, contacts, totalAppts, confirmedAppts };
  }, [enquiries, appointments]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative bg-[#090F1D] text-white border border-slate-800 w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[94vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-portal-title"
      >
        {/* Top Header Strip */}
        <div className="bg-[#050914] px-4 sm:px-6 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-[#F15A24] p-1.5 rounded shrink-0 shadow-sm">
              <OfficialLogoMark size={24} color="#FFFFFF" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="admin-portal-title" className="text-sm sm:text-base font-bold font-sans text-white tracking-wide">
                  Narayan Engineering · Operations &amp; Admin Desk
                </h2>
                <span className="hidden sm:inline-block text-[10px] font-mono-tech px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-400">
                  ESTD 1991
                </span>
                {slotStatus.isClaimed ? (
                  <span className="hidden md:inline-block text-[10px] font-mono-tech px-2 py-0.5 rounded bg-blue-950 border border-blue-500/40 text-blue-300">
                    Admin Slot: 1/1 Claimed
                  </span>
                ) : (
                  <span className="hidden md:inline-block text-[10px] font-mono-tech px-2 py-0.5 rounded bg-amber-950 border border-amber-500/40 text-amber-300 animate-pulse">
                    Admin Slot: 1/1 Available
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 font-mono-tech">
                Supabase Ref: <span className="text-orange-400 font-bold">{SUPABASE_PROJECT_ID}</span> · Centralized Inquiries &amp; Appointment Stream
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-2.5 py-1.5 rounded hover:bg-slate-800/80 transition-colors font-mono-tech cursor-pointer"
                title="Sign out of Admin Session"
              >
                <LogOut size={14} />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close Admin Panel"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        {!isAuthenticated ? (
          /* Authentication & Single-Slot Setup Gate */
          <div className="flex-1 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <div className="w-full max-w-md bg-[#0B1528] p-6 sm:p-8 rounded-xl border border-slate-800 shadow-2xl space-y-6">
              {/* Header Icon & Title */}
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-full bg-orange-500/10 border border-orange-500/30 text-[#F15A24] flex items-center justify-center mx-auto">
                  <Shield size={28} />
                </div>
                <h3 className="text-lg font-bold font-sans text-white">
                  {authMode === 'signup' ? 'Create Single Admin Account' : 'Administrative Sign In'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {authMode === 'signup'
                    ? 'Exactly ONE administrative account slot is provided. Once created, registration is locked permanently.'
                    : 'Enter your registered admin credentials to manage appointments and tender enquiries.'}
                </p>
              </div>

              {/* Slot Status Notice */}
              <div className="bg-[#070D18] p-3 rounded-lg border border-slate-800 text-xs font-mono-tech space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Admin Account Slot:</span>
                  {slotStatus.isClaimed ? (
                    <span className="text-blue-400 font-bold flex items-center gap-1">
                      <Lock size={11} /> 1/1 Claimed (Locked)
                    </span>
                  ) : (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 size={11} /> 1 Slot Open for Setup
                    </span>
                  )}
                </div>
                {slotStatus.isClaimed && (
                  <div className="text-[10px] text-slate-500">
                    Registered: <span className="text-slate-300">{slotStatus.admin?.email}</span>
                  </div>
                )}
              </div>

              {/* Form Switcher Tabs (Only if slot is unclaimed!) */}
              {!slotStatus.isClaimed && (
                <div className="grid grid-cols-2 p-1 bg-[#070D18] rounded-lg border border-slate-800 text-xs font-mono-tech">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('signup');
                      setSignupError('');
                    }}
                    className={`py-2 rounded-md font-bold transition-all cursor-pointer ${
                      authMode === 'signup'
                        ? 'bg-[#F15A24] text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    1. Create Admin (Slot)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('login');
                      setLoginError('');
                    }}
                    className={`py-2 rounded-md font-bold transition-all cursor-pointer ${
                      authMode === 'login'
                        ? 'bg-slate-800 text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    2. Sign In
                  </button>
                </div>
              )}

              {/* SIGNUP FORM (Only visible when slot is open) */}
              {authMode === 'signup' && !slotStatus.isClaimed && (
                <form onSubmit={handleSignup} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-slate-300 font-mono-tech mb-1">
                      Admin Full Name <span className="text-orange-400">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Satyanarayan L. Mahto"
                      value={signupFullName}
                      onChange={(e) => setSignupFullName(e.target.value)}
                      className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-sans focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-mono-tech mb-1">
                      Admin Official Email <span className="text-orange-400">*</span>
                    </label>
                    <input
                      type="email"
                      placeholder="admin@narayanengineering.com"
                      value={signupEmail}
                      onChange={(e) => setSignupEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-sans focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-mono-tech mb-1">
                      Admin Password <span className="text-orange-400">*</span>
                    </label>
                    <input
                      type="password"
                      placeholder="Minimum 6 characters"
                      value={signupPassword}
                      onChange={(e) => setSignupPassword(e.target.value)}
                      className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-mono-tech focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-mono-tech mb-1">
                      Confirm Password <span className="text-orange-400">*</span>
                    </label>
                    <input
                      type="password"
                      placeholder="Confirm your password"
                      value={signupConfirmPassword}
                      onChange={(e) => setSignupConfirmPassword(e.target.value)}
                      className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-mono-tech focus:outline-none focus:border-[#F15A24]"
                    />
                  </div>

                  {signupError && (
                    <div className="p-2.5 bg-rose-950/60 border border-rose-500/40 rounded text-rose-300 font-mono-tech text-[11px] flex items-center gap-1.5">
                      <AlertCircle size={14} className="shrink-0" />
                      <span>{signupError}</span>
                    </div>
                  )}

                  {signupSuccess && (
                    <div className="p-2.5 bg-emerald-950/60 border border-emerald-500/40 rounded text-emerald-300 font-mono-tech text-[11px] flex items-center gap-1.5">
                      <CheckCircle2 size={14} className="shrink-0" />
                      <span>{signupSuccess}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isRegistering}
                    className="w-full bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech font-bold uppercase text-xs py-3 rounded-lg transition-colors cursor-pointer shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <UserPlus size={15} />
                    <span>{isRegistering ? 'Registering...' : 'Claim Single Admin Account & Lock'}</span>
                  </button>

                  <p className="text-[10px] text-slate-400 text-center font-mono-tech">
                    Note: After submitting, registration will be permanently disabled for all visitors.
                  </p>
                </form>
              )}

              {/* LOGIN FORM (Always available) */}
              {authMode === 'login' && (
                <form onSubmit={handleLogin} className="space-y-4 text-xs">
                  {usePinMode ? (
                    <div>
                      <label className="block text-slate-300 font-mono-tech mb-1.5">
                        Master Founding Security PIN
                      </label>
                      <input
                        type="password"
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        placeholder="Enter PIN (e.g. 1991)"
                        autoFocus
                        className="w-full px-4 py-3 bg-[#070D18] border border-slate-700 rounded-lg text-white text-center font-mono-tech tracking-widest text-lg focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="block text-slate-300 font-mono-tech mb-1">
                          Admin Email Address
                        </label>
                        <input
                          type="email"
                          placeholder="e.g. admin@narayanengineering.com"
                          value={loginIdentifier}
                          onChange={(e) => setLoginIdentifier(e.target.value)}
                          autoFocus
                          className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-sans focus:outline-none focus:border-[#F15A24]"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-mono-tech mb-1">
                          Password
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="w-full px-3 py-2 bg-[#070D18] border border-slate-700 rounded-lg text-white font-mono-tech focus:outline-none focus:border-[#F15A24]"
                        />
                      </div>
                    </>
                  )}

                  {loginError && (
                    <div className="p-2.5 bg-rose-950/60 border border-rose-500/40 rounded text-rose-300 font-mono-tech text-[11px] flex items-center gap-1.5">
                      <AlertCircle size={14} className="shrink-0" />
                      <span>{loginError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech font-bold uppercase text-xs py-3 rounded-lg transition-colors cursor-pointer shadow-lg flex items-center justify-center gap-2"
                  >
                    <Lock size={15} />
                    <span>Unlock Admin Dashboard</span>
                  </button>

                  <div className="pt-2 flex items-center justify-between text-[11px] font-mono-tech text-slate-400">
                    <button
                      type="button"
                      onClick={() => {
                        setUsePinMode(!usePinMode);
                        setLoginError('');
                      }}
                      className="hover:text-orange-400 underline cursor-pointer"
                    >
                      {usePinMode ? 'Use Email & Password' : 'Use Master 1991 PIN'}
                    </button>

                    {!slotStatus.isClaimed && (
                      <button
                        type="button"
                        onClick={() => setAuthMode('signup')}
                        className="text-orange-400 hover:underline cursor-pointer"
                      >
                        Claim Single Slot
                      </button>
                    )}
                  </div>
                </form>
              )}
            </div>
          </div>
        ) : (
          /* Logged-in Operations Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Supabase Schema Notice Banner (if tables pending) */}
            {dbStatus && (!dbStatus.tables.enquiries || !dbStatus.tables.contacts) && (
              <div className="bg-amber-950/40 border-b border-amber-600/30 px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-amber-200">
                  <AlertCircle size={15} className="shrink-0 text-amber-400" />
                  <span>
                    Supabase tables pending in project <strong>{SUPABASE_PROJECT_ID}</strong>. Enquiries &amp; appointments are currently backed up safely in local queue.
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
                      setCopiedSql(true);
                      setTimeout(() => setCopiedSql(false), 2000);
                    }}
                    className="inline-flex items-center gap-1 bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer"
                  >
                    {copiedSql ? <Check size={12} /> : <Copy size={12} />}
                    <span>{copiedSql ? 'SQL Copied!' : 'Copy Complete Schema SQL'}</span>
                  </button>
                  <a
                    href={SUPABASE_SQL_EDITOR_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-tech px-2.5 py-1 rounded text-[11px] border border-slate-700"
                  >
                    <span>Open SQL Editor</span>
                    <ExternalLink size={12} />
                  </a>
                </div>
              </div>
            )}

            {/* Navigation Tabs Bar */}
            <div className="px-4 sm:px-6 bg-[#070D19] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto text-xs font-mono-tech">
                <button
                  onClick={() => setActiveTab('enquiries')}
                  className={`py-3 px-3 border-b-2 font-bold transition-all cursor-pointer flex items-center gap-2 ${
                    activeTab === 'enquiries'
                      ? 'border-[#F15A24] text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText size={15} />
                  <span>Tender &amp; RFQ Enquiries ({enquiries.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('appointments')}
                  className={`py-3 px-3 border-b-2 font-bold transition-all cursor-pointer flex items-center gap-2 ${
                    activeTab === 'appointments'
                      ? 'border-[#F15A24] text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Calendar size={15} />
                  <span>Site Visits &amp; Appointments ({appointments.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('profile')}
                  className={`py-3 px-3 border-b-2 font-bold transition-all cursor-pointer flex items-center gap-2 ${
                    activeTab === 'profile'
                      ? 'border-[#F15A24] text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck size={15} />
                  <span>Admin Profile &amp; Single Slot</span>
                </button>
              </div>

              {/* Admin Identity pill */}
              <div className="hidden lg:flex items-center gap-2 text-xs font-mono-tech text-slate-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Signed In: <strong className="text-white">{currentAdmin?.full_name || 'Administrator'}</strong></span>
              </div>
            </div>

            {/* TAB 1: ENQUIRIES & RFQs */}
            {activeTab === 'enquiries' && (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 sm:px-6 bg-[#070D19] border-b border-slate-800 text-xs font-mono-tech">
                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Total Inquiries</span>
                      <span className="text-xl font-bold font-sans text-white">{stats.totalEnquiries}</span>
                    </div>
                    <div className="p-2 rounded bg-blue-500/10 text-blue-400">
                      <Layers size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Tender Scopes</span>
                      <span className="text-xl font-bold font-sans text-orange-400">{stats.rfqs}</span>
                    </div>
                    <div className="p-2 rounded bg-orange-500/10 text-[#F15A24]">
                      <FileText size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">General Contacts</span>
                      <span className="text-xl font-bold font-sans text-amber-400">{stats.contacts}</span>
                    </div>
                    <div className="p-2 rounded bg-amber-500/10 text-amber-400">
                      <Mail size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Supabase Sync</span>
                      <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 mt-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span>Connected</span>
                      </span>
                    </div>
                    <div className="p-2 rounded bg-emerald-500/10 text-emerald-400">
                      <Database size={18} />
                    </div>
                  </div>
                </div>

                {/* Filter and Actions Bar */}
                <div className="p-4 sm:px-6 bg-[#0A1121] border-b border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono-tech">
                    <button
                      onClick={() => setTypeFilter('all')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        typeFilter === 'all'
                          ? 'bg-[#F15A24] text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      All ({enquiries.length})
                    </button>
                    <button
                      onClick={() => setTypeFilter('rfq')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        typeFilter === 'rfq'
                          ? 'bg-[#F15A24] text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      Tenders ({stats.rfqs})
                    </button>
                    <button
                      onClick={() => setTypeFilter('contact')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        typeFilter === 'contact'
                          ? 'bg-[#F15A24] text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      Contacts ({stats.contacts})
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative flex-1 sm:w-64">
                      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search client, company..."
                        className="w-full bg-[#070D18] border border-slate-700 text-white pl-8 pr-3 py-1.5 rounded-md text-xs font-mono-tech focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>

                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="bg-[#070D18] border border-slate-700 text-slate-300 px-2.5 py-1.5 rounded-md text-xs font-mono-tech focus:outline-none focus:border-[#F15A24] cursor-pointer"
                    >
                      <option value="all">Status: All</option>
                      <option value="new">Status: New</option>
                      <option value="reviewed">Status: Under Review</option>
                      <option value="quoted">Status: Quoted</option>
                      <option value="closed">Status: Closed</option>
                    </select>

                    <button
                      onClick={loadData}
                      disabled={isLoading}
                      className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                      title="Reload from Supabase"
                    >
                      <RefreshCw size={15} className={isLoading ? 'animate-spin' : ''} />
                    </button>

                    <button
                      onClick={handleExportEnquiriesCsv}
                      className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-md text-xs font-mono-tech transition-colors cursor-pointer border border-slate-700"
                    >
                      <Download size={13} />
                      <span className="hidden sm:inline">Export CSV</span>
                    </button>

                    <button
                      onClick={handleAddDemo}
                      disabled={isLoading}
                      className="inline-flex items-center gap-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-md text-xs font-mono-tech transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                    >
                      <PlusCircle size={13} />
                      <span className="hidden sm:inline">+ Demo RFQ</span>
                    </button>
                  </div>
                </div>

                {/* Enquiries Feed */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
                  {filteredEnquiries.length === 0 ? (
                    <div className="py-16 text-center bg-[#070D18] rounded-xl border border-slate-800 p-8 space-y-3">
                      <FileText size={32} className="text-slate-500 mx-auto" />
                      <h4 className="text-sm font-bold text-white">No enquiries match criteria</h4>
                      <p className="text-xs text-slate-400">
                        {searchTerm ? 'Try adjusting your search filters.' : 'Click "+ Demo RFQ" to test with a realistic requisition.'}
                      </p>
                    </div>
                  ) : (
                    filteredEnquiries.map((item) => {
                      const isRfq = item.type === 'rfq';
                      const status = item.status || 'new';

                      return (
                        <div
                          key={item.id}
                          className="bg-[#0B1528] hover:bg-[#0E1B33] border border-slate-800 hover:border-slate-700 rounded-xl p-4 sm:p-5 transition-all shadow-md space-y-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono-tech border-b border-slate-800/80 pb-3">
                            <div className="flex items-center gap-2">
                              <span
                                className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${
                                  isRfq
                                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                                    : 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                                }`}
                              >
                                {isRfq ? 'TENDER / RFQ' : 'GENERAL CONTACT'}
                              </span>

                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                                  status === 'new'
                                    ? 'bg-amber-950/80 text-amber-300 border border-amber-600/40'
                                    : status === 'reviewed'
                                    ? 'bg-blue-950/80 text-blue-300 border border-blue-600/40'
                                    : status === 'quoted'
                                    ? 'bg-purple-950/80 text-purple-300 border border-purple-600/40'
                                    : 'bg-emerald-950/80 text-emerald-300 border border-emerald-600/40'
                                }`}
                              >
                                {status === 'new'
                                  ? '● NEW'
                                  : status === 'reviewed'
                                  ? 'UNDER REVIEW'
                                  : status === 'quoted'
                                  ? 'QUOTATION SENT'
                                  : 'CLOSED'}
                              </span>

                              {item.source === 'database' ? (
                                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-500/30">
                                  <Database size={10} /> Supabase
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 bg-amber-950/50 px-2 py-0.5 rounded border border-amber-500/30">
                                  Offline Backup
                                </span>
                              )}
                            </div>

                            <div className="text-slate-400 text-[11px] flex items-center gap-1">
                              <Clock size={12} />
                              <span>{new Date(item.created_at).toLocaleString()}</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                            <div className="lg:col-span-4 space-y-1.5">
                              <h4 className="text-base font-bold text-white font-sans">
                                {item.name}
                              </h4>
                              {item.company && (
                                <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                                  <Building size={13} className="text-orange-400 shrink-0" />
                                  <span className="truncate">{item.company}</span>
                                </div>
                              )}
                              <div className="space-y-1 pt-1 text-xs font-mono-tech text-slate-400">
                                <div className="flex items-center gap-1.5">
                                  <Mail size={12} className="text-slate-500 shrink-0" />
                                  <a href={`mailto:${item.email}`} className="text-slate-300 hover:text-orange-400 truncate">
                                    {item.email}
                                  </a>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <Phone size={12} className="text-slate-500 shrink-0" />
                                  <a href={`tel:${item.phone}`} className="text-slate-300 hover:text-emerald-400">
                                    {item.phone}
                                  </a>
                                </div>
                              </div>
                            </div>

                            <div className="lg:col-span-8 space-y-2">
                              <div className="flex flex-wrap items-center gap-2 text-xs">
                                {item.discipline && (
                                  <span className="font-mono-tech text-[11px] text-orange-300 bg-[#16233B] px-2.5 py-1 rounded border border-orange-500/30 font-semibold">
                                    {item.discipline}
                                  </span>
                                )}
                                {item.plantType && (
                                  <span className="font-mono-tech text-[11px] text-slate-300 bg-slate-800/80 px-2 py-0.5 rounded">
                                    Plant: {item.plantType}
                                  </span>
                                )}
                                {item.location && (
                                  <span className="font-mono-tech text-[11px] text-slate-400 flex items-center gap-1">
                                    <MapPin size={11} className="text-slate-500" />
                                    {item.location}
                                  </span>
                                )}
                              </div>

                              <div className="bg-[#070D18] p-3 rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed max-h-24 overflow-y-auto">
                                <span className="font-semibold text-slate-400 block text-[10px] uppercase font-mono-tech mb-0.5">
                                  Scope / Requirements:
                                </span>
                                {item.scope || item.message || 'No description provided'}
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/60 text-xs font-mono-tech">
                            <div className="flex items-center gap-2">
                              <span className="text-slate-400 text-[11px]">Workflow:</span>
                              <select
                                value={status}
                                onChange={(e) =>
                                  handleEnquiryStatusChange(item, e.target.value as EnquiryStatus)
                                }
                                className="bg-[#070D18] border border-slate-700 text-xs text-white px-2 py-1 rounded focus:outline-none focus:border-[#F15A24] cursor-pointer"
                              >
                                <option value="new">Mark as New</option>
                                <option value="reviewed">Under Review</option>
                                <option value="quoted">Quotation Sent</option>
                                <option value="closed">Closed / Executed</option>
                              </select>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setSelectedEnquiry(item)}
                                className="inline-flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded transition-colors cursor-pointer"
                              >
                                <Eye size={12} />
                                <span>Details</span>
                              </button>

                              <button
                                onClick={() => handleCopyDetails(item)}
                                className="inline-flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded transition-colors cursor-pointer"
                              >
                                {copiedId === item.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                                <span>{copiedId === item.id ? 'Copied' : 'Copy'}</span>
                              </button>

                              <a
                                href={`tel:${item.phone}`}
                                className="inline-flex items-center gap-1 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 px-2.5 py-1 rounded transition-colors"
                              >
                                <Phone size={12} />
                                <span>Call</span>
                              </a>

                              <a
                                href={`mailto:${item.email}?subject=Narayan%20Engineering%20Tender%20Follow-up%20-%20${encodeURIComponent(item.company || item.name)}`}
                                className="inline-flex items-center gap-1 bg-blue-950/60 hover:bg-blue-900 border border-blue-500/40 text-blue-300 px-2.5 py-1 rounded transition-colors"
                              >
                                <Mail size={12} />
                                <span>Email</span>
                              </a>

                              <button
                                onClick={() => handleDeleteEnquiry(item)}
                                className="inline-flex items-center gap-1 text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 p-1.5 rounded transition-colors cursor-pointer ml-1"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: APPOINTMENTS & SITE VISITS */}
            {activeTab === 'appointments' && (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 sm:px-6 bg-[#070D19] border-b border-slate-800 text-xs font-mono-tech">
                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Total Bookings</span>
                      <span className="text-xl font-bold font-sans text-white">{stats.totalAppts}</span>
                    </div>
                    <div className="p-2 rounded bg-purple-500/10 text-purple-400">
                      <Calendar size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Active / Confirmed</span>
                      <span className="text-xl font-bold font-sans text-emerald-400">{stats.confirmedAppts}</span>
                    </div>
                    <div className="p-2 rounded bg-emerald-500/10 text-emerald-400">
                      <CalendarCheck size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Backend Table</span>
                      <span className="text-xs font-semibold text-slate-300 mt-1 block">
                        public.appointments
                      </span>
                    </div>
                    <div className="p-2 rounded bg-blue-500/10 text-blue-400">
                      <Database size={18} />
                    </div>
                  </div>

                  <div className="bg-[#0C1527] p-3 rounded-lg border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">Plant Sites</span>
                      <span className="text-xs font-semibold text-orange-400 mt-1 block">
                        Dahej / Vadodara / Panoli
                      </span>
                    </div>
                    <div className="p-2 rounded bg-orange-500/10 text-[#F15A24]">
                      <MapPin size={18} />
                    </div>
                  </div>
                </div>

                {/* Filter and Actions Bar */}
                <div className="p-4 sm:px-6 bg-[#0A1121] border-b border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono-tech">
                    <button
                      onClick={() => setAppointmentStatusFilter('all')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        appointmentStatusFilter === 'all'
                          ? 'bg-[#F15A24] text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      All ({appointments.length})
                    </button>
                    <button
                      onClick={() => setAppointmentStatusFilter('confirmed')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        appointmentStatusFilter === 'confirmed'
                          ? 'bg-emerald-600 text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      Confirmed ({stats.confirmedAppts})
                    </button>
                    <button
                      onClick={() => setAppointmentStatusFilter('completed')}
                      className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                        appointmentStatusFilter === 'completed'
                          ? 'bg-blue-600 text-white font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      Completed
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative flex-1 sm:w-64">
                      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={appointmentSearch}
                        onChange={(e) => setAppointmentSearch(e.target.value)}
                        placeholder="Search client, location, date..."
                        className="w-full bg-[#070D18] border border-slate-700 text-white pl-8 pr-3 py-1.5 rounded-md text-xs font-mono-tech focus:outline-none focus:border-[#F15A24]"
                      />
                    </div>

                    <button
                      onClick={loadData}
                      disabled={isLoading}
                      className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                      title="Reload from Supabase"
                    >
                      <RefreshCw size={15} className={isLoading ? 'animate-spin' : ''} />
                    </button>

                    <button
                      onClick={handleExportAppointmentsCsv}
                      className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-md text-xs font-mono-tech transition-colors cursor-pointer border border-slate-700"
                    >
                      <Download size={13} />
                      <span className="hidden sm:inline">Export CSV</span>
                    </button>
                  </div>
                </div>

                {/* Appointments List */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
                  {filteredAppointments.length === 0 ? (
                    <div className="py-16 text-center bg-[#070D18] rounded-xl border border-slate-800 p-8 space-y-3">
                      <Calendar size={32} className="text-slate-500 mx-auto" />
                      <h4 className="text-sm font-bold text-white">No appointments recorded</h4>
                      <p className="text-xs text-slate-400">
                        When clients book consultations through the website scheduler, they will automatically appear here.
                      </p>
                    </div>
                  ) : (
                    filteredAppointments.map((item) => {
                      const status = item.status || 'confirmed';

                      return (
                        <div
                          key={item.id}
                          className="bg-[#0B1528] hover:bg-[#0E1B33] border border-slate-800 hover:border-slate-700 rounded-xl p-4 sm:p-5 transition-all shadow-md space-y-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono-tech border-b border-slate-800/80 pb-3">
                            <div className="flex items-center gap-2">
                              <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2.5 py-0.5 rounded text-[11px] font-bold">
                                {item.appointment_type}
                              </span>

                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                                  status === 'confirmed'
                                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-600/40'
                                    : status === 'completed'
                                    ? 'bg-blue-950/80 text-blue-300 border border-blue-600/40'
                                    : status === 'rescheduled'
                                    ? 'bg-amber-950/80 text-amber-300 border border-amber-600/40'
                                    : 'bg-rose-950/80 text-rose-300 border border-rose-600/40'
                                }`}
                              >
                                {status.toUpperCase()}
                              </span>

                              <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                                {item.source === 'database' ? 'Supabase Table' : 'Local Queue'}
                              </span>
                            </div>

                            <div className="text-orange-400 font-bold text-xs flex items-center gap-1.5">
                              <Calendar size={13} />
                              <span>
                                {new Date(item.appointment_date).toLocaleDateString(undefined, {
                                  weekday: 'short',
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric',
                                })}{' '}
                                · {item.time_slot.split(' ')[0]}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                            <div className="lg:col-span-4 space-y-1.5">
                              <h4 className="text-base font-bold text-white font-sans">
                                {item.client_name}
                              </h4>
                              {item.company && (
                                <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                                  <Building size={13} className="text-orange-400 shrink-0" />
                                  <span>{item.company}</span>
                                </div>
                              )}
                              <div className="space-y-1 pt-1 text-xs font-mono-tech text-slate-400">
                                <div className="flex items-center gap-1.5">
                                  <Mail size={12} className="text-slate-500 shrink-0" />
                                  <a href={`mailto:${item.email}`} className="text-slate-300 hover:text-orange-400">
                                    {item.email}
                                  </a>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <Phone size={12} className="text-slate-500 shrink-0" />
                                  <a href={`tel:${item.phone}`} className="text-slate-300 hover:text-emerald-400">
                                    {item.phone}
                                  </a>
                                </div>
                              </div>
                            </div>

                            <div className="lg:col-span-8 space-y-2">
                              {item.project_location && (
                                <div className="text-xs font-mono-tech text-slate-300 flex items-center gap-1.5">
                                  <MapPin size={13} className="text-[#F15A24] shrink-0" />
                                  <span>Plant / Site Location: <strong className="text-white">{item.project_location}</strong></span>
                                </div>
                              )}
                              <div className="bg-[#070D18] p-3 rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed max-h-24 overflow-y-auto">
                                <span className="font-semibold text-slate-400 block text-[10px] uppercase font-mono-tech mb-0.5">
                                  Meeting Scope / Agenda:
                                </span>
                                {item.notes || 'No custom notes provided.'}
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/60 text-xs font-mono-tech">
                            <div className="flex items-center gap-2">
                              <span className="text-slate-400 text-[11px]">Appointment Status:</span>
                              <select
                                value={status}
                                onChange={(e) =>
                                  handleAppointmentStatusChange(
                                    item,
                                    e.target.value as 'confirmed' | 'completed' | 'rescheduled' | 'cancelled'
                                  )
                                }
                                className="bg-[#070D18] border border-slate-700 text-xs text-white px-2 py-1 rounded focus:outline-none focus:border-[#F15A24] cursor-pointer"
                              >
                                <option value="confirmed">Confirmed</option>
                                <option value="completed">Completed</option>
                                <option value="rescheduled">Rescheduled</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setSelectedAppointment(item)}
                                className="inline-flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded transition-colors cursor-pointer"
                              >
                                <Eye size={12} />
                                <span>Details</span>
                              </button>

                              <a
                                href={`tel:${item.phone}`}
                                className="inline-flex items-center gap-1 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 px-2.5 py-1 rounded transition-colors"
                              >
                                <Phone size={12} />
                                <span>Call</span>
                              </a>

                              <a
                                href={`mailto:${item.email}?subject=Narayan%20Engineering%20Appointment%20Confirmation`}
                                className="inline-flex items-center gap-1 bg-blue-950/60 hover:bg-blue-900 border border-blue-500/40 text-blue-300 px-2.5 py-1 rounded transition-colors"
                              >
                                <Mail size={12} />
                                <span>Email</span>
                              </a>

                              <button
                                onClick={() => handleDeleteAppointment(item)}
                                className="inline-flex items-center gap-1 text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 p-1.5 rounded transition-colors cursor-pointer ml-1"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* TAB 3: ADMIN PROFILE & SECURITY */}
            {activeTab === 'profile' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-6">
                <div className="max-w-2xl mx-auto space-y-6">
                  {/* Single Admin Account Plaque */}
                  <div className="bg-[#0B1528] rounded-xl border border-slate-800 p-6 space-y-5 shadow-lg">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-orange-500/10 border border-orange-500/30 text-[#F15A24] flex items-center justify-center">
                          <Shield size={24} />
                        </div>
                        <div>
                          <h4 className="text-base font-bold font-sans text-white">
                            Single Super-Admin Account
                          </h4>
                          <p className="text-xs text-slate-400 font-mono-tech">
                            Narayan Engineering Enterprise Security Architecture
                          </p>
                        </div>
                      </div>

                      <span className="px-3 py-1 rounded-full text-xs font-mono-tech font-bold bg-blue-950 border border-blue-500/40 text-blue-300">
                        Slot: 1/1 Occupied
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono-tech">
                      <div className="bg-[#070D18] p-3.5 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-slate-500 uppercase text-[10px]">Registered Admin Name</span>
                        <div className="text-white font-semibold text-sm">
                          {slotStatus.admin?.full_name || currentAdmin?.full_name || 'System Administrator'}
                        </div>
                      </div>

                      <div className="bg-[#070D18] p-3.5 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-slate-500 uppercase text-[10px]">Administrative Email</span>
                        <div className="text-orange-400 font-semibold text-sm truncate">
                          {slotStatus.admin?.email || currentAdmin?.email || 'admin@narayanengineering.com'}
                        </div>
                      </div>

                      <div className="bg-[#070D18] p-3.5 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-slate-500 uppercase text-[10px]">Role / Access Level</span>
                        <div className="text-emerald-400 font-semibold">
                          Super Administrator (Full Privileges)
                        </div>
                      </div>

                      <div className="bg-[#070D18] p-3.5 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-slate-500 uppercase text-[10px]">Registration Policy</span>
                        <div className="text-slate-300 font-semibold flex items-center gap-1.5">
                          <Lock size={12} className="text-rose-400" />
                          <span>Permanently Locked (Single Account Only)</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-lg bg-[#070D18] border border-slate-800/80 text-xs text-slate-400 space-y-1">
                      <div className="font-semibold text-slate-300">Single-Slot Security Guarantee:</div>
                      <p className="text-[11px] leading-relaxed">
                        By architectural design, the system restricts account registration to exactly <strong>1 single administrative slot</strong>. Any further registration attempts by external visitors are rejected with an access-denial error.
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                      <button
                        onClick={handleLogout}
                        className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2 rounded text-xs font-mono-tech transition-colors cursor-pointer"
                      >
                        <LogOut size={14} />
                        <span>Sign Out of Admin Console</span>
                      </button>

                      <div className="text-[11px] font-mono-tech text-slate-500">
                        Master Founding PIN: 1991 (Always available as emergency fail-safe)
                      </div>
                    </div>
                  </div>

                  {/* Supabase Technical Integration Card */}
                  <div className="bg-[#0B1528] rounded-xl border border-slate-800 p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm font-bold text-white font-sans">
                        <Database size={16} className="text-[#F15A24]" />
                        <span>Supabase PostgreSQL Integration Specs</span>
                      </div>
                      <span className="text-xs font-mono-tech text-emerald-400 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span>Online</span>
                      </span>
                    </div>

                    <div className="text-xs font-mono-tech space-y-2 text-slate-300">
                      <div className="flex items-center justify-between bg-[#070D18] p-2.5 rounded border border-slate-800">
                        <span className="text-slate-500">Project Reference ID:</span>
                        <span className="text-orange-400 font-bold">{SUPABASE_PROJECT_ID}</span>
                      </div>
                      <div className="flex items-center justify-between bg-[#070D18] p-2.5 rounded border border-slate-800">
                        <span className="text-slate-500">API Gateway Endpoint:</span>
                        <span className="text-slate-300 truncate max-w-[280px]">https://{SUPABASE_PROJECT_ID}.supabase.co</span>
                      </div>
                      <div className="flex items-center justify-between bg-[#070D18] p-2.5 rounded border border-slate-800">
                        <span className="text-slate-500">Database Tables:</span>
                        <span className="text-slate-300">public.enquiries, public.contacts, public.appointments, public.admin_users</span>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-end gap-2">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
                          setCopiedSql(true);
                          setTimeout(() => setCopiedSql(false), 2000);
                        }}
                        className="inline-flex items-center gap-1.5 bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech px-3 py-1.5 rounded text-xs font-bold transition-colors cursor-pointer"
                      >
                        {copiedSql ? <Check size={13} /> : <Copy size={13} />}
                        <span>{copiedSql ? 'Schema SQL Copied!' : 'Copy Complete Schema SQL'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Footer Ribbon */}
            <div className="bg-[#050914] px-4 sm:px-6 py-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs font-mono-tech text-slate-400">
              <div className="flex items-center gap-3">
                <span>Total Enquiries: <strong>{enquiries.length}</strong></span>
                <span>·</span>
                <span>Total Appointments: <strong>{appointments.length}</strong></span>
              </div>
              <div>
                <span>Narayan Engineering · Vadodara EPC Operations</span>
              </div>
            </div>
          </div>
        )}

        {/* Detailed Modal: Enquiry */}
        {selectedEnquiry && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="bg-[#0A1224] text-white border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              <div className="bg-[#060B17] p-5 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono-tech uppercase text-orange-400 font-bold block">
                    {selectedEnquiry.type === 'rfq' ? 'TENDER / RFQ SPECIFICATION' : 'GENERAL INQUIRY RECORD'}
                  </span>
                  <h3 className="text-base font-bold font-sans text-white mt-0.5">
                    {selectedEnquiry.name} · {selectedEnquiry.company || 'Enterprise Requisition'}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedEnquiry(null)}
                  className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 space-y-4 overflow-y-auto text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono-tech">
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">STATUS</span>
                    <span className="font-semibold text-emerald-400 uppercase mt-0.5 block">
                      {selectedEnquiry.status || 'new'}
                    </span>
                  </div>
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">PHONE</span>
                    <a href={`tel:${selectedEnquiry.phone}`} className="text-white hover:text-emerald-400 mt-0.5 block">
                      {selectedEnquiry.phone}
                    </a>
                  </div>
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">EMAIL</span>
                    <a href={`mailto:${selectedEnquiry.email}`} className="text-white hover:text-orange-400 truncate mt-0.5 block">
                      {selectedEnquiry.email}
                    </a>
                  </div>
                </div>

                <div className="space-y-2">
                  <h5 className="font-mono-tech text-xs uppercase text-slate-400 font-bold">
                    Technical Scope &amp; Requisition Details
                  </h5>
                  <div className="bg-[#060D1A] p-4 rounded-lg border border-slate-800 space-y-3 font-mono-tech text-xs leading-relaxed text-slate-200">
                    {selectedEnquiry.discipline && (
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase">Engineering Discipline:</span>
                        <span className="text-orange-400 font-bold">{selectedEnquiry.discipline}</span>
                      </div>
                    )}
                    {selectedEnquiry.plantType && (
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase">Plant / Facility Type:</span>
                        <span className="text-slate-200">{selectedEnquiry.plantType}</span>
                      </div>
                    )}
                    {selectedEnquiry.location && (
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase">Site Location:</span>
                        <span className="text-slate-200">{selectedEnquiry.location}</span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Scope of Work:</span>
                      <p className="mt-1 text-slate-100 whitespace-pre-wrap font-sans text-xs bg-[#03060C] p-3 rounded border border-slate-800/80">
                        {selectedEnquiry.scope || selectedEnquiry.message || 'No detailed scope supplied.'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${selectedEnquiry.phone}`}
                      className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-mono-tech px-4 py-2 rounded text-xs font-bold transition-colors"
                    >
                      <Phone size={14} />
                      <span>Call Client</span>
                    </a>
                    <a
                      href={`mailto:${selectedEnquiry.email}?subject=Narayan%20Engineering%20Quotation%20Desk`}
                      className="inline-flex items-center gap-1.5 bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech px-4 py-2 rounded text-xs font-bold transition-colors"
                    >
                      <Mail size={14} />
                      <span>Compose Email</span>
                    </a>
                  </div>

                  <button
                    onClick={() => handleCopyDetails(selectedEnquiry)}
                    className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-tech px-3.5 py-2 rounded text-xs border border-slate-700 transition-colors cursor-pointer"
                  >
                    <Copy size={14} />
                    <span>Copy Full Record</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Detailed Modal: Appointment */}
        {selectedAppointment && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="bg-[#0A1224] text-white border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              <div className="bg-[#060B17] p-5 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono-tech uppercase text-purple-400 font-bold block">
                    SITE VISIT &amp; CONSULTATION APPOINTMENT
                  </span>
                  <h3 className="text-base font-bold font-sans text-white mt-0.5">
                    {selectedAppointment.client_name} · {selectedAppointment.company || 'Enterprise Appointment'}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedAppointment(null)}
                  className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 space-y-4 overflow-y-auto text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono-tech">
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">DATE</span>
                    <span className="font-semibold text-orange-400 mt-0.5 block">
                      {selectedAppointment.appointment_date}
                    </span>
                  </div>
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">TIME SLOT</span>
                    <span className="text-white font-semibold mt-0.5 block truncate">
                      {selectedAppointment.time_slot.split(' ')[0]}
                    </span>
                  </div>
                  <div className="bg-[#060D1A] p-3 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">STATUS</span>
                    <span className="font-semibold text-emerald-400 uppercase mt-0.5 block">
                      {selectedAppointment.status || 'confirmed'}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 font-mono-tech">
                  <div className="bg-[#060D1A] p-4 rounded-lg border border-slate-800 space-y-3 text-xs leading-relaxed text-slate-200">
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Meeting Type:</span>
                      <span className="text-purple-300 font-bold">{selectedAppointment.appointment_type}</span>
                    </div>

                    {selectedAppointment.project_location && (
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase">Plant / Site Location:</span>
                        <span className="text-white">{selectedAppointment.project_location}</span>
                      </div>
                    )}

                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Client Email &amp; Phone:</span>
                      <div className="flex flex-wrap gap-4 mt-1 text-slate-200">
                        <span>{selectedAppointment.email}</span>
                        <span>·</span>
                        <span>{selectedAppointment.phone}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Discussion Agenda / Notes:</span>
                      <p className="mt-1 text-slate-100 whitespace-pre-wrap font-sans text-xs bg-[#03060C] p-3 rounded border border-slate-800/80">
                        {selectedAppointment.notes || 'No custom notes provided.'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${selectedAppointment.phone}`}
                      className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-mono-tech px-4 py-2 rounded text-xs font-bold transition-colors"
                    >
                      <Phone size={14} />
                      <span>Call Client</span>
                    </a>
                    <a
                      href={`mailto:${selectedAppointment.email}?subject=Narayan%20Engineering%20Appointment%20Confirmation`}
                      className="inline-flex items-center gap-1.5 bg-[#F15A24] hover:bg-orange-600 text-white font-mono-tech px-4 py-2 rounded text-xs font-bold transition-colors"
                    >
                      <Mail size={14} />
                      <span>Email Client</span>
                    </a>
                  </div>

                  <button
                    onClick={() => setSelectedAppointment(null)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono-tech px-4 py-2 rounded text-xs cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
