import React from 'react';
import { Eye, Shield, Users, CheckCircle, Sparkles } from 'lucide-react';

export const VisionSection: React.FC = () => {
  return (
    <section id="vision" className="py-20 bg-[#0B1528] text-white border-b border-slate-800 relative overflow-hidden">
      {/* Precision grid pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-25 pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-800/90 border border-slate-700 text-xs font-mono-tech uppercase tracking-wider text-orange-400">
          <Eye size={14} className="text-[#F15A24]" />
          Strategic Aspiration
        </div>

        <div className="space-y-4">
          <h2 className="text-xs uppercase font-mono-tech tracking-widest text-slate-400">
            OUR VISION
          </h2>

          <div className="relative py-4 px-4 sm:px-8">
            <span className="text-4xl sm:text-6xl text-[#F15A24]/30 font-serif absolute -top-4 left-0 leading-none select-none">
              “
            </span>
            <p className="text-2xl sm:text-3xl lg:text-4xl font-extrabold uppercase font-sans tracking-tight text-white leading-snug sm:leading-tight">
              TO BE RECOGNIZED AS THE LEADING INSTRUMENTATION AND ELECTRICAL ENGINEERING COMPANY FOR ITS WORK, QUALITY, SAFETY AND HUMAN RESOURCES COMPETENCY.
            </p>
            <span className="text-4xl sm:text-6xl text-[#F15A24]/30 font-serif absolute -bottom-8 right-0 leading-none select-none">
              ”
            </span>
          </div>
        </div>

        {/* Vision Pillars directly extracted from the vision statement */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-slate-800">
          <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            <div className="text-[#F15A24] font-bold text-xs uppercase font-mono-tech mb-1">Pillar 1</div>
            <div className="text-white font-bold text-sm tracking-wide">WORK EXCELLENCE</div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            <div className="text-[#F15A24] font-bold text-xs uppercase font-mono-tech mb-1">Pillar 2</div>
            <div className="text-white font-bold text-sm tracking-wide">QUALITY COMPLIANCE</div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            <div className="text-[#F15A24] font-bold text-xs uppercase font-mono-tech mb-1">Pillar 3</div>
            <div className="text-white font-bold text-sm tracking-wide">SAFETY CULTURE</div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            <div className="text-[#F15A24] font-bold text-xs uppercase font-mono-tech mb-1">Pillar 4</div>
            <div className="text-white font-bold text-sm tracking-wide">HR COMPETENCY</div>
          </div>
        </div>
      </div>
    </section>
  );
};
