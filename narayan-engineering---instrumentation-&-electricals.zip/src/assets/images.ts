// High-resolution authentic factory, refinery, and instrumentation photography assets
import refineryHeroBanner from './images/refinery_hero_banner_1790417227387.jpg';
import industrialTransmitter from './images/industrial_transmitter_1790417243476.jpg';
import refinerySkyline from './images/refinery_skyline_industries_1790417262111.jpg';
import engineerTabletRefinery from './images/engineer_tablet_refinery_1790417274969.jpg';
import controlValvesSkid from './images/control_valves_skid_1790417341519.jpg';
import instrumentCalibration from './images/instrument_calibration_1790417360096.jpg';
import electricalPanelMCC from './images/electrical_panel_mcc_1790417763860.jpg';
import instrumentGaugesDial from './images/instrument_gauges_1790417780359.jpg';
import fieldMaintenanceTechs from './images/field_maintenance_1790417796576.jpg';

// Featured Projects Photography
import projRefineryCabling from './images/proj_refinery_cabling_1790418124163.jpg';
import projDcsControlRoom from './images/proj_dcs_control_room_1790418143823.jpg';
import projValveManifold from './images/proj_valve_manifold_1790418164668.jpg';
import projSubstation from './images/proj_substation_1790418183604.jpg';
import projTurnaround from './images/proj_turnaround_1790418198419.jpg';
import projCalibration from './images/proj_calibration_1790418218197.jpg';

export const IMAGES = {
  heroBanner: {
    src: refineryHeroBanner,
    alt: 'Massive modern oil refinery and petrochemical complex illuminated at dusk',
    title: 'Hydrocarbon Refinery & Petrochemical Complex Infrastructure',
    tag: 'Petrochemical / Refinery Infrastructure',
  },
  transmitter: {
    src: industrialTransmitter,
    alt: 'Industrial digital pressure transmitter with LCD display gauge mounted on process piping',
    title: 'Field Pressure & Differential Flow Transmitter',
    tag: 'Field Instrumentation & Sensing',
    specs: 'HART Protocol · 0-100 BAR · 4-20mA Output · Ex-d Class 1 Div 1',
  },
  instrumentGauges: {
    src: instrumentGaugesDial,
    alt: 'Precision stainless steel process pressure gauges and digital dials on high-pressure manifold',
    title: 'Precision Process Gauges & Manifold Dial Instrumentation',
    tag: 'Process Gauges & Sensing',
    specs: 'SS316 Dial Gauges · 0-250 kg/cm² · Dual Scale · Manifold Valve Hookups',
  },
  electricalPanel: {
    src: electricalPanelMCC,
    alt: 'Industrial electrical switchgear panels, MCC motor control centers and busbars in refinery substation',
    title: 'HT/LT Switchgear & Motor Control Center Panels',
    tag: 'Electrical Power & Switchgear',
    specs: '415V MCC / PCC Panels · Air Circuit Breakers · Flameproof Enclosures',
  },
  fieldMaintenance: {
    src: fieldMaintenanceTechs,
    alt: 'Certified Indian instrumentation technicians conducting field maintenance on plant junction boxes and transmitters',
    title: 'Turnkey Field Maintenance & Annual Shutdown Operations',
    tag: 'Field Maintenance & Overhaul',
    specs: 'Preventive Overhaul · 24/7 Rapid Mobilization · Zero Unplanned Downtime',
  },
  refinerySkyline: {
    src: refinerySkyline,
    alt: 'Continuous chemical, fertilizer and refinery plant distillation towers at sunset',
    title: 'Continuous Process Plant Sector Footprint',
    tag: 'Continuous Process Facilities',
  },
  engineerOnSite: {
    src: engineerTabletRefinery,
    alt: 'Certified Indian instrumentation commissioning engineer with tablet at refinery complex',
    title: 'Turnkey Commissioning & Field Engineering Teams',
    tag: 'On-Site Engineering & Telemetry',
    experience: 'Over 35 Years of Proven Field Track Record (Estd. 1991)',
  },
  controlValves: {
    src: controlValvesSkid,
    alt: 'Pneumatic flow control valves with smart digital positioners and piping manifold',
    title: 'Precision Final Control Elements & Valve Automation',
    tag: 'Valves & Actuation Systems',
    specs: 'Smart Electro-Pneumatic Positioner · SS316 Piping · Class 300 Flanges',
  },
  calibrationBench: {
    src: instrumentCalibration,
    alt: 'Instrumentation technician calibrating differential pressure transmitter with digital test kit',
    title: 'Certified Testing, Calibration & Loop Checking',
    tag: 'Calibration & Loop Verification',
    specs: 'NABL Traceable Test Bench · Handheld Calibrator · 5-Point Calibration',
  },
};

export interface FeaturedProject {
  id: string;
  title: string;
  category: 'refinery' | 'electrical' | 'instrumentation' | 'turnaround';
  categoryLabel: string;
  client: string;
  location: string;
  scope: string;
  image: string;
  aspectRatioClass: string;
  deliverables: string[];
  metrics: string;
  year: string;
}

export const FEATURED_PROJECTS: FeaturedProject[] = [
  {
    id: 'proj-1',
    title: 'Perforated Cable Tray & Signal Routing Overhaul',
    category: 'refinery',
    categoryLabel: 'Refinery Infrastructure',
    client: 'Gujarat Refinery (IOCL)',
    location: 'Vadodara, Gujarat',
    scope: 'Erection of heavy-duty ladder and perforated cable trays along piperacks, laying screened instrumentation pair cables, and junction box terminations.',
    image: projRefineryCabling,
    aspectRatioClass: 'aspect-[16/10]',
    deliverables: [
      '22,000+ Meters Multi-pair Cable Laying',
      'Perforated GI Tray Fabrication & Clamping',
      '120+ Hazardous-area Ex-d Junction Boxes',
      'Complete Megger & Loop Continuity Sign-off',
    ],
    metrics: 'Zero Downtime · 100% QA Inspection Tagged',
    year: '2023–24',
  },
  {
    id: 'proj-2',
    title: 'DCS Marshalling Cabinets & SCADA Integration',
    category: 'instrumentation',
    categoryLabel: 'Automation & Control Rooms',
    client: 'Petrochemical Complex',
    location: 'Dahej / Hazira PCPIR, Gujarat',
    scope: 'Assembly, wiring, glanding, and cold/hot loop testing for Honeywell / Yokogawa DCS marshalling panels, system cabinets, and analyzer sample skids.',
    image: projDcsControlRoom,
    aspectRatioClass: 'aspect-[4/3]',
    deliverables: [
      '48 Marshalling & System Racks Erection',
      'Fiber Optic & Modbus Serial Communication',
      'Instrument Gas & Air Header Tubing',
      'Joint SAT with OEM DCS Specialists',
    ],
    metrics: '99.98% First-Pass Loop Verification',
    year: '2023',
  },
  {
    id: 'proj-3',
    title: 'High-Pressure Manifolds & Differential Transmitters',
    category: 'instrumentation',
    categoryLabel: 'Field Instrumentation',
    client: 'Natural Gas Cracking Facility',
    location: 'Gandhar / Bharuch, Gujarat',
    scope: 'Fabrication of 1/2" SS316 seamless impulse tubing, 5-valve manifold mounting, and hydrostatic testing for smart differential pressure transmitters.',
    image: projValveManifold,
    aspectRatioClass: 'aspect-[3/4]',
    deliverables: [
      'SS316 Tubing with Swagelok / Parker Fittings',
      'Argon Purged TIG Welding on Socket Welds',
      '300 BAR Hydrostatic Pressure Testing',
      'HART Protocol Range Calibration',
    ],
    metrics: '300 BAR Hydro Verified',
    year: '2022',
  },
  {
    id: 'proj-4',
    title: '415V MCC Switchgear & Substation Busbar Couplers',
    category: 'electrical',
    categoryLabel: 'Industrial Electrical',
    client: 'Petroleum Terminal & Tank Farm',
    location: 'Vadinar / Jamnagar, Gujarat',
    scope: 'HT transformer secondary connections, 415V Motor Control Center (MCC) panel positioning, busbar torque verification, and flameproof gland terminations.',
    image: projSubstation,
    aspectRatioClass: 'aspect-[4/3]',
    deliverables: [
      '18-Panel Draw-out Type MCC Installation',
      '1250A Copper Busbar Torque Checked',
      'Air Circuit Breaker (ACB) Timing Tests',
      'Substation Earthing Grid & Pit Construction',
    ],
    metrics: 'Class A Electrical Contractor Standard',
    year: '2024',
  },
  {
    id: 'proj-5',
    title: 'Refinery Annual Turnaround & Rapid Loop Overhaul',
    category: 'turnaround',
    categoryLabel: 'Plant Turnaround & Shutdown',
    client: 'Mangalore Refinery & Petrochem (MRPL)',
    location: 'Mangalore, Karnataka',
    scope: 'Mobilization of 120+ specialized technicians and engineers for scheduled 21-day continuous revamp: control valve servicing, transmitter recertification, and emergency loop checkout.',
    image: projTurnaround,
    aspectRatioClass: 'aspect-[16/9]',
    deliverables: [
      '24/7 Day & Night Shift Crew Mobilization',
      'Over 850 Control Loops Checked in 18 Days',
      'Pneumatic Actuator Stroke Calibrations',
      'Zero Lost Time Injury (LTI) Safety Record',
    ],
    metrics: 'Completed 3 Days Ahead of Schedule',
    year: '2023',
  },
  {
    id: 'proj-6',
    title: 'NABL Certified 5-Point Calibration Bench Facility',
    category: 'instrumentation',
    categoryLabel: 'Testing & Calibration',
    client: 'Specialty Chemical & Polymer Plant',
    location: 'Nandesari / Vadodara, Gujarat',
    scope: 'Setup of on-site master calibration facility using Fluke digital test instruments, dead-weight testers, and dry-block calibrators for ISO 9001 audit compliance.',
    image: projCalibration,
    aspectRatioClass: 'aspect-[3/4]',
    deliverables: [
      '5-Point Calibration (0%, 25%, 50%, 75%, 100%)',
      'NABL Traceable Test Bench Equipment',
      'Over 1,200 Certified Tagged Instruments',
      'Complete Test Certificate Documentation Dossier',
    ],
    metrics: '100% Regulatory Audit Acceptance',
    year: '2024',
  },
];


